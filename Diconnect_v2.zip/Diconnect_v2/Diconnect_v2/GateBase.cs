using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// Base class for every gate. Deriving a gate needs ONE file:
    /// set width/height (cells), pin counts, override evaluate(), done.
    /// </summary>
    internal abstract class GateBase : IGate
    {
        // ---- identity & placement ------------------------------------------------------

        public string name = "gate";

        /// <summary>Top-left cell of the gate inside the gate grid. Pins do NOT take cells.</summary>
        public int cell_x, cell_y;

        /// <summary>
        /// Size in grid cells: automatically as big as the name needs (Raylib
        /// MeasureTextEx) and as high as the pins need - at least 1x1.
        /// Gates can ignore this with <see cref="fixed_size"/> (e.g. AND/OR 2x2).
        /// </summary>
        public (int width, int height)? fixed_size;

        public (int width, int height) get_cell_size()
        {
            if (fixed_size != null) return fixed_size.Value;

            (int w, int _) = Global.measure_gate_cells(num_inputs, num_outputs, name);

            //hoehe: alle pins muessen neben- und uebereinander passen
            int pin_rows = Math.Max(num_inputs, num_outputs) + 2;
            int h = Math.Max(1, (int)Math.Ceiling(pin_rows * (float)Global.pin_size / Global.cell_size));
            return (w, h);
        }

        /// <summary>Does the common draw show the name text? Gates like LEVER draw their own.</summary>
        public bool draw_name = true;

        public abstract int num_inputs { get; }
        public abstract int num_outputs { get; }

        public Pin[] inputs;
        public Pin[] outputs;

        /// <summary>For saving/loading later: which gate type to instantiate.</summary>
        public abstract string type_id();

        protected List<bool> saved_input_values = new();
        protected List<bool> saved_output_values = new();

        protected GateBase()
        {
            int ni = num_inputs, no = num_outputs;
            inputs = new Pin[ni];
            for (int i = 0; i < ni; i++) inputs[i] = new Pin(this, true, i) { name = "IN" + i };
            outputs = new Pin[no];
            for (int i = 0; i < no; i++) outputs[i] = new Pin(this, false, i) { name = "OUT" + i };
        }

        public int id { get; private set; } = World.next_gate_id();

        // ---- state: IGate ---------------------------------------------------------------

        protected List<bool> new_outputs = new();
        bool outputs_changed;

        public bool read()
        {
            List<bool> ins = new List<bool>();
            foreach (Pin p in inputs) ins.Add(p.get_from_wire());
            new_outputs = evaluate(ins);
            while (new_outputs.Count < num_outputs) new_outputs.Add(outputs[new_outputs.Count].state);
            while (new_outputs.Count > num_outputs) new_outputs.RemoveAt(new_outputs.Count - 1);

            outputs_changed = false;
            for (int i = 0; i < num_outputs; i++)
                if (new_outputs[i] != outputs[i].state) { outputs_changed = true; break; }
            return outputs_changed;
        }

        public bool write()
        {
            bool changed = outputs_changed;
            for (int i = 0; i < num_outputs; i++) outputs[i].state = new_outputs[i];
            for (int i = 0; i < num_inputs; i++) inputs[i].state = inputs[i].get_from_wire();
            return changed;
        }

        /// <summary>
        /// The gate's logic: given the input vector, return the OUTPUT values
        /// it WANTS (they are applied later by write()).
        /// For stateful gates, cache internal state here (e.g. latches).
        /// </summary>
        protected abstract List<bool> evaluate(List<bool> inputs);

        public List<bool> get_inputs()
        {
            var v = new List<bool>();
            foreach (Pin p in inputs) v.Add(p.state);
            return v;
        }

        public List<bool> get_outputs()
        {
            var v = new List<bool>();
            foreach (Pin p in outputs) v.Add(p.state);
            return v;
        }

        public List<IGate> get_fanout()
        {
            var fan = new List<IGate>();
            foreach (Pin p in outputs)
                foreach (Wire w in p.wires)
                    if (w.input != null && !fan.Contains(w.input.gate))
                        fan.Add(w.input.gate);
            return fan;
        }

        // ---- interaction -----------------------------------------------------------------

        /// <summary>User interaction happens between ticks (e.g. lever toggle).</summary>
        public virtual void on_right_click(GateBase self, bool pressed, Vector2 world_pos) { }

        /// <summary>Called once per frame for per-frame things (blink timers on traps, etc.).</summary>
        public virtual void frame_update(float dt) { }

        /// <summary>Future custom info text / titles per state (inspecting mode).</summary>
        public virtual string info_text() { return name; }

        public Pin pin_at(Vector2 world_pos)
        {
            foreach (Pin p in inputs) if (p.hit(world_pos)) return p;
            foreach (Pin p in outputs) if (p.hit(world_pos)) return p;
            return null;
        }

        // ---- rendering --------------------------------------------------------------------

        /// <summary>Cull test: is this gate's bounding box (incl. pins) visible in the camera view?</summary>
        public bool visible(Camera2D cam)
        {
            (int w, int h) = get_cell_size();
            float px = cell_x * Global.cell_size - Global.pin_size;
            float py = cell_y * Global.cell_size - Global.pin_size;
            float pw = w * Global.cell_size + 2 * Global.pin_size;
            float ph = h * Global.cell_size + 2 * Global.pin_size;
            return Raylib.CheckCollisionRecs(
                new Rectangle(px, py, pw, ph), Global.camera_rect(cam));
        }

        public virtual void draw()
        {
            (int w, int h) = get_cell_size();
            Global.draw_common(cell_x, cell_y, w, h, num_inputs, num_outputs,
                               draw_name ? name : "", inputs, outputs);
            draw_costum();
        }

        /// <summary>Custom visuals for gates that need more (displays, levers, lamps). Optional.</summary>
        public virtual void draw_costum() { }

        public void draw_common() { draw(); }
    }
}
