using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// A lever: one output, no inputs. Right-click toggles. Draws no name,
    /// instead a big 1 or 0 - red when on.
    /// </summary>
    internal class LEVER : GateBase
    {
        public override int num_inputs => 0;
        public override int num_outputs => 1;

        public bool is_on;

        public LEVER()
        {
            name = "lever";
            draw_name = false;
        }

        /// <summary>Right-click toggles (handled between ticks from building mode).</summary>
        public void toggle()
        {
            is_on = !is_on;
            // wires are instant: the new output value is live immediately,
            // the FANOUT re-evaluates on the next tick
            outputs[0].state = is_on;
            foreach (IGate f in get_fanout())
                World.schedule(f);
            World.kick();           // make sure a tick runs even with ticks_per_frame < 1
        }

        public override string type_id() => "LEVER";

        protected override List<bool> evaluate(List<bool> inputs)
        {
            // no inputs; keep the applied state so toggling doesn't snap back to false
            return new List<bool> { outputs[0].state };
        }

        public override void draw_costum()
        {
            (int w, int h) = get_cell_size();
            int px = cell_x * Global.cell_size;
            int py = cell_y * Global.cell_size;
            int pw = w * Global.cell_size;
            int ph = h * Global.cell_size;

            string text = is_on ? "1" : "0";
            Color col = is_on ? Global.activecolor : Global.standart_color;

            Vector2 size = Raylib.MeasureTextEx(Global.font, text, Global.font_size, 1f);
            Raylib.DrawTextEx(Global.font, text,
                new Vector2(px + (pw - size.X) / 2f, py + (ph - size.Y) / 2f),
                Global.font_size, 1f, col);
        }
    }
}
