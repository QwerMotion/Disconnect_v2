using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// A lamp: one input, no outputs. Filled red while it receives a signal,
    /// white when it is dark. 1x1 cells.
    /// </summary>
    [GateCategory("basic")]
    internal class LAMP : GateBase
    {
        public override int num_inputs => 1;
        public override int num_outputs => 0;

        public bool is_lit;

        public LAMP()
        {
            name = "lamp";
            draw_name = false;
            fixed_size = (1, 1);
        }

        public override string type_id() => "LAMP";

        protected override List<bool> evaluate(List<bool> inputs)
        {
            // remember the lit state between ticks so it survives a read/write cycle
            if (inputs.Count > 0) is_lit = inputs[0];
            return new List<bool>();
        }

        public override void draw_costum()
        {
            (int w, int h) = get_cell_size();
            int px = cell_x * Global.cell_size;
            int py = cell_y * Global.cell_size;
            int pw = w * Global.cell_size - 8;
            int ph = h * Global.cell_size - 8;

            Raylib.DrawRectangle(px + 4, py + 4, pw, ph,
                                 is_lit ? Global.activecolor : Global.standart_color);
        }
    }
}
