using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    internal class NOT : GateBase
    {
        public override int num_inputs => 1;
        public override int num_outputs => 1;
        public override string type_id() => "NOT";

        public NOT() { name = "NOT"; }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            return new List<bool> { !inputs[0] };
        }
    }
}
