using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    internal class AND : GateBase
    {
        public override int num_inputs => 2;
        public override int num_outputs => 1;
        public override string type_id() => "AND";

        public AND()
        {
            name = "AND";
            //and/or sind immer 2x2 zellen, unabhaengig vom namen
            fixed_size = (2, 2);
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            bool all = true;
            foreach (bool b in inputs) if (!b) { all = false; break; }
            return new List<bool> { all };
        }
    }
}
