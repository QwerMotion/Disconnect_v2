﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diconnect_v2
{
    internal interface IWire
    {
        bool get_state();

        (Ipin output, Ipin input) get_connection();

        bool connect(Ipin output, Ipin input); //if both pins are outputs or both are inputs, this should return false
    }
}
