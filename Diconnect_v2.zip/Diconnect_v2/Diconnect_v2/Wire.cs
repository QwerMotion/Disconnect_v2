using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// An instant connection between one output pin and one input pin.
    /// No gate delay: a wire's state is simply its driving output pin's state.
    /// </summary>
    internal class Wire : IWire
    {
        public Pin output;
        public Pin input;

        public Wire() { }

        public Wire(Pin output_pin, Pin input_pin)
        {
            output = output_pin;
            input = input_pin;
        }

        // ---- IWire ------------------------------------------------------------------

        public bool get_state() => output.state;
        public (Ipin output, Ipin input) get_connection() => (output, input);

        public bool connect(Ipin output_pin, Ipin input_pin)
        {
            if (output_pin.is_input() == input_pin.is_input()) return false;
            Pin op = output_pin.is_input() ? (Pin)input_pin : (Pin)output_pin;
            Pin ip = output_pin.is_input() ? (Pin)output_pin : (Pin)input_pin;
            connect_undirected(op, ip);
            return true;
        }

        // ---- helpers ------------------------------------------------------------------

        /// <summary>Real connect: only a valid output->input pair will register this wire.</summary>
        public bool connect_undirected(Pin a, Pin b)
        {
            // decide real direction
            Pin op, ip;
            if (!a.input && b.input) { op = a; ip = b; }
            else if (a.input && !b.input) { op = b; ip = a; }
            else return false; // both same kind

            output = op;
            input = ip;

            output.wires.Add(this);   // output can feed many
            input.wires.Add(this);    // input kann jetzt MEHERE fan-in-traeger haben (or)

            World.register(this);
            return true;
        }

        /// <summary>
        /// The wire between these two pins, if one exists (null otherwise).
        /// Direction-independent: pins can be passed in any order.
        /// </summary>
        public static Wire find_between(Pin a, Pin b)
        {
            if (a == null || b == null) return null;

            Pin from, to;
            if (!a.input && b.input) { from = a; to = b; }
            else if (a.input && !b.input) { from = b; to = a; }
            else return null; // same kind can never be wired

            foreach (Wire w in World.wires)
                if (w.output == from && w.input == to) return w;
            return null;
        }

        public void destroy(List<Wire> removal_notification_list)
        {
            if (output == null && input == null) return;
            // unlink from pins
            if (output != null && output.wires.Contains(this)) output.wires.Remove(this);
            if (input != null && input.wires.Contains(this)) input.wires.Remove(this);
            output = null;
            input = null;
            World.unregister(this);
        }

        /// <summary>
        /// Eine glatte kubische bezier-kurve STRIKT zwischen den beiden pins
        /// (keine mittel-/wegpunkte): die kontrolle-punkte liegen EXAKT
        /// waagrecht neben ihren pins, dadurch steht die kurve an beiden
        /// endpunkten garantiert senkrecht zur y-achse (waagrechte
        /// ankunft/abfahrt) und schwingt dann im bogen zum ziel.
        /// </summary>
        static void draw_smooth_curve(Vector2 a, Vector2 b, Color c, float thickness)
        {
            //kontroll-punktabstand: mit der pin-distanz wachsend
            float dx = MathF.Max(24f, MathF.Min(120f, MathF.Abs(b.X - a.X) * 0.4f));
            Vector2 c1 = new Vector2(a.X + dx, a.Y);   // waagrecht hinter dem start-pin
            Vector2 c2 = new Vector2(b.X - dx, b.Y);   // waagrecht vor dem ziel-pin

            //kubische bezier: start, kontrollpunkte, ziel - die kurve startet
            //exakt am start-pin und endet exakt am ziel-pin
            Raylib.DrawSplineBezierCubic(
                new Vector2[] { a, c1, c2, b },
                4, thickness, c);
        }

        public void draw(Camera2D cam)
        {
            Color c = output != null && output.state ? Global.activecolor : Global.wire_color;
            draw_smooth_curve(output.center(), input.center(), c, Global.wire_thickness);
        }

        /// <summary>Preview: dieselbe bezier-kurve wie die echte leitung,
        /// gelber tint.</summary>
        public static void draw_preview_curve(Pin start, Vector2 mouse)
        {
            if (start == null) return;
            draw_smooth_curve(start.center(), mouse,
                new Color(255, 255, 0, 160), Global.wire_thickness + 1f);
        }
    }
}
