using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// One pin of a gate. Pins do NOT occupy grid cells.
    /// An input pin can be driven by many wires at once: it reads HIGH if at
    /// least one of its fan-in wires is high (artificial "or" gate).
    /// </summary>
    internal class Pin : Ipin
    {
        public readonly IGate gate;
        public readonly bool input;   // true = input pin, false = output pin
        public readonly int index;    // index along its side of the gate

        public List<Wire> wires = new(); // output: all outgoing; input: all fan-in

        public bool state;         // applied/current value (input: last received; output: last applied)
        public bool pending_state; // computed by read(), applied by write()

        public string name = "";
        public string description = "";

        public Pin(IGate gate, bool is_input, int index)
        {
            this.gate = gate;
            input = is_input;
            this.index = index;
            name = (is_input ? "IN" : "OUT") + index;
        }

        // ---- Ipin -------------------------------------------------------------------

        public IGate get_gate() => gate;
        public bool get_state() => state;
        public bool is_input() => input;
        public string get_name() => name;
        public string get_description() => description;

        // ---- helpers ----------------------------------------------------------------

        /// <summary>Value an evaluation should see: for inputs the OR over all
        /// fan-in wire states (artificial or), else own state.</summary>
        public bool get_from_wire()
        {
            if (input)
            {
                foreach (Wire w in wires)
                    if (w.output != null && w.output.state) return true; //or-fan-in
                return false; //kein (hoher) fan-in vorhanden
            }
            return state;
        }

        public Vector2 center()
        {
            Rectangle r = rect();
            return new Vector2(r.X + r.Width / 2f, r.Y + r.Height / 2f);
        }

        /// <summary>Screen-space rect of this pin. Proxy to the gate's placement + shared pin math.</summary>
        public Rectangle rect()
        {
            if (gate is GateBase g)
            {
                (int w, int h) = g.get_cell_size();
                return Global.pin_rect(g.cell_x, g.cell_y, w, h, count(), index, input);
            }
            return new Rectangle(0, 0, 0, 0);
        }

        private int count()
        {
            if (gate is GateBase g)
                return input ? g.num_inputs : g.num_outputs;
            return 1;
        }

        public bool hit(Vector2 world_pos)
        {
            Rectangle r = rect();
            return Raylib.CheckCollisionPointRec(world_pos, r);
        }

        public void disconnect_all()
        {
            foreach (var wd in wires) wd.destroy(null);
            wires.Clear();
        }
    }
}
