﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diconnect_v2
{
    internal interface IGate
    {
        void draw_common(); //for drawing what every gate has in common (box with gatename and pins)

        (int width, int height) get_cell_size(); //for drawing the box

        bool read(); //evluate new state, dont apply it yet, return true if output has changed
                    
        bool write(); //apply new state to self, if something changed, return true
                      //if this is true, the fanout needs to be put in next

        List<bool> get_inputs(); //returns a binary vector thar represents its input signals
                                //mostly to enforce having such a vector for internal calcultions
        List<bool> get_outputs(); //returns a binary vector thar represents its output signals
                                  //mostly to enforce having such a vector for internal calcultions

        List<IGate> get_fanout(); //returns a list of all gates that are connected to an output if this gate
    }
}
