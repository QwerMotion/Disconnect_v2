using Raylib_cs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace Diconnect_v2
{
    /// <summary>
    /// Inventory of all placeable entries, drawn as a simple text list
    /// (inspired by the Disconnect Inventory): W/S selects, A/D pages,
    /// mouse wheel scrolls, left click selects directly, page indicator
    /// underneath. Entries are gate types OR the special "cable" tool -
    /// cableing logic only applies while cable is selected.
    /// </summary>
    internal static class Inventory
    {
        //so viele eintraege werden gleichzeitig auf einer inventar-seite angezeigt
        static public int items_per_page = 6;

        //eintraege: Type (gate) oder "cable" (verkabelungs-werkzeug), alphabetisch
        static public List<object> elements = new();

        //globaler index ueber elements
        static public int selected = 0;

        static public void init()
        {
            //nur gates: das cable-werkzeug ist kein inventar-eintrag mehr,
            //es wird per hotkey (c) Ein-/Ausgeschaltet
            List<(string name, object entry)> all = new();
            foreach (var p in GateRegistry.pages)
                foreach (var t in p.gate_types)
                    all.Add((t.Name.ToLowerInvariant(), t));

            all.Sort((a, b) => string.CompareOrdinal(a.name, b.name));
            elements.Clear();
            foreach (var (_, entry) in all) elements.Add(entry);
            selected = 0;
        }

        static public int count => elements.Count;

        static int get_max_pages_for(int cnt) => cnt <= 0 ? 1 : (cnt + items_per_page - 1) / items_per_page;

        static public int get_max_pages() => get_max_pages_for(count);

        static public int get_current_page() => count == 0 ? 0 : selected / items_per_page;

        static void set_page_ref(ref int sel, int new_page, int cnt)
        {
            int mp = get_max_pages_for(cnt);

            //ueber das letzte blatt -> wieder vorne, unter das erste -> wieder hinten
            if (new_page >= mp) new_page = 0;
            else if (new_page < 0) new_page = mp - 1;

            //auswahl auf das erste element der neuen seite setzen
            sel = new_page * items_per_page;
            if (sel >= cnt && cnt > 0) sel = cnt - 1;
        }

        static void increment_ref(ref int sel, int cnt)
        {
            if (cnt <= 0) return;

            //innerhalb der aktuellen seite umschalten (w/s bzw mausrad)
            int page_start = (sel / items_per_page) * items_per_page;
            int page_end = Math.Min(page_start + items_per_page, cnt);

            sel += 1;
            if (sel >= page_end) sel = page_start;
        }

        static void decrement_ref(ref int sel, int cnt)
        {
            if (cnt <= 0) return;

            int page_start = (sel / items_per_page) * items_per_page;

            sel -= 1;
            if (sel < page_start)
                sel = Math.Min(page_start + items_per_page, cnt) - 1;
        }

        //tastatur-steuerung: w/s innerhalv der seite, a/d seitenwechsel
        static void do_input_ref(ref int sel, int cnt)
        {
            if (Raylib.GetMouseWheelMove() < 0) increment_ref(ref sel, cnt);
            if (Raylib.GetMouseWheelMove() > 0) decrement_ref(ref sel, cnt);

            if (Raylib.IsKeyPressed(KeyboardKey.S)) increment_ref(ref sel, cnt);
            if (Raylib.IsKeyPressed(KeyboardKey.W)) decrement_ref(ref sel, cnt);

            //seitenwechsel, umlaeufe ganz oben/unten
            if (Raylib.IsKeyPressed(KeyboardKey.A)) set_page_ref(ref sel, sel / items_per_page - 1, cnt);
            if (Raylib.IsKeyPressed(KeyboardKey.D)) set_page_ref(ref sel, sel / items_per_page + 1, cnt);
        }

        /// <summary>The gate type behind the current selection.</summary>
        static public Type get_selected_type() => count == 0 ? null : elements[selected] as Type;

        //anzeige-name des eintrags an index i (kleinschreibung wie im vorbild)
        static public String get_display_name(int index)
        {
            return (elements[index] as Type)?.Name.ToLowerInvariant() ?? "?";
        }

        static public void do_input(Vector2 window_mouse, float ox, float oy, float scale)
        {
            //das inventar reagiert nur auf tastatur (w/s/a/d) und mausrad -
            //keine maus-klicks, links-klicks fallen komplett in die welt durch
            do_input_ref(ref selected, count);
        }

        // ---- zeichnen ----------------------------------------------------------------

        static public void draw(float ox, float oy, float scale)
        {
            if (count <= 0) return;

            int page = selected / items_per_page;
            int page_start = page * items_per_page;
            int page_end = Math.Min(page_start + items_per_page, count);
            float font_size = Global.inventory_fontsize * scale;
            float line = Global.inventory_line_height * scale;

            //nur die eintraege der aktuellen seite anzeigen
            for (int i = page_start; i < page_end; i++)
            {
                Color draw_color = Color.LightGray;
                if (i == selected) draw_color = Color.Orange;

                Raylib.DrawTextEx(Global.font, get_display_name(i),
                    new Vector2(ox + 10 * scale, oy + 10 * scale + line * (i - page_start)),
                    font_size, 0f, draw_color);
            }

            //seitenanzeige direkt unter dem letzten eintrag der aktuellen seite
            string page_text = $"{page + 1} / {get_max_pages()}";
            Raylib.DrawTextEx(Global.font, page_text,
                new Vector2(ox + 10 * scale, oy + 10 * scale + line * (page_end - page_start)),
                font_size, 0f, Color.LightGray);
        }

        //fenster-pixel-bereich, in dem die liste liegt (fuer klick-masking)
        static public Rectangle screen_rect(float ox, float oy, float scale)
        {
            float h = Global.inventory_fontsize + (items_per_page + 1) * Global.inventory_line_height;
            return new Rectangle(ox, oy, 200 * scale, h * scale + 10 * scale);
        }

        static public bool contains_window(Vector2 window_mouse, float ox, float oy, float scale)
        {
            if (count <= 0) return false;
            return Raylib.CheckCollisionPointRec(window_mouse, screen_rect(ox, oy, scale));
        }
    }
}
