using Diconnect_v2;
using Raylib_cs;
using System;
using System.Collections.Generic;
using System.Numerics;

namespace HelloWorld;

internal static class Program
{
    //16:9 reference resolution of the letterboxed content area
    const float CONTENT_W = 1280f;
    const float CONTENT_H = 720f;

    // inspecting-mode bookkeeping
    static List<GateBase> inspected_set = new();

    static void Main()
    {
        Raylib.SetConfigFlags(ConfigFlags.ResizableWindow);
        Raylib.InitWindow(1280, 720, "Diconnect_v2");
        Raylib.SetTargetFPS(60);
        Raylib.SetWindowMinSize(640, 360);

        GateRegistry.init();
        Inventory.init();
        Global.update_letterbox();

       // seed_world();

        while (!Raylib.WindowShouldClose())
        {
            Global.update_letterbox();

            // user input happens between ticks
            update_camera();
            update_modes();

            // simulation: Global.ticks_per_frame decides how many ticks per frame
            int ticks = Global.ticks_this_frame();
            for (int i = 0; i < ticks; i++) World.tick();

            draw_frame();
        }

        Raylib.CloseWindow();
    }

    static void seed_world()
    {
        World.place(GateRegistry.create("LEVER"), 2, 2);
        World.place(GateRegistry.create("AND"), 6, 2);
        World.place(GateRegistry.create("NOT"), 6, 4);
        World.place(GateRegistry.create("OR"), 10, 3);
        World.place(GateRegistry.create("LAMP"), 6, 6);
    }

    // ---- mouse coords ----------------------------------------------------------------

    /// <summary>Mouse in window pixels.</summary>
    static Vector2 mouse_window() => Raylib.GetMousePosition();

    /// <summary>Mouse in world-space (letterbox handled inside the camera).</summary>
    static Vector2 mouse_world() => Raylib.GetScreenToWorld2D(mouse_window(), Global.camera);

    // ---- camera -------------------------------------------------------------------

    static void update_camera()
    {
        Vector2 v = new Vector2();
        if (Raylib.IsKeyDown(KeyboardKey.Up)) v.Y -= 1;
        if (Raylib.IsKeyDown(KeyboardKey.Down)) v.Y += 1;
        if (Raylib.IsKeyDown(KeyboardKey.Left)) v.X -= 1;
        if (Raylib.IsKeyDown(KeyboardKey.Right)) v.X += 1;
        if (v != Vector2.Zero)
            Global.camera.Target += Vector2.Normalize(v) * Global.cam_speed * Raylib.GetFrameTime();

        //zoom: i rein, o raus (an der mausposition)
        if (Raylib.IsKeyPressed(KeyboardKey.I)) Global.camera_zoom_step(+1);
        if (Raylib.IsKeyPressed(KeyboardKey.O)) Global.camera_zoom_step(-1);
    }

    // ---- modes ---------------------------------------------------------------------

    static void update_modes()
    {
        Vector2 wp = mouse_world();
        // hotkey c toggelt das cable-werkzeug an/aus (kein inventar-eintrag mehr).
        // im cableing-modus bleibt es an, esc beendet beide zustaende.
        if (Raylib.IsKeyPressed(KeyboardKey.C) && Global.state != GlobalState.cableing)
            Global.cable_tool_active = !Global.cable_tool_active;

        bool cable_mode = Global.cable_tool_active;
        bool over_inventory = Global.state == GlobalState.building &&
                              Inventory.contains_window(mouse_window(), Global.content_offset_x,
                                                        Global.content_offset_y, Global.content_scale);

        if (Raylib.IsKeyPressed(KeyboardKey.Escape))
        {
            // esc beendet auch das aktive cable-werkzeug
            if (Global.state == GlobalState.cableing) Global.cable_tool_active = false;
            end_inspecting();
        }

        switch (Global.state)
        {
            case GlobalState.building:
                Inventory.do_input(mouse_window(), Global.content_offset_x, Global.content_offset_y, Global.content_scale);
                update_building(wp, over_inventory, cable_mode);
                break;
            case GlobalState.cableing: update_cableing(wp); break;
            case GlobalState.inspecting: update_inspecting(wp); break;
        }

        Global.selected_gate = Inventory.get_selected_type();
    }

    static void update_building(Vector2 wp, bool over_inventory, bool cable_mode)
    {
        if (over_inventory)
        {
            //das inventar ist rein ein overlay: platzieren/umschalten funktionieren
            //weiterhin, nur der pin-hover-highlighting wird unterdrueckt
            Global.cable_hover = null;
        }
        else
        {
            //nur mit dem cable-werkzeug bekommen pins die hover-farbe
            Global.cable_hover = cable_mode || Global.state == GlobalState.cableing
                ? World.pin_at(wp)
                : null;
        }

        if (Raylib.IsMouseButtonPressed(MouseButton.Right))
        {
            Pin p = World.pin_at(wp);
            if (cable_mode)
            {
                GateBase over = World.gate_at(wp);
                if (p != null)
                {
                    // pin right-click -> cableing mode (nur mit cable ausgewaehlt)
                    Global.cable_start = p;
                    Global.state = GlobalState.cableing;
                    return;
                }
                if (over is LEVER levCable)
                {
                    //lever bleibt auch mit cable-werkzeug anklickbar
                    levCable.toggle();
                    return;
                }
                return; //cable-werkzeug platziert keine gates
            }

            GateBase g = World.gate_at(wp);
            if (g is LEVER lev)
            {
                // lever right-click toggles (user input happens between ticks)
                lev.toggle();
                return;
            }

            if (Global.selected_gate != null)
            {
                (int cx, int cy) = Global.cell_at(wp);
                GateBase new_gate = GateRegistry.create(Global.selected_gate);
                if (new_gate != null && World.place(new_gate, cx, cy))
                    World.kick();
            }
        }

        // left click: mark gate and enter inspecting mode
        // (das inventar verbraucht keine klicks - links-klicks wirken ueberall in der welt,
        //  auch dort wo die liste gerade liegt)
        if (Raylib.IsMouseButtonPressed(MouseButton.Left))
        {
            GateBase g = World.gate_at(wp);
            if (g != null)
            {
                inspected_set.Clear();
                inspected_set.Add(g);
                Global.inspected = g;
                Global.state = GlobalState.inspecting;
                Global.drag_offset = wp - new Vector2(g.cell_x * Global.cell_size, g.cell_y * Global.cell_size);
            }
        }
    }

    static void update_cableing(Vector2 wp)
    {
        Global.cable_hover = World.pin_at(wp);

        if (Raylib.IsKeyPressed(KeyboardKey.Escape))
        {
            Global.cable_start = null;
            Global.state = GlobalState.building;
            return;
        }

        if (Raylib.IsMouseButtonPressed(MouseButton.Right))
        {
            Pin p = World.pin_at(wp);
            if (p != null && !ReferenceEquals(p, Global.cable_start))
            {
                // one output + one input required; same kind cancels
                if (p.is_input() != Global.cable_start.is_input())
                {
                    //bereits verbunden? dieser klick trennt sie wieder
                    Wire existing = Wire.find_between(Global.cable_start, p);
                    if (existing != null)
                    {
                        existing.destroy(null);

                        //der getrennte eingang muss auf unverbunden zurueckfallen
                        Pin in_pin = p.is_input() ? p : Global.cable_start;
                        if (in_pin.gate is GateBase driven) World.eval_gate_recursive(driven);
                    }
                    else
                    {
                        var w = new Wire();
                        w.connect_undirected(Global.cable_start, p);

                        // wires are instant: the driven gate must re-evaluate,
                        // and so must everything downstream of it
                        Pin in_pin = p.is_input() ? p : Global.cable_start;
                        if (in_pin.gate is GateBase driven) World.eval_gate_recursive(driven);
                    }
                    World.kick();
                }
                Global.cable_start = null;
                Global.state = GlobalState.building;
            }
            else if (p == null)
            {
                //clicked nothing -> back to building (keine wegpunkte mehr:
                //ein kabel gehört nur zu zwei pins)
                Global.cable_start = null;
                Global.state = GlobalState.building;
            }
            //klick auf den start-pin selbst: nichts tun (bewusst, damit der
            //starter nicht versehentlich "abgebrochen" wirkt)
        }
    }

    static void update_inspecting(Vector2 wp)
    {
        // T deletes the marked gate
        if (Raylib.IsKeyPressed(KeyboardKey.T))
        {
            GateBase target = Global.dragged ?? Global.inspected;
            if (target != null)
            {
                World.remove(target);
                inspected_set.Remove(target);
                Global.dragged = null;
                Global.inspected = null;
                Global.state = GlobalState.building;
            }
            return;
        }

        // while the left button is down, the marked gate follows the mouse
        if (Global.dragged == null && Raylib.IsMouseButtonDown(MouseButton.Left) && Global.inspected != null)
        {
            Global.dragged = Global.inspected;
            Global.drag_offset = wp - new Vector2(
                Global.inspected.cell_x * Global.cell_size,
                Global.inspected.cell_y * Global.cell_size);
            World.begin_drag(Global.inspected);
        }

        if (Global.dragged != null)
        {
            (int cx, int cy) = Global.cell_at(wp - Global.drag_offset);
            Global.dragged.cell_x = cx;
            Global.dragged.cell_y = cy;

            if (Raylib.IsMouseButtonReleased(MouseButton.Left))
            {
                if (World.is_free_at_drag(Global.dragged))
                    World.commit_drag(Global.dragged);
                else
                    World.abort_drag(Global.dragged);
                Global.dragged = null;
                Global.state = GlobalState.building;
            }
        }
    }

    static void end_inspecting()
    {
        if (Global.dragged != null)
        {
            World.abort_drag(Global.dragged);
            Global.dragged = null;
        }
        Global.inspected = null;
        inspected_set.Clear();
        Global.state = GlobalState.building;
    }

    // ---- drawing -------------------------------------------------------------------

    static void draw_frame()
    {
        Raylib.BeginDrawing();
        Raylib.ClearBackground(Global.frame_color);   // = the letterbox borders (dark gray by default)

        // scissor off the borders so nothing bleeds into them
        Raylib.BeginScissorMode((int)Global.content_offset_x, (int)Global.content_offset_y,
                                (int)(CONTENT_W * Global.content_scale), (int)(CONTENT_H * Global.content_scale));

        //inside the content area the background is black
        Raylib.DrawRectangle((int)Global.content_offset_x, (int)Global.content_offset_y,
                             (int)(CONTENT_W * Global.content_scale), (int)(CONTENT_H * Global.content_scale),
                             Color.Black);

        Raylib.BeginMode2D(Global.camera);
        draw_wires();
        var drawn = new HashSet<IGate>();   // multi-cell gates sit on many keys, draw once
        foreach (var kv in World.gate_grid)
            if (kv.Value is GateBase g && drawn.Add(g) && g.visible(Global.camera))
                g.draw();
        draw_overlays();
        Raylib.EndMode2D();

        //inventory list, top-left in content space - aber NICHT im cabling-mode
        //(c-gedrueckt oder aktiv am verbinden): dort steht stattdessen "connecting"
        if (Global.state == GlobalState.cableing || Global.cable_tool_active)
        {
            string label = "connecting";
            Raylib.DrawTextEx(Global.font, label,
                new Vector2(Global.content_offset_x + 10 * Global.content_scale,
                            Global.content_offset_y + 10 * Global.content_scale),
                Global.inventory_fontsize * Global.content_scale, 0f, Color.Orange);
        }
        else
        {
            Inventory.draw(Global.content_offset_x, Global.content_offset_y, Global.content_scale);
        }

        Raylib.EndScissorMode();
        Raylib.EndDrawing();
    }

    static void draw_wires()
    {
        foreach (Wire w in World.wires)
        {
            if (w.output == null || w.input == null) continue;
            // culled: only draw wires with an on-screen endpoint
            if (Global.point_on_screen(w.output.center(), Global.camera) ||
                Global.point_on_screen(w.input.center(), Global.camera))
                w.draw(Global.camera);
        }

        // cableing preview: exakt dieselbe bezier-kurve wie die spaetere echte leitung
        if (Global.state == GlobalState.cableing && Global.cable_start != null)
            Wire.draw_preview_curve(Global.cable_start, mouse_world());
    }

    static void draw_overlays()
    {
        // hovered pin highlight: nur im cable-gebrauch (cable gewaehlt oder cableing)
        if (Global.cable_hover != null &&
            (Global.state == GlobalState.cableing || Global.cable_tool_active))
            Raylib.DrawRectangleRec(Global.cable_hover.rect(), new Color(255, 255, 0, 110));

        // ghost preview of the selected gate in building mode
        // (none while the cable tool is active, none while hovering a lever
        //  so the lever stays clickable without the preview covering it;
        //  ueber dem inventar wird normal gezeichnet - platzieren geht ueberall)
        GateBase hover_gate = World.gate_at(mouse_world());
        if (Global.state == GlobalState.building && Global.selected_gate != null &&
            hover_gate is not LEVER &&
            !Global.cable_tool_active)
        {
            (int cx, int cy) = Global.cell_at(mouse_world());
            GateBase ghost = GateRegistry.create(Global.selected_gate);
            if (ghost != null)
            {
                ghost.cell_x = cx; ghost.cell_y = cy;
                Color old = Global.standart_color;
                Global.standart_color = new Color(255, 255, 255, 120);
                ghost.draw();
                Global.standart_color = old;
            }
        }

        // highlight the marked gate in inspecting mode
        if (Global.state == GlobalState.inspecting && Global.inspected != null)
        {
            (int w, int h) = Global.inspected.get_cell_size();
            Raylib.DrawRectangleLinesEx(new Rectangle(
                Global.inspected.cell_x * Global.cell_size, Global.inspected.cell_y * Global.cell_size,
                w * Global.cell_size, h * Global.cell_size), 3f, Color.SkyBlue);
        }
    }
}
