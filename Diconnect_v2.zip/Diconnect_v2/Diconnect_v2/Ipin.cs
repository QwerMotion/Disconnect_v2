﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diconnect_v2
{
    internal interface Ipin
    {
        IGate get_gate();

        bool get_state();


        bool is_input();
        string get_name(); //for when hovering over the pin, to show its name eg. J, K, C 

        string get_description(); //same for description
    }

  
}
