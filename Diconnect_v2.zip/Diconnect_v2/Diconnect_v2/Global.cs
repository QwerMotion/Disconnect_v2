using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using Raylib_cs;

namespace Diconnect_v2
{
    public enum GlobalState
    {
        building,
        cableing,
        inspecting
    }

    internal static class Global
    {
        static public Color standart_color = Color.White;
        static public Color activecolor = Color.Red; // wires/pins that are active
        static public Color wire_color = Color.Gray; // wire idle

        static public int cell_size = 64; //pixels
        static public int pin_size = 16; //pixels, quare
        static public int font_size = 32;
        static public Font font = Raylib.LoadFont("fonts/pixy.regular.ttf");
        static public float ticks_per_frame = 0.1f;

        public static float wire_thickness = 2f;

        // ---- inventory look -----------------------------------------------------------

        public static int inventory_fontsize = 20;
        public static int inventory_line_height = 24;

        // ---- window / letterbox (16:9) ------------------------------------------------

        public static float content_offset_x = 0f;
        public static float content_offset_y = 0f;
        public static float content_scale = 1f;
        public static Color frame_color = new Color(35, 35, 35, 255); //letterbox/border-farbe

        //kamera-zoom bereich
        public static float zoom_min = 0.25f;
        public static float zoom_max = 3f;
        public static float zoom_step = 1.25f;

        /// <summary>User zoom (multiplied with the letterbox scale in the camera).</summary>
        public static float user_zoom = 1f;

        /// <summary>Compute the 16:9 letterbox for the current window size and apply it to the camera.</summary>
        public static void update_letterbox()
        {
            float w = Raylib.GetScreenWidth();
            float h = Raylib.GetScreenHeight();

            float scale = Math.Min(w / 1280f, h / 720f);
            content_scale = scale;
            content_offset_x = (w - 1280f * scale) / 2f;
            content_offset_y = (h - 720f * scale) / 2f;

            // the camera maps content-space into the letterboxed rect: offset is the
            // border size, zoom is content_scale * user_zoom. That way mouse -> world
            // conversions stay a single GetScreenToWorld2D call.
            camera.Offset = new Vector2(content_offset_x, content_offset_y);
            if (camera.Zoom <= content_scale || user_zoom != camera.Zoom / content_scale)
                camera.Zoom = content_scale * user_zoom;
        }

        /// <summary>Window -> letterboxed content coordinates.</summary>
        public static Vector2 to_content(Vector2 window_pos)
        {
            return new Vector2((window_pos.X - content_offset_x) / content_scale,
                               (window_pos.Y - content_offset_y) / content_scale);
        }

        /// <summary>Content -> window coordinates.</summary>
        public static Vector2 to_window(Vector2 content_pos)
        {
            return new Vector2(content_pos.X * content_scale + content_offset_x,
                               content_pos.Y * content_scale + content_offset_y);
        }

        public static bool point_in_content(Vector2 window_pos)
        {
            return window_pos.X >= content_offset_x && window_pos.X <= content_offset_x + 1280f * content_scale &&
                   window_pos.Y >= content_offset_y && window_pos.Y <= content_offset_y + 720f * content_scale;
        }

        // ---- state machine -----------------------------------------------------------

        public static GlobalState state = GlobalState.building;

        // ---- inventory selection --------------------------------------------------

        public static Type selected_gate;   // what will be placed on right click
        public static int current_page = 0;

        // ---- cableing ---------------------------------------------------------------

        public static Pin cable_start;      // first clicked pin while cableing
        public static Pin cable_hover;      // pin under mouse while cableing

        //das cable-werkzeug ist kein inventar-eintrag mehr: es wird per hotkey
        //(c) an-/ausgeschaltet und ersetzt den gate-ghost waehrend es aktiv ist
        public static bool cable_tool_active = false;

        // ---- inspecting ---------------------------------------------------------------

        public static GateBase inspected;
        public static GateBase dragged;
        public static Vector2 drag_offset;

        // ---- camera ---------------------------------------------------------------

        public static Camera2D camera = new Camera2D
        {
            Zoom = 1f,
            Target = new Vector2(0, 0),
            Offset = new Vector2(0, 0)
        };
        public static float cam_speed = 400f;

        public static (int cell_x, int cell_y) cell_at(Vector2 world_pos)
        {
            return ((int)Math.Floor(world_pos.X / cell_size),
                    (int)Math.Floor(world_pos.Y / cell_size));
        }

        /// <summary>
        /// Zoom in/out around the mouse position (raylib zoom-to-cursor pattern).
        /// Returns true if a zoom step was applied.
        /// </summary>
        public static bool camera_zoom_step(float dir)
        {
            if (dir == 0) return false;

            float old_user = user_zoom;
            if (dir > 0) user_zoom = Math.Min(zoom_max, user_zoom * zoom_step);
            else user_zoom = Math.Max(zoom_min, user_zoom / zoom_step);
            if (old_user == user_zoom) return false;

            //welt-punkt unterm mauszeiger halten:
            Vector2 mouse = Raylib.GetMousePosition();
            Vector2 before = Raylib.GetScreenToWorld2D(mouse, camera);

            camera.Zoom = content_scale * user_zoom;   //Offset bleibt der briefkasten-rand

            Vector2 after = Raylib.GetScreenToWorld2D(mouse, camera);
            camera.Target += before - after;
            return true;
        }

        public static Rectangle camera_rect(Camera2D cam)
        {
            Vector2 tl = Raylib.GetScreenToWorld2D(new Vector2(0, 0), cam);
            Vector2 br = Raylib.GetScreenToWorld2D(
                new Vector2(Raylib.GetScreenWidth(), Raylib.GetScreenHeight()), cam);
            return new Rectangle(tl.X, tl.Y, br.X - tl.X, br.Y - tl.Y);
        }

        public static bool rect_on_screen(Rectangle r, Camera2D cam)
        {
            return Raylib.CheckCollisionRecs(r, camera_rect(cam));
        }

        public static bool point_on_screen(Vector2 p, Camera2D cam)
        {
            return Raylib.CheckCollisionPointRec(p, camera_rect(cam));
        }

        // ---- pins ------------------------------------------------------------------

        /// <summary>
        /// Shared math so drawing and hit-testing agree: rect of a pin on a gate
        /// boxed (cell_x*cell_size, cell_y*cell_size) of size (w*h cells).
        /// </summary>
        public static Rectangle pin_rect(int cell_x, int cell_y, int width_cells, int height_cells, int pin_count, int index, bool is_input)
        {
            int whole_height = height_cells * cell_size;
            float pin_distance = (whole_height - pin_size * pin_count) / (pin_count + 1);
            int x = is_input ? cell_x * cell_size - pin_size
                             : (cell_x + width_cells) * cell_size;
            int y = cell_y * cell_size + (int)pin_distance * (index + 1) + index * pin_size;
            return new Rectangle(x, y, pin_size, pin_size);
        }

        // ---- tick accumulator ---------------------------------------------------------

        public static float tick_accumulator = 0f;

        /// <summary>
        /// Returns how many ticks run THIS frame. Fractional ticks_per_frame lets
        /// one tick stretch across multiple frames (e.g. 0.5f = 1 tick every 2 frames).
        /// </summary>
        public static int ticks_this_frame()
        {
            tick_accumulator += ticks_per_frame;
            int ticks = (int)tick_accumulator;
            if (ticks > 0) tick_accumulator -= ticks;
            return ticks;
        }

        /// <summary>Size of a gate box: fits the name, min 1 cell.</summary>
        public static (int width, int height) measure_gate_cells(int num_inputs, int num_outputs, string name)
        {
            var m = Raylib.MeasureTextEx(font, name, font_size, 1f);
            int width = Math.Max(1, (int)Math.Ceiling(m.X / cell_size) + 1);   // +1 cell padding
            return (width, 1);
        }

        static public void draw_common(int cell_x, int cell_y, int width_cells, int height_cells, int num_inputs, int num_outputs, string name, Ipin[] inputs = null, Ipin[] outputs = null)
        {
            Raylib.DrawRectangleLines(cell_x * cell_size, cell_y * cell_size, width_cells * cell_size, height_cells * cell_size, standart_color);
            Raylib.DrawTextEx(font, name, new Vector2(cell_x * cell_size + 8, cell_y * cell_size + 8), font_size, 1f, standart_color);

            //draw the pins: red when the pin is active, white otherwise
            for (int i = 0; i < num_inputs; i++)
            {
                Rectangle r = pin_rect(cell_x, cell_y, width_cells, height_cells, num_inputs, i, is_input: true);
                bool active = inputs != null && i < inputs.Length && inputs[i].get_state();
                draw_pin(r, active);
            }

            for (int i = 0; i < num_outputs; i++)
            {
                Rectangle r = pin_rect(cell_x, cell_y, width_cells, height_cells, num_outputs, i, is_input: false);
                bool active = outputs != null && i < outputs.Length && outputs[i].get_state();
                draw_pin(r, active);
            }
        }

        /// <summary>Draw one pin filled with its activity color (activecolor=red when active, white when not).</summary>
        static public void draw_pin(Rectangle r, bool active)
        {
            int size = pin_size;
            int px = (int)r.X;
            int py = (int)r.Y;
            Raylib.DrawRectangle(px, py, size, size, active ? activecolor : standart_color);
        }
    }
}
