using Raylib_cs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Diconnect_v2
{
    /// <summary>
    /// Ein baustein in einer construct-datei: welches gate (type_id), wo relativ
    /// zum linken oberen eck der auswahl, und sein eigener zustand.
    /// </summary>
    internal class ConstructGateData
    {
        public string type { get; set; } = "";

        /// <summary>Zelle relativ zum construct-ursprung.</summary>
        public int x { get; set; }
        public int y { get; set; }

        /// <summary>Zustand des gates (siehe GateBase.save_state): flipflops,
        /// lever und uhren speichern hier ihren zustand. Neue zustands-gates
        /// brauchen keine aenderung an dieser stelle.</summary>
        public Dictionary<string, string> state { get; set; } = new();
    }

    /// <summary>
    /// Ein organize-item (beschriftung/rahmen) in einer construct-datei.
    /// Es liegt auf der eigenen ebene, hat keine pins und keine leitungen -
    /// beim platzieren wird es einfach wieder mit hingelegt.
    /// </summary>
    internal class ConstructOrganizeData
    {
        public string type { get; set; } = "";

        /// <summary>Zelle relativ zum construct-ursprung.</summary>
        public int x { get; set; }
        public int y { get; set; }

        /// <summary>Groesse in zellen (rahmen sind nicht 1x1).</summary>
        public int width { get; set; } = 1;
        public int height { get; set; } = 1;

        /// <summary>Eigener zustand (z.b. der text einer beschriftung).</summary>
        public Dictionary<string, string> state { get; set; } = new();
    }

    /// <summary>Eine leitung zwischen zwei gates des constructs.</summary>
    internal class ConstructWireData
    {
        /// <summary>Index in gates (ausgangs-seite).</summary>
        public int from_gate { get; set; }

        /// <summary>Index des ausgangs-pins an diesem gate.</summary>
        public int from_pin { get; set; }

        /// <summary>Index in gates (eingangs-seite).</summary>
        public int to_gate { get; set; }

        /// <summary>Index des eingangs-pins an diesem gate.</summary>
        public int to_pin { get; set; }

        /// <summary>Farbe der leitung (index in Global.wire_colors, 0 = rot).
        /// Aeltere dateien ohne das feld bekommen rot.</summary>
        public int color { get; set; } = 0;
    }

    /// <summary>
    /// Ein construct: mehrere gates, die zu einer schaltung verdrahtet wurden.
    /// Es steht als eigener eintrag in der kategorie "constructs" im inventar
    /// und wird beim platzieren als ganze gruppe in die welt gesetzt (nichts
    /// darf die platzierung blockieren).
    ///
    /// Die klasse ist gleichzeitig das json-format: version + name + gates +
    /// wires. Neue gates brauchen hier keine aenderung, solange sie ihren
    /// zustand ueber GateBase.save_state()/load_state() beschreiben.
    /// </summary>
    internal class ConstructDef : IMenuEntry
    {
        //standart-rahmendaten fuer die zukunft (migration alter dateien)
        public const int current_version = 1;

        public int version { get; set; } = current_version;
        public string name { get; set; } = "";

        /// <summary>Ausdehnung der auswahl in zellen (nur fuer die vorschau).</summary>
        public int width { get; set; }
        public int height { get; set; }

        public List<ConstructGateData> gates { get; set; } = new();
        public List<ConstructWireData> wires { get; set; } = new();

        /// <summary>Beschriftungen und rahmen, die mitgespeichert wurden.</summary>
        public List<ConstructOrganizeData> organize { get; set; } = new();

        [JsonIgnore]
        public string source_path = "";

        // ---- menu (nicht teil der datei) -----------------------------------------------

        [JsonIgnore]
        public string display_name => name;

        [JsonIgnore]
        public string sort_key => name;

        // ---- platzieren ---------------------------------------------------------------

        /// <summary>Alle ausdehnungen des constructs in zellen (fuer die vorschau).</summary>
        public (int width, int height) footprint()
        {
            if (width > 0 && height > 0) return (width, height);

            int w = 1, h = 1;
            foreach (ConstructGateData entry in gates)
            {
                GateBase g = make_gate(entry);
                if (g == null) continue;
                (int gw, int gh) = g.get_cell_size();
                w = Math.Max(w, entry.x + gw);
                h = Math.Max(h, entry.y + gh);
            }
            return (w, h);
        }

        static GateBase make_gate(ConstructGateData entry)
        {
            GateBase g = GateRegistry.create(entry.type);
            if (g == null) return null;
            g.cell_x = entry.x;
            g.cell_y = entry.y;
            return g;
        }

        /// <summary>
        /// Passt das construct hierhin? Geprueft wird jede zelle jedes gates
        /// gegen die welt UND gegen die anderen gates des constructs.
        /// </summary>
        public bool can_place_at(int cell_x, int cell_y)
        {
            var cells = new HashSet<(int x, int y)>();

            foreach (ConstructGateData entry in gates)
            {
                GateBase g = make_gate(entry);
                if (g == null) return false;                  //unbekannter gate-typ

                (int w, int h) = g.get_cell_size();
                for (int x = cell_x + entry.x; x < cell_x + entry.x + w; x++)
                    for (int y = cell_y + entry.y; y < cell_y + entry.y + h; y++)
                    {
                        if (!cells.Add((x, y))) return false;      //ueberlappt sich selbst
                        if (World.at_cell(x, y) != null) return false;
                    }
            }
            return true;
        }

        /// <summary>
        /// Das construct in die welt setzen: alle gates an ihre position,
        /// zustand wiederherstellen, dann die leitungen ziehen.
        /// </summary>
        public bool place_at(int cell_x, int cell_y)
        {
            if (gates.Count == 0) return false;
            if (!can_place_at(cell_x, cell_y)) return false;

            var placed = new List<GateBase>();
            foreach (ConstructGateData entry in gates)
            {
                GateBase g = GateRegistry.create(entry.type);
                if (g == null) return false;

                g.cell_x = cell_x + entry.x;
                g.cell_y = cell_y + entry.y;
                g.load_state(entry.state);      //zustand VOR dem ersten tick

                if (!World.place(g, g.cell_x, g.cell_y)) return false;   //darf nach can_place_at nicht passieren
                placed.Add(g);
            }

            foreach (ConstructWireData wd in wires)
            {
                if (wd.from_gate < 0 || wd.from_gate >= placed.Count) continue;
                if (wd.to_gate < 0 || wd.to_gate >= placed.Count) continue;

                GateBase from = placed[wd.from_gate], to = placed[wd.to_gate];
                if (wd.from_pin < 0 || wd.from_pin >= from.outputs.Length) continue;
                if (wd.to_pin < 0 || wd.to_pin >= to.inputs.Length) continue;

                //die farbe gehoert zur leitung, nicht zu den pins: vor dem verbinden setzen
                Wire w = new Wire { color_index = Global.clamp_color(wd.color) };
                w.connect_undirected(from.outputs[wd.from_pin], to.inputs[wd.to_pin]);
            }

            //organize-ebene: beschriftungen und rahmen wieder hinlegen
            foreach (ConstructOrganizeData od in organize)
            {
                if (GateRegistry.create(od.type) is not OrganizeItem item) continue;

                item.set_size(od.width, od.height);
                item.load_state(od.state);
                Organize.place(item, cell_x + od.x, cell_y + od.y);
            }

            //frisch verdrahtet: alles nochmal auswerten, damit der zustand stimmt
            foreach (GateBase g in placed) World.schedule(g);
            World.kick();
            return true;
        }

        /// <summary>Halbdurchsichtige vorschau (wie der gate-ghost beim bauen).</summary>
        public void draw_ghost(int cell_x, int cell_y)
        {
            Color old = Global.standart_color;
            Global.standart_color = new Color(255, 255, 255, 120);

            (int w, int h) = footprint();
            Raylib.DrawRectangleLines(cell_x * Global.cell_size, cell_y * Global.cell_size,
                                      w * Global.cell_size, h * Global.cell_size, Global.standart_color);

            foreach (ConstructGateData entry in gates)
            {
                GateBase g = make_gate(entry);
                if (g == null) continue;
                g.cell_x = cell_x + entry.x;
                g.cell_y = cell_y + entry.y;
                g.draw();
            }

            Global.standart_color = old;
        }
    }

    /// <summary>
    /// Die construct-dateien im unterordner "constructs": lesen, schreiben und
    /// aus einer auswahl erzeugen. Eine datei = ein construct
    /// (constructs/&lt;name&gt;.json).
    /// </summary>
    internal static class ConstructStore
    {
        public const string folder = "constructs";

        public static List<ConstructDef> all = new();

        static readonly JsonSerializerOptions json_options = new JsonSerializerOptions
        {
            WriteIndented = true,
        };

        static public string path_for(string name) => Path.Combine(folder, name + ".json");

        /// <summary>Alle construct-dateien einlesen (kaputte dateien werden ignoriert).</summary>
        public static void load()
        {
            all.Clear();
            if (!Directory.Exists(folder)) return;

            foreach (string path in Directory.GetFiles(folder, "*.json").OrderBy(p => p, StringComparer.Ordinal))
            {
                try
                {
                    ConstructDef def = JsonSerializer.Deserialize<ConstructDef>(File.ReadAllText(path));
                    if (def == null) continue;
                    if (def.gates == null) def.gates = new();
                    if (def.wires == null) def.wires = new();
                    if (def.organize == null) def.organize = new();
                    if (string.IsNullOrEmpty(def.name)) def.name = Path.GetFileNameWithoutExtension(path);
                    def.source_path = path;
                    all.Add(def);
                }
                catch (Exception)
                {
                    //eine defekte datei darf das spiel nicht aufhalten
                }
            }
        }

        /// <summary>Namen als dateinamen brauchbar machen (leer = unbrauchbar).</summary>
        static public string sanitize(string name)
        {
            if (name == null) return "";
            name = name.Trim();
            foreach (char bad in Path.GetInvalidFileNameChars())
                name = name.Replace(bad, '_');
            name = name.Replace('/', '_').Replace('\\', '_');
            return name.Trim();
        }

        /// <summary>Ein construct als json schreiben. Leerer name = nichts tun.</summary>
        public static bool save(ConstructDef def)
        {
            if (def == null) return false;
            def.name = sanitize(def.name);
            if (def.name.Length == 0) return false;

            def.version = ConstructDef.current_version;
            try
            {
                Directory.CreateDirectory(folder);
                File.WriteAllText(path_for(def.name), JsonSerializer.Serialize(def, json_options));
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Die id, unter der ein gate gespeichert wird.
        ///
        /// Zeigt type_id() auf einen ANDEREN typ (klassischer copy-paste-fehler
        /// beim anlegen einer neuen gate-datei, z.b. ein XOR das "AND" meldet),
        /// wuerde das construct sonst still das falsche gate speichern. Hier
        /// zaehlt deshalb der klassentyp, und der fehler wird einmal gemeldet.
        /// </summary>
        static string save_id(GateBase g)
        {
            string id = g.type_id();
            if (!string.IsNullOrEmpty(id) && GateRegistry.type_by_id(id) == g.GetType()) return id;

            Console.WriteLine($"WARNING: {g.GetType().Name}.type_id() sagt \"{id}\" - " +
                              $"gespeichert wird stattdessen \"{g.GetType().Name}\".");
            return g.GetType().Name;
        }

        /// <summary>
        /// Aus der auswahl ein construct bauen: alle gates, die VOLLSTAENDIG
        /// innerhalb liegen (die auswahl wurde vorher geprueft), mit ihrem
        /// zustand, und alle leitungen, deren beide enden mitgespeichert sind.
        /// </summary>
        public static ConstructDef capture(string name, (int x1, int y1, int x2, int y2) rect)
        {
            var def = new ConstructDef
            {
                name = sanitize(name),
                width = Math.Abs(rect.x2 - rect.x1) + 1,
                height = Math.Abs(rect.y2 - rect.y1) + 1,
            };

            //alle gates in der auswahl, stabil sortiert (das json soll gleich bleiben)
            var gate_list = new List<GateBase>();
            foreach (var kv in World.gate_grid)
                if (kv.Value is GateBase g && !gate_list.Contains(g))
                    gate_list.Add(g);

            gate_list.Sort((a, b) => a.cell_y != b.cell_y
                ? a.cell_y.CompareTo(b.cell_y)
                : a.cell_x.CompareTo(b.cell_x));

            var index_of = new Dictionary<GateBase, int>();
            foreach (GateBase g in gate_list)
            {
                if (!Selection.fully_inside(g, rect)) continue;

                index_of[g] = def.gates.Count;
                def.gates.Add(new ConstructGateData
                {
                    type = save_id(g),
                    x = g.cell_x - rect.x1,
                    y = g.cell_y - rect.y1,
                    state = g.save_state() ?? new Dictionary<string, string>(),
                });
            }

            //organize-items (beschriftungen/rahmen), die vollstaendig drin liegen
            foreach (OrganizeItem item in Organize.inside(rect))
            {
                (int iw, int ih) = item.get_cell_size();
                def.organize.Add(new ConstructOrganizeData
                {
                    type = save_id(item),
                    x = item.cell_x - rect.x1,
                    y = item.cell_y - rect.y1,
                    width = iw,
                    height = ih,
                    state = item.save_state() ?? new Dictionary<string, string>(),
                });
            }

            //leitungen nur, wenn BEIDE enden mitgespeichert sind - eine leitung
            //aus der auswahl heraus kann hier nicht wiederhergestellt werden
            foreach (Wire w in World.wires)
            {
                if (w.output == null || w.input == null) continue;
                if (w.output.gate is not GateBase from || w.input.gate is not GateBase to) continue;
                if (!index_of.TryGetValue(from, out int fi)) continue;
                if (!index_of.TryGetValue(to, out int ti)) continue;

                def.wires.Add(new ConstructWireData
                {
                    from_gate = fi,
                    from_pin = w.output.index,
                    to_gate = ti,
                    to_pin = w.input.index,
                    color = Global.clamp_color(w.color_index),
                });
            }

            return def;
        }
    }
}
