using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using Raylib_cs;

namespace Diconnect_v2
{
    public enum GlobalState
    {
        building,
        cableing,
        inspecting,
        inputting,
        saving,
        searching
    }

    /// <summary>Auf welcher seite der gate-box ein pin sitzt.</summary>
    public enum PinSide
    {
        left,
        right
    }

    internal static class Global
    {
        static public Color standart_color = Color.White;
        static public Color activecolor = Color.Red; // pins that are active

        static public int cell_size = 64; //pixels
        static public int pin_size = 16; //pixels, square (breite UND hoehe eines normalen pins)

        /// <summary>
        /// Gesamthoehe eines 8-bit-pins in pixeln (siehe <see cref="Pin.bits"/>).
        ///
        /// Ein 8-bit-pin ist EIN pin-platz, der acht bit-reihen uebereinander
        /// zeigt - genau wie ein 8-bit-kabel acht gestapelte kurven ist. Die
        /// hoehe einer reihe ist deshalb pin8_size / 8.
        ///
        /// Bewusst klein (standart 32: eine reihe ist 4px hoch) - ein 8-bit-pin
        /// soll wenig platz brauchen. Die reihenhoehe ist pin8_size / 8; steht
        /// hier dasselbe wie in <see cref="wire8_spacing"/>, treffen die
        /// leitungen eines kabels die reihen des pins genau.
        /// </summary>
        static public int pin8_size = 32;
        static public int pin8_rows => 8;

        /// <summary>
        /// Abstand zwischen den acht leitungen eines 8-bit-kabels in pixeln.
        ///
        /// Absichtlich NICHT an die reihen des pins gekoppelt (das kabel ist
        /// keine pin-zeichnung): ein kabel soll eng liegen und wenig platz
        /// brauchen (standart 4). Die acht leitungen sitzen mittig auf dem pin,
        /// reihe 0 (MSB) ganz oben; steht hier die reihenhoehe des pins
        /// (pin8_size / 8), decken sich leitungen und reihen genau.
        /// </summary>
        static public int wire8_spacing = 4;

        /// <summary>
        /// Der senkrechte versatz der kabel-reihe `bit` eines buendels aus
        /// `bits` leitungen um einen mittelpunkt - genau das, was die pins
        /// NICHT mit ihrer reihen-aufteilung machen: die leitungen liegen
        /// wire8_spacing auseinander, reihe 0 (MSB) ganz oben, und der stapel
        /// ist mittig. Bei 1 bit gibt es keinen versatz.
        /// </summary>
        public static Vector2 line_offset(int bits, int bit)
        {
            if (bits <= 1) return Vector2.Zero;
            return new Vector2(0f, (bit - (bits - 1) / 2f) * wire8_spacing);
        }

        // ---- wire colors ---------------------------------------------------------------

        /// <summary>
        /// Die farben, die eine leitung haben kann. Global und in fester
        /// reihenfolge - index-parallel zu <see cref="wire_color_names"/>:
        /// wire_colors[n] gehoert zu wire_color_names[n].
        /// </summary>
        public static readonly Color[] wire_colors =
        {
            Color.Red,     // 0
            Color.Green,   // 1
            Color.Yellow,  // 2
            Color.Blue,    // 3
            Color.Magenta, // 4
            Color.White,   // 5
        };

        /// <summary>Die namen der farben (im cabling-menue angezeigt).</summary>
        public static readonly string[] wire_color_names =
        {
            "red", "green", "yellow", "blue", "magenta", "white",
        };

        /// <summary>Die gerade gewaehlte farbe (index in wire_colors). Neue
        /// leitungen und die vorschau benutzen sie.</summary>
        public static int active_wire_color = 0;

        /// <summary>Wie eine farbe AKTIV aussieht (voll, fuer die gewaehlte).</summary>
        public static Color wire_color_of(int index) => wire_colors[clamp_color(index)];

        /// <summary>
        /// Wie eine farbe PASSIV aussieht: ausgegraut. So werden die nicht
        /// gewaehlten namen der farben-liste gezeigt - und so wird eine leitung
        /// gezeichnet, deren bit TIEF liegt (siehe Wire.draw).
        /// </summary>
        public static Color wire_color_passive(int index) => grey_out(wire_colors[clamp_color(index)]);

        /// <summary>
        /// Wie stark ausgegraut wird: 0 = die volle farbe, 1 = nur noch grau.
        /// 0.7 heisst 30% farbe + 70% dunkelgrau. Gilt fuer die passive form
        /// jeder farbe (nicht gewaehlte menue-namen und tiefe leitungen).
        /// </summary>
        public static float wire_grey_amount = 0.8f;

        /// <summary>Die aktive farbe selbst - neue leitungen und die vorschau.</summary>
        public static Color selected_wire_color => wire_color_of(active_wire_color);

        public static int clamp_color(int index) => Math.Clamp(index, 0, wire_colors.Length - 1);

        /// <summary>
        /// Eine farbe ausgrauen: 30% der farbe, 70% dunkelgrau. Dunkelgrau (statt
        /// eines hellen grau), damit auch ein helles gelb oder weiss noch klar
        /// dunkler aussieht als seine aktive form.
        /// </summary>
        public static Color grey_out(Color c)
        {
            const float grey = 70f;   // das dunkelgrau, in das geblendet wird
            float g = Math.Clamp(wire_grey_amount, 0f, 1f);
            float keep = 1f - g;
            byte mix(byte channel) => (byte)(channel * keep + grey * g);

            return new Color(mix(c.R), mix(c.G), mix(c.B), (byte)255);
        }
        static public int font_size = 32;
        static public Font font = Raylib.LoadFont("fonts/pixy.regular.ttf");

        /// <summary>Abstand zwischen den buchstaben beim text-zeichnen (standart 1).
        /// Gilt fuer ALLE texte, damit die schrift ueberall gleich laeuft.</summary>
        static public float letter_spacing = 1f;

        /// <summary>
        /// Wie weit der schreibzeiger nach diesem text steht - also die stelle,
        /// an die der naechste buchstabe (oder der blinkende cursor) gehoert.
        ///
        /// Raylibs MeasureTextEx zaehlt den buchstaben-abstand nur ZWISCHEN den
        /// zeichen, DrawTextEx rueckt aber nach jedem zeichen - auch nach dem
        /// letzten - um den abstand weiter. Gemessen: 6 zeichen mit abstand 3
        /// ergeben 15px mehr als ohne (5x3), gezeichnet wird aber 6x3. Der
        /// cursor muss deshalb eine abstandsbreite hinter dem mass stehen,
        /// sonst sitzt er im letzten zeichen. Ohne abstand aendert sich nichts.
        /// </summary>
        public static float text_advance(Font f, string text, float size)
        {
            if (string.IsNullOrEmpty(text)) return 0f;
            return Raylib.MeasureTextEx(f, text, size, letter_spacing).X + letter_spacing;
        }

        /// <summary>Die standart-raylib-schrift. Sie deckt das ganze ascii-set ab,
        /// die pixy-schrift nicht - deshalb zeichnen die anzeigen (display, ascii,
        /// digit) damit.</summary>
        static public Font display_font => Raylib.GetFontDefault();

        /// <summary>Schriftgroesse der pin-namen (hotkey tab) - bewusst klein,
        /// damit die namen ueber den pins in die gate-box passen.</summary>
        static public int pin_name_fontsize = 12;

        /// <summary>Farbe der pin-namen (hotkey tab).</summary>
        static public Color pin_name_color = Color.Orange;

        /// <summary>Farbe der markierten flaeche im speicher-modus (ctrl+s).</summary>
        static public Color selection_color = Color.Orange;

        /// <summary>Farbe der rahmen auf der organize-ebene.</summary>
        static public Color border_color = Color.SkyBlue;

        /// <summary>Schriftgroesse der beschriftungen (organize-ebene) - klein,
        /// damit ein text in die 1x1-zelle passt.</summary>
        static public int label_fontsize = 20;

        /// <summary>Zeigt die namen der pins an den pins an (hotkey tab).</summary>
        static public bool show_pin_names = false;
        static public float ticks_per_frame = 1000f;

        public static float wire_thickness = 4f;

        // ---- inventory look -----------------------------------------------------------

        public static int inventory_fontsize = 20;
        public static int inventory_line_height = 24;

        // ---- window / letterbox (16:9) ------------------------------------------------

        public static float content_offset_x = 0f;
        public static float content_offset_y = 0f;
        public static float content_scale = 1f;
        public static Color frame_color = new Color(35, 35, 35, 255); //letterbox/border-farbe

        //kamera-zoom bereich
        public static float zoom_min = 0.25f;
        public static float zoom_max = 3f;
        public static float zoom_step = 1.25f;

        /// <summary>User zoom (multiplied with the letterbox scale in the camera).</summary>
        public static float user_zoom = 1f;

        /// <summary>Compute the 16:9 letterbox for the current window size and apply it to the camera.</summary>
        public static void update_letterbox()
        {
            float w = Raylib.GetScreenWidth();
            float h = Raylib.GetScreenHeight();

            float scale = Math.Min(w / 1280f, h / 720f);
            content_scale = scale;
            content_offset_x = (w - 1280f * scale) / 2f;
            content_offset_y = (h - 720f * scale) / 2f;

            // the camera maps content-space into the letterboxed rect: offset is the
            // border size, zoom is content_scale * user_zoom. That way mouse -> world
            // conversions stay a single GetScreenToWorld2D call.
            camera.Offset = new Vector2(content_offset_x, content_offset_y);
            if (camera.Zoom <= content_scale || user_zoom != camera.Zoom / content_scale)
                camera.Zoom = content_scale * user_zoom;
        }

        /// <summary>Window -> letterboxed content coordinates.</summary>
        public static Vector2 to_content(Vector2 window_pos)
        {
            return new Vector2((window_pos.X - content_offset_x) / content_scale,
                               (window_pos.Y - content_offset_y) / content_scale);
        }

        /// <summary>Content -> window coordinates.</summary>
        public static Vector2 to_window(Vector2 content_pos)
        {
            return new Vector2(content_pos.X * content_scale + content_offset_x,
                               content_pos.Y * content_scale + content_offset_y);
        }

        public static bool point_in_content(Vector2 window_pos)
        {
            return window_pos.X >= content_offset_x && window_pos.X <= content_offset_x + 1280f * content_scale &&
                   window_pos.Y >= content_offset_y && window_pos.Y <= content_offset_y + 720f * content_scale;
        }

        // ---- state machine -----------------------------------------------------------

        public static GlobalState state = GlobalState.building;

        /// <summary>
        /// Spectate-modus (f1): die schaltung laeuft, aber es ist keine ui da -
        /// nichts wird gebaut, nichts markiert, kein menue gezeigt. Nur lever und
        /// uhren lassen sich bedienen (siehe Program.update_spectating); esc geht
        /// zurueck ins bauen.
        ///
        /// Bewusst NICHT ein wert von <see cref="state"/>: der spectate-modus legt
        /// nur etwas ueber den zustand (state bleibt building), so kehren die
        /// modi nach dem ausschalten von selbst wieder in ihren zustand zurueck.
        /// </summary>
        public static bool spectating = false;

        // ---- inventory selection --------------------------------------------------

        public static Type selected_gate;   // native gate type that would be placed
        public static object selected_item; // Type (gate) ODER ConstructDef - was platziert wird
        public static int current_page = 0;

        // ---- cableing ---------------------------------------------------------------

        public static Pin cable_start;      // first clicked pin while cableing
        public static Pin cable_hover;      // pin under mouse while cableing

        //das cable-werkzeug ist kein inventar-eintrag mehr: es wird per hotkey
        //(c) an-/ausgeschaltet und ersetzt den gate-ghost waehrend es aktiv ist
        public static bool cable_tool_active = false;

        /// <summary>
        /// Kabelt der user gerade? Das ist entweder ein angefangenes kabel
        /// (state cableing) oder das eingeschaltete kabel-werkzeug - beides
        /// zeigt die farben-liste statt des inventars.
        /// </summary>
        public static bool in_connecting_mode => state == GlobalState.cableing || cable_tool_active;

        /// <summary>
        /// Das kabel-werkzeug aufgeben und zurueck ins bauen (esc): das
        /// angefangene kabel wird vergessen UND das werkzeug geht aus - sonst
        /// bliebe die farben-liste stehen, und esc kaeme aus dem kabel-modus
        /// nicht mehr heraus.
        /// </summary>
        public static void leave_connecting_mode()
        {
            cable_start = null;
            cable_hover = null;
            cable_tool_active = false;
            state = GlobalState.building;
        }

        // ---- inspecting ---------------------------------------------------------------

        public static GateBase inspected;
        public static GateBase dragged;
        public static Vector2 drag_offset;

        // ---- text input (GlobalState.inputting) ----------------------------------------

        /// <summary>Was der user bisher getippt hat (nur waehrend inputting).</summary>
        public static string input_text = "";

        /// <summary>true = "nur zahlen": ziffern, ein dezimaltrenner, fuehrendes minus.
        /// false = der user darf alles tippen.</summary>
        public static bool input_numeric = true;

        /// <summary>true = nur eine frage (enter = ja, esc = nein): es wird nichts
        /// getippt und kein cursor gezeigt - siehe begin_confirm.</summary>
        public static bool input_readonly = false;

        /// <summary>Kurze beschriftung ueber dem getippten text (leer = keine).</summary>
        public static string input_prompt = "";

        /// <summary>Wird bei Enter mit dem getippten text aufgerufen; Esc uebernimmt nichts.</summary>
        public static Action<string> input_commit;

        /// <summary>Wird bei Esc aufgerufen (optional) - z.b. um eine frisch
        /// platzierte, noch namenlose beschriftung wieder zu entfernen.</summary>
        public static Action input_cancel;

        /// <summary>Modus, in den eine text-eingabe nach enter/esc zurueckkehrt
        /// (standart building - der speicher-modus fragt z.b. nach einem namen).</summary>
        public static GlobalState input_return_state = GlobalState.building;

        /// <summary>Inventar aus, tastatur an: der user tippt einen wert ein.</summary>
        public static void begin_input(bool numeric, string initial, string prompt, Action<string> commit)
        {
            begin_input(numeric, initial, prompt, commit, null);
        }

        /// <summary>Wie oben, zusaetzlich mit einem aufraeumen bei Esc.</summary>
        public static void begin_input(bool numeric, string initial, string prompt, Action<string> commit, Action cancel)
        {
            input_text = initial ?? "";
            input_numeric = numeric;
            input_readonly = false;
            input_prompt = prompt ?? "";
            input_commit = commit;
            input_cancel = cancel;
            input_return_state = state;   //nach enter/esc dorthin zurueck
            state = GlobalState.inputting;
        }

        /// <summary>
        /// Eine frage statt einer eingabe: enter = ja, esc = nein. Im feld steht
        /// nur der text der frage (z.b. "delete? yes [enter] no [esc]"), es wird
        /// nichts getippt und kein cursor gezeichnet.
        /// </summary>
        public static void begin_confirm(string prompt, Action on_yes)
        {
            begin_input(numeric: false, initial: "", prompt: prompt,
                        commit: _ => on_yes?.Invoke());
            input_readonly = true;
        }

        /// <summary>Eingabe beenden (enter uebernimmt/wird vom aufrufer gemacht, esc verwirft) -> vorheriger modus.</summary>
        public static void end_input()
        {
            input_text = "";
            input_prompt = "";
            input_commit = null;
            input_cancel = null;
            input_readonly = false;
            state = input_return_state;
            input_return_state = GlobalState.building;
        }

        /// <summary>Darf dieses zeichen ins eingabefeld? Im zahlen-modus wird alles
        /// ausser ziffern, einem dezimaltrenner und einem fuehrenden minus verworfen.</summary>
        public static bool input_accepts(char ch)
        {
            if (input_readonly) return false;   //nur eine frage, nichts zum tippen
            if (!input_numeric) return true;
            if (char.IsDigit(ch)) return true;
            if (ch == '.' || ch == ',') return !input_text.Contains('.') && !input_text.Contains(',');
            if (ch == '-') return input_text.Length == 0;
            return false;
        }

        // ---- camera ---------------------------------------------------------------

        public static Camera2D camera = new Camera2D
        {
            Zoom = 1f,
            Target = new Vector2(0, 0),
            Offset = new Vector2(0, 0)
        };
        public static float cam_speed = 400f;

        /// <summary>
        /// Wie viel schneller die kamera mit shift laeuft (faktor auf
        /// <see cref="cam_speed"/>): shift + pfeiltaste = 4x so schnell.
        /// </summary>
        public static float cam_speed_fast = 4f;

        public static (int cell_x, int cell_y) cell_at(Vector2 world_pos)
        {
            return ((int)Math.Floor(world_pos.X / cell_size),
                    (int)Math.Floor(world_pos.Y / cell_size));
        }

        /// <summary>
        /// Stufenloses zoomen: so viele <see cref="zoom_step"/>-schritte pro sekunde,
        /// solange shift die (I)/(O) taste unten haelt. 4 heisst: in einer viertel
        /// sekunde ein ganzer schritt - dasselbe tempo wie ein einzelner druck, nur
        /// ueber die frames verteilt, damit das bild gleitet statt zu springen.
        /// </summary>
        public static float zoom_smooth_steps_per_second = 4f;

        /// <summary>
        /// Set the user zoom level, keeping the point under the cursor still
        /// (raylib zoom-to-cursor pattern). Clamps into zoom_min/zoom_max.
        /// Returns true if the level actually moved (false at the limits).
        /// </summary>
        public static bool camera_zoom_to(float wanted)
        {
            float old_user = user_zoom;
            user_zoom = Math.Clamp(wanted, zoom_min, zoom_max);
            if (old_user == user_zoom) return false;

            //welt-punkt unterm mauszeiger halten:
            Vector2 mouse = Raylib.GetMousePosition();
            Vector2 before = Raylib.GetScreenToWorld2D(mouse, camera);

            camera.Zoom = content_scale * user_zoom;   //Offset bleibt der briefkasten-rand

            Vector2 after = Raylib.GetScreenToWorld2D(mouse, camera);
            camera.Target += before - after;
            return true;
        }

        /// <summary>
        /// Zoom in/out around the mouse position, one whole <see cref="zoom_step"/> at a
        /// time - this is what a press of (I)/(O) does. `dir` +1 in, -1 out.
        /// Returns true if a zoom step was applied.
        /// </summary>
        public static bool camera_zoom_step(float dir)
        {
            if (dir == 0) return false;
            return camera_zoom_to(dir > 0 ? user_zoom * zoom_step : user_zoom / zoom_step);
        }

        /// <summary>
        /// Stufenloses zoomen fuer gehaltene tasten: `dir` +1 rein, -1 raus, `dt` die
        /// sekunden seit dem letzten frame. Es wird nur ein *bruchteil* eines schrittes
        /// gezoomt - genau das macht die bewegung glatt.
        /// Returns true if the zoom moved.
        /// </summary>
        public static bool camera_zoom_smooth(float dir, float dt)
        {
            if (dir == 0 || dt <= 0f) return false;

            float factor = MathF.Pow(zoom_step, dir * zoom_smooth_steps_per_second * dt);
            return camera_zoom_to(user_zoom * factor);
        }

        public static Rectangle camera_rect(Camera2D cam)
        {
            Vector2 tl = Raylib.GetScreenToWorld2D(new Vector2(0, 0), cam);
            Vector2 br = Raylib.GetScreenToWorld2D(
                new Vector2(Raylib.GetScreenWidth(), Raylib.GetScreenHeight()), cam);
            return new Rectangle(tl.X, tl.Y, br.X - tl.X, br.Y - tl.Y);
        }

        public static bool rect_on_screen(Rectangle r, Camera2D cam)
        {
            return Raylib.CheckCollisionRecs(r, camera_rect(cam));
        }

        public static bool point_on_screen(Vector2 p, Camera2D cam)
        {
            return Raylib.CheckCollisionPointRec(p, camera_rect(cam));
        }

        // ---- pins ------------------------------------------------------------------

        /// <summary>
        /// Shared math so drawing and hit-testing agree: rect of a pin on a gate
        /// boxed (cell_x*cell_size, cell_y*cell_size) of size (w*h cells).
        ///
        /// heights ist die hoehe JEDER pin-platzes auf DIESER seite (Grid.pin_size
        /// fuer einen normalen pin, Global.pin8_size fuer einen 8-bit-pin), slot
        /// der platz darin (0 = oben) - die pins werden damit von oben nach unten
        /// verteilt. Sind alle hoehen gleich, ist das genau die alte rechnung.
        ///
        /// Ueblicherweise liegt jeder pin auf seiner seite (eingang links,
        /// ausgang rechts); gates duerfen aber beide seiten gleich setzen - dann
        /// liegen eingang und ausgang auf DERSELBEN seite und teilen sich deren
        /// stapel (siehe GateBase.pins_on).
        /// </summary>
        public static Rectangle pin_rect(int cell_x, int cell_y, int width_cells, int height_cells, int[] heights, int slot, PinSide side)
        {
            int whole_height = height_cells * cell_size;

            int total = 0;
            for (int i = 0; i < heights.Length; i++) total += heights[i];

            float pin_distance = (whole_height - total) / (float)(heights.Length + 1);

            int y = cell_y * cell_size + (int)pin_distance * (slot + 1);
            for (int i = 0; i < slot; i++) y += heights[i];

            int x = side == PinSide.left ? cell_x * cell_size - pin_size
                                         : (cell_x + width_cells) * cell_size;
            return new Rectangle(x, y, pin_size, heights[slot]);
        }

        /// <summary>
        /// Die reihe eines gestapelten pins: ein 8-bit-pin (oder sein kabel) wird
        /// in `bits` gleich hohe reihen geteilt, reihe 0 ist die oberste (MSB).
        /// Bei einem normalen pin kommt genau r zurueck.
        /// </summary>
        public static Rectangle bit_row(Rectangle r, int index, int bits)
        {
            if (bits <= 1) return r;
            float h = r.Height / bits;
            return new Rectangle(r.X, r.Y + index * h, r.Width, h);
        }

        // ---- tick accumulator ---------------------------------------------------------

        public static float tick_accumulator = 0f;

        /// <summary>
        /// Returns how many ticks run THIS frame. Fractional ticks_per_frame lets
        /// one tick stretch across multiple frames (e.g. 0.5f = 1 tick every 2 frames).
        /// </summary>
        public static int ticks_this_frame()
        {
            tick_accumulator += ticks_per_frame;
            int ticks = (int)tick_accumulator;
            if (ticks > 0) tick_accumulator -= ticks;
            return ticks;
        }

        /// <summary>Size of a gate box: fits the name, min 1 cell.</summary>
        public static (int width, int height) measure_gate_cells(int num_inputs, int num_outputs, string name)
        {
            var m = Raylib.MeasureTextEx(font, name, font_size, letter_spacing);
            int width = Math.Max(1, (int)Math.Ceiling(m.X / cell_size) + 1);   // +1 cell padding
            return (width, 1);
        }

        static public void draw_common(int cell_x, int cell_y, int width_cells, int height_cells, int num_inputs, int num_outputs, string name, Pin[]? inputs = null, Pin[]? outputs = null)
        {
            Raylib.DrawRectangleLines(cell_x * cell_size, cell_y * cell_size, width_cells * cell_size, height_cells * cell_size, standart_color);
            Raylib.DrawTextEx(font, name, new Vector2(cell_x * cell_size + 8, cell_y * cell_size + 8), font_size, letter_spacing, standart_color);

            //die pins zeichnen: rot wenn aktiv, sonst weiss. Ein 8-bit-pin zeigt
            //seine acht bits als gestapelte reihen. Die lage kommt aus Pin.rect()
            //(dieselbe rechnung, mit der ein pin getroffen wird) - auch bei gates,
            //deren pins beide auf DERSELBEN seite liegen.
            for (int i = 0; i < num_inputs; i++)
            {
                Pin? p = pin_or_null(inputs, i);
                draw_pin_stack(p, pin_rect_of(p, cell_x, cell_y, width_cells, height_cells, num_inputs, i, is_input: true));
            }

            for (int i = 0; i < num_outputs; i++)
            {
                Pin? p = pin_or_null(outputs, i);
                draw_pin_stack(p, pin_rect_of(p, cell_x, cell_y, width_cells, height_cells, num_outputs, i, is_input: false));
            }

            //pin-namen (hotkey tab): der name steht mittig auf dem pin selbst.
            //Im spectate-modus (f1) bleibt er weg - das ist ui.
            if (show_pin_names && !spectating)
            {
                for (int i = 0; i < num_inputs; i++)
                    draw_pin_name(pin_or_null(inputs, i));
                for (int i = 0; i < num_outputs; i++)
                    draw_pin_name(pin_or_null(outputs, i));
            }
        }

        /// <summary>Der pin an index i der liste (oder null).</summary>
        static Pin? pin_or_null(Pin[]? pins, int index)
        {
            return pins != null && index >= 0 && index < pins.Length ? pins[index] : null;
        }

        /// <summary>
        /// Das rechteck eines pins. Liegt das pin-objekt vor, rechnet es sein
        /// rechteck selbst aus (Pin.rect) - dieselbe eine rechnung wie beim
        /// treffen. Ohne pin-objekt bleibt die alte verteilung (eingang links,
        /// ausgang rechts, jeder pin pin_size hoch).
        /// </summary>
        static Rectangle pin_rect_of(Pin? pin, int cell_x, int cell_y, int width_cells, int height_cells, int count, int index, bool is_input)
        {
            if (pin != null) return pin.rect();

            var heights = new int[count];
            for (int i = 0; i < count; i++) heights[i] = pin_size;
            return pin_rect(cell_x, cell_y, width_cells, height_cells, heights, index,
                            is_input ? PinSide.left : PinSide.right);
        }

        /// <summary>Den namen eines pins klein auf den pin zeichnen.</summary>
        static void draw_pin_name(Pin? pin)
        {
            if (pin == null || string.IsNullOrEmpty(pin.name)) return;

            Raylib.DrawTextEx(font, pin.name, pin_name_pos(pin.rect(), pin.name),
                              pin_name_fontsize, letter_spacing, pin_name_color);
        }

        /// <summary>
        /// Position (linke obere ecke) des pin-namens: der name steht genau
        /// ueber dem pin, also mittig auf dessen x- und y-mitte (der name liegt
        /// damit auf dem pin selbst). Gemeinsame mathematik mit dem zeichnen,
        /// wie pin_rect, damit beide immer uebereinstimmen.
        /// </summary>
        public static Vector2 pin_name_pos(Rectangle r, string text)
        {
            Vector2 m = Raylib.MeasureTextEx(font, text, pin_name_fontsize, letter_spacing);

            return new Vector2(r.X + (r.Width - m.X) / 2f,
                               r.Y + (r.Height - m.Y) / 2f);
        }

        /// <summary>
        /// Einen ganzen pin zeichnen: ein normaler pin ist ein quadrat, ein
        /// 8-bit-pin eine reihe von acht (jede reihe mit dem pegel ihres bits).
        /// </summary>
        static public void draw_pin_stack(Pin? pin, Rectangle r)
        {
            int bits = pin != null ? pin.bits : 1;
            for (int bit = 0; bit < bits; bit++)
                draw_pin(bit_row(r, bit, bits), pin != null && pin.bit(bit));
        }

        /// <summary>Draw one pin filled with its activity color (activecolor=red when active, white when not).</summary>
        static public void draw_pin(Rectangle r, bool active)
        {
            Raylib.DrawRectangle((int)r.X, (int)r.Y, (int)r.Width, (int)r.Height,
                                 active ? activecolor : standart_color);
        }
    }
}
