using Diconnect_v2;
using Raylib_cs;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;

namespace HelloWorld;

internal static class Program
{
    //16:9 reference resolution of the letterboxed content area
    const float CONTENT_W = 1280f;
    const float CONTENT_H = 720f;

    // inspecting-mode bookkeeping
    static List<GateBase> inspected_set = new();

    static void Main()
    {
        Raylib.SetConfigFlags(ConfigFlags.ResizableWindow);
        Raylib.InitWindow(1280, 720, "Diconnect_v2");
        Raylib.SetTargetFPS(60);
        Raylib.SetWindowMinSize(640, 360);

        GateRegistry.init();
        Inventory.init();
        SaveTools.init();
        Global.update_letterbox();

        //esc gehoert den modi (abbrechen) und darf das fenster nicht schliessen
        Raylib.SetExitKey(KeyboardKey.Null);

       // seed_world();

        while (!Raylib.WindowShouldClose())
        {
            Global.update_letterbox();

            // user input happens between ticks
            update_camera();
            update_modes();

            // per-frame sim: uhren toggeln in echtzeit, unabhaengig von ticks_per_frame
            World.frame_update_all(Raylib.GetFrameTime());

            // simulation: Global.ticks_per_frame decides how many ticks per frame
            int ticks = Global.ticks_this_frame();
            for (int i = 0; i < ticks; i++) World.tick();

            draw_frame();
        }

        Raylib.CloseWindow();
    }

    static void seed_world()
    {
        World.place(GateRegistry.create("LEVER"), 2, 2);
        World.place(GateRegistry.create("AND"), 6, 2);
        World.place(GateRegistry.create("NOT"), 6, 4);
        World.place(GateRegistry.create("OR"), 10, 3);
        World.place(GateRegistry.create("LAMP"), 6, 6);
    }

    // ---- mouse coords ----------------------------------------------------------------

    /// <summary>Mouse in window pixels.</summary>
    static Vector2 mouse_window() => Raylib.GetMousePosition();

    /// <summary>Mouse in world-space (letterbox handled inside the camera).</summary>
    static Vector2 mouse_world() => Raylib.GetScreenToWorld2D(mouse_window(), Global.camera);

    // ---- camera -------------------------------------------------------------------

    static void update_camera()
    {
        //waehrend einer text-eingabe (oder der suche) wird nicht gescrollt/gezoomt:
        //sonst waeren pfeiltasten/i/o gleichzeitig kamerasteuerung und eingabe -
        //in der suche blaettern die pfeiltasten durch die treffer-liste
        if (Global.state == GlobalState.inputting || Global.state == GlobalState.searching) return;

        //shift ist der "mehr dampf"-knopf der kamera: die pfeile laufen schneller
        //(siehe Global.cam_speed_fast) und (I)/(O) zoomen stufenlos statt in
        //schritten. einmal abgefragt, damit beide dasselbe lesen.
        bool shift = Raylib.IsKeyDown(KeyboardKey.LeftShift) || Raylib.IsKeyDown(KeyboardKey.RightShift);

        Vector2 v = new Vector2();
        if (Raylib.IsKeyDown(KeyboardKey.Up)) v.Y -= 1;
        if (Raylib.IsKeyDown(KeyboardKey.Down)) v.Y += 1;
        if (Raylib.IsKeyDown(KeyboardKey.Left)) v.X -= 1;
        if (Raylib.IsKeyDown(KeyboardKey.Right)) v.X += 1;
        if (v != Vector2.Zero)
        {
            //mit shift laeuft die kamera schneller (wie viel, steht in
            //Global.cam_speed_fast) - fuer weite wege in grossen schaltungen
            float speed = Global.cam_speed;
            if (shift) speed *= Global.cam_speed_fast;

            Global.camera.Target += Vector2.Normalize(v) * speed * Raylib.GetFrameTime();
        }

        //zoom: i rein, o raus (an der mausposition). Das sind zwei getrennte
        //arten zu zoomen, und shift waehlt zwischen ihnen:
        //- ohne shift: ein druck zoomt genau einen schritt, die taste liegen zu
        //  lassen aendert nichts (wie bisher)
        //- mit shift: es zoomt stufenlos, solange die taste liegt - der shift-druck
        //  selbst zoomt NUR den bruchteil eines frames. Sonst gaebe es beim
        //  anfassen erst einen ganzen sprung und danach das gleiten.
        if (shift)
        {
            float dt = Raylib.GetFrameTime();
            if (Raylib.IsKeyDown(KeyboardKey.I)) Global.camera_zoom_smooth(+1, dt);
            if (Raylib.IsKeyDown(KeyboardKey.O)) Global.camera_zoom_smooth(-1, dt);
        }
        else
        {
            if (Raylib.IsKeyPressed(KeyboardKey.I)) Global.camera_zoom_step(+1);
            if (Raylib.IsKeyPressed(KeyboardKey.O)) Global.camera_zoom_step(-1);
        }
    }

    // ---- modes ---------------------------------------------------------------------

    static void update_modes()
    {
        // text-eingabe ist modal: kein inventar, keine welt-klicks, keine hotkeys.
        // esc bricht ab, enter uebernimmt (siehe update_inputting) - hier also
        // frueh raus, damit z.b. "c" nicht das cable-werkzeug umschaltet.
        if (Global.state == GlobalState.inputting)
        {
            update_inputting();
            return;
        }

        //die inventar-suche (ctrl+f) ist genauso modal: sie liest ihre eigene
        //tastatur (tippen, pfeile, mausrad) und geht mit esc/enter/klick ins bauen
        if (Global.state == GlobalState.searching)
        {
            update_searching();
            return;
        }

        Vector2 wp = mouse_world();

        // f1 schaltet den spectate-modus an/aus (siehe toggle_spectate). Das
        // steht VOR allem anderen, damit man aus jedem modus hinein kommt -
        // auch aus dem speichern oder mitten aus einem kabel.
        if (Raylib.IsKeyPressed(KeyboardKey.F1)) { toggle_spectate(); return; }

        // im spectate-modus gibt es nichts zu bauen: nur lever und uhren lassen
        // sich bedienen, esc geht zurueck ins bauen (siehe update_spectating)
        if (Global.spectating) { update_spectating(wp); return; }

        // ctrl+s schaltet den speicher-modus an/aus. Das passiert VOR der
        // uebrigen tastatur-auswertung und kehrt direkt zurueck: sonst wuerde
        // dasselbe "s" gleichzeitig das menue verschieben.
        bool ctrl = Raylib.IsKeyDown(KeyboardKey.LeftControl) || Raylib.IsKeyDown(KeyboardKey.RightControl);

        // ctrl+f oeffnet die inventar-suche - wie ctrl+s aus jedem modus heraus
        if (ctrl && Raylib.IsKeyPressed(KeyboardKey.F))
        {
            enter_search();
            return;
        }

        if (ctrl && Raylib.IsKeyPressed(KeyboardKey.S))
        {
            if (Global.state == GlobalState.saving) leave_saving();
            else enter_saving();
            return;
        }

        // tab zeigt die pin-namen an den pins an/aus
        if (Raylib.IsKeyPressed(KeyboardKey.Tab)) Global.show_pin_names = !Global.show_pin_names;

        // hotkey c toggelt das cable-werkzeug an/aus (kein inventar-eintrag mehr).
        // im cableing-modus bleibt es an, esc beendet beide zustaende.
        // im speicher-modus gibt es nur die werkzeuge.
        if (Global.state != GlobalState.saving &&
            Raylib.IsKeyPressed(KeyboardKey.C) && Global.state != GlobalState.cableing)
            Global.cable_tool_active = !Global.cable_tool_active;

        bool cable_mode = Global.cable_tool_active;
        bool over_inventory = Global.state == GlobalState.building &&
                              Inventory.contains_window(mouse_window(), Global.content_offset_x,
                                                        Global.content_offset_y, Global.content_scale);

        //esc gehoert hier her (und nicht in die einzelnen modi):
        //  kabeln   -> das kabel-werkzeug aufgeben (halbfertiges kabel UND
        //              farben-liste), zurueck ins bauen. Das gilt fuer beide
        //              zustaende des kabelns (angefangenes kabel oder nur das
        //              werkzeug an) - sonst bliebe man im gewaehlten kabel-modus.
        //  saving   -> zurueck ins bauen
        //  sonst    -> ein laufendes ziehen/markieren abbrechen
        if (Raylib.IsKeyPressed(KeyboardKey.Escape))
        {
            if (Global.in_connecting_mode) cancel_cableing();
            else if (Global.state == GlobalState.saving) leave_saving();
            else end_inspecting();
        }

        switch (Global.state)
        {
            case GlobalState.building:
                //mit dem kabel-werkzeug waehlt w/s die leitungs-farbe, sonst das inventar
                if (cable_mode) ColorMenu.do_input();
                else Inventory.do_input(mouse_window(), Global.content_offset_x, Global.content_offset_y, Global.content_scale);
                update_building(wp, over_inventory, cable_mode);
                break;
            case GlobalState.cableing:
                ColorMenu.do_input();   //die farben-liste steht hier statt des inventars
                update_cableing(wp);
                break;
            case GlobalState.inspecting: update_inspecting(wp); break;
            case GlobalState.saving: update_saving(wp); break;
        }

        Global.selected_item = Inventory.get_selected_entry();
        Global.selected_gate = Inventory.get_selected_type();

        //ein offener rahmen gehoert zu dem eintrag, mit dem er begonnen wurde:
        //waehlt der user etwas anderes im inventar, wird er verworfen
        Organize.keep_item(Global.selected_item);
    }

    // ---- speichern (saving) ---------------------------------------------------------

    /// <summary>Ctrl+S: werkzeug-menue statt inventar, esc fuehrt zurueck.</summary>
    static void enter_saving()
    {
        //einen laufenden drag/markieren zuerst abbrechen: sonst bliebe ein
        //gate "in der luft" (es ist beim ziehen aus dem grid genommen)
        end_inspecting();
        Selection.cancel_move();            //ein angefangenes verschieben faellt weg
        Global.cable_tool_active = false;   //kein kabel-werkzeug im speicher-modus
        Global.cable_start = null;
        Organize.reset_marker();            //ein offener rahmen wird hier nicht weitergefuehrt
        Global.state = GlobalState.saving;
    }

    static void leave_saving()
    {
        Selection.cancel_move();
        Global.state = GlobalState.building;
    }

    // ---- inventar-suche (ctrl+f) -----------------------------------------------------

    /// <summary>
    /// Ctrl+F: die suche oeffnen. Wie der speicher-modus laesst sie liegen, was
    /// gerade laeuft (ein gezogenes gate, eine markierung, das kabel-werkzeug) -
    /// schliesslich soll danach das inventar mit dem gewaehlten eintrag zu sehen
    /// sein.
    /// </summary>
    static void enter_search()
    {
        end_inspecting();                   //bricht auch ein laufendes ziehen ab
        Selection.cancel_move();
        Global.cable_tool_active = false;   //sonst stuende nach der suche die farben-liste da
        Global.cable_start = null;
        Global.cable_hover = null;
        Organize.reset_marker();
        Search.begin();
    }

    /// <summary>
    /// Die suche: tippen filtert die inventar-liste (ohne seiten-grenze), pfeile
    /// hoch/runter und das mausrad blaettern durch die treffer, enter uebernimmt
    /// den gewaehlten eintrag, ein linksklick auf eine zeile genau diesen, esc
    /// (oder ein klick daneben) geht zurueck ins bauen. Das uebernehmen setzt die
    /// inventar-auswahl - seite und zeile ergeben sich aus dem eintrag.
    /// </summary>
    static void update_searching()
    {
        Search.Result result = Search.do_input(mouse_window(), Global.content_offset_x, Global.content_offset_y);

        if (result == Search.Result.choose) Search.choose();
        if (result != Search.Result.none) Search.close();
    }

    /// <summary>
    /// Das werkzeug-menue benutzt sich wie das inventar; ein linksklick in die
    /// welt wendet das gewaehlte werkzeug an (mark all / marker / save).
    /// Klicks auf dem menue selbst werden geschluckt, damit man nicht
    /// versehentlich eine ecke setzt.
    /// </summary>
    static void update_saving(Vector2 wp)
    {
        SaveTools.do_input();

        if (SaveTools.contains_window(mouse_window(), Global.content_offset_x,
                                      Global.content_offset_y, Global.content_scale))
            return;

        //ziehen der markierten flaeche: wer IN der auswahl links drueckt und dann
        //zieht, verschiebt alles darin - gates mit ihren leitungen, beschriftungen
        //und rahmen (siehe Selection.move_region). Ohne bewegung war es ein
        //normaler werkzeug-klick; der kommt erst beim LOSLASSEN zurueck, damit ein
        //klick die flaeche nicht schon beim druecken wegschiebt oder loescht.
        Selection.DragResult drag = Selection.handle_drag(wp);
        if (drag == Selection.DragResult.dragging) return;

        if (drag == Selection.DragResult.clicked || Raylib.IsMouseButtonPressed(MouseButton.Left))
        {
            (int cx, int cy) = Global.cell_at(wp);
            SaveTools.use(cx, cy);
        }
    }

    // ---- spectate (f1) -------------------------------------------------------------

    /// <summary>
    /// F1: in den spectate-modus und wieder heraus. Beim betreten bleibt liegen,
    /// was gerade laeuft (ein gezogenes gate, ein halbes kabel, die markierung im
    /// speicher-modus) - der modus ist nur zum zuschauen und bedienen da.
    /// </summary>
    static void toggle_spectate()
    {
        if (Global.spectating) { leave_spectate(); return; }

        end_inspecting();                 //bricht auch ein laufendes ziehen ab
        Selection.cancel_move();
        Organize.reset_marker();
        Global.leave_connecting_mode();   //kabel-werkzeug aus, zustand = building
        Global.spectating = true;
    }

    /// <summary>Zurueck ins bauen (esc im spectate-modus oder f1).</summary>
    static void leave_spectate()
    {
        Global.spectating = false;
        Global.state = GlobalState.building;
    }

    /// <summary>
    /// Der spectate-modus: die schaltung laeuft weiter (uhren ticken, der tick
    /// laeuft in der hauptschleife), aber es wird nichts gebaut und keine ui
    /// gezeigt. Bedienen laesst sich nur, was auch ohne bauen geht: ein lever
    /// kippt, eine uhr fragt nach ihrer rate.
    ///
    /// Beide maus-tasten bedienen hier, weil es sonst nichts zu klicken gibt -
    /// links markiert ja nichts mehr. Esc (oder f1) geht zurueck ins bauen.
    /// </summary>
    static void update_spectating(Vector2 wp)
    {
        if (Raylib.IsKeyPressed(KeyboardKey.Escape)) { leave_spectate(); return; }

        if (Raylib.IsMouseButtonPressed(MouseButton.Left) ||
            Raylib.IsMouseButtonPressed(MouseButton.Right))
            spectate_use(wp);
    }

    /// <summary>
    /// Die eine bedienung, die der spectate-modus kennt: ein lever kippt, eine
    /// uhr fragt nach ihrer rate. Eigene methode, damit die auswahl (welches gate
    /// auf diesen klick hoert) ohne echten maus-zustand pruefbar ist.
    /// </summary>
    static void spectate_use(Vector2 wp)
    {
        GateBase g = World.gate_at(wp);
        if (g is LEVER lever) { lever.toggle(); return; }
        if (g is CLOCK clock) ask_clock_rate(clock, fresh: false);
    }

    // ---- text input (inputting) -----------------------------------------------------

    /// <summary>
    /// Zwischen den ticks: zeichen einsammeln, backspace loescht, enter
    /// uebernimmt den text, esc verwirft ihn. Der cursor wird nur gezeichnet.
    /// </summary>
    static void update_inputting()
    {
        int c;
        while ((c = Raylib.GetCharPressed()) > 0)
        {
            if (c < 32) continue;   //steuerzeichen (enter, esc, backspace) kommen nicht als text
            char ch = (char)c;
            if (Global.input_accepts(ch)) Global.input_text += ch;
        }

        if (Raylib.IsKeyPressed(KeyboardKey.Backspace) && Global.input_text.Length > 0)
            Global.input_text = Global.input_text.Substring(0, Global.input_text.Length - 1);

        if (Raylib.IsKeyPressed(KeyboardKey.Enter) || Raylib.IsKeyPressed(KeyboardKey.KpEnter))
        {
            //vor end_input() merken - das raeumt den callback ab
            Action<string> commit = Global.input_commit;
            string typed = Global.input_text;
            Global.end_input();
            commit?.Invoke(typed);
            return;
        }

        if (Raylib.IsKeyPressed(KeyboardKey.Escape))
        {
            //abbrechen: es wird nichts uebernommen (eine frisch platzierte
            //beschriftung raeumt ihr cancel-callback wieder weg)
            Action cancel = Global.input_cancel;
            Global.end_input();
            cancel?.Invoke();
            return;
        }
    }

    /// <summary>Fragt nach der tick-rate einer uhr (zahlen-eingabe).</summary>
    static void ask_clock_rate(CLOCK clock, bool fresh)
    {
        string current = clock.hz.ToString("0.##", CultureInfo.InvariantCulture);
        string prompt = fresh ? "ticks per second:" : "ticks per second (now " + current + "):";
        string initial = fresh ? "" : current;

        Global.begin_input(numeric: true, initial: initial, prompt: prompt,
                           commit: text => clock.set_rate(text));
    }

    /// <summary>
    /// Fragt nach der zahl einer 32-bit-konstante (dieselbe zahlen-eingabe wie
    /// bei der taktrate einer uhr). Ins feld passen nur ziffern, EIN trennzeichen
    /// und ein fuehrendes minus - '.' und ',' sind beide der dezimaltrenner
    /// (Global.input_accepts und CONST32.set_value lesen sie so).
    ///
    /// Beim erneuten fragen steht der jetzige wert im feld, und zwar mit ALLEN
    /// stellen (format_exact): enter ohne aenderung laesst die zahl also genau
    /// so, wie sie war.
    /// </summary>
    static void ask_const_value(CONST32 constant, bool fresh)
    {
        string current = Number32.format_exact(Number32.value_of(constant.raw, true));
        string prompt = fresh ? "number:" : $"number (now {current}):";
        string initial = fresh ? "" : current;

        Global.begin_input(numeric: true, initial: initial, prompt: prompt,
                           commit: text => constant.set_value(text));
    }

    static void update_building(Vector2 wp, bool over_inventory, bool cable_mode)
    {
        if (over_inventory)
        {
            //das inventar ist rein ein overlay: platzieren/umschalten funktionieren
            //weiterhin, nur der pin-hover-highlighting wird unterdrueckt
            Global.cable_hover = null;
        }
        else
        {
            //nur mit dem cable-werkzeug bekommen pins die hover-farbe
            Global.cable_hover = cable_mode || Global.state == GlobalState.cableing
                ? World.pin_at(wp)
                : null;
        }

        // left click: mark gate and enter inspecting mode
        // (das inventar verbraucht keine klicks - links-klicks wirken ueberall in der welt,
        //  auch dort wo die liste gerade liegt)
        if (Raylib.IsMouseButtonPressed(MouseButton.Left))
        {
            GateBase clicked = World.gate_at(wp);

            //organize-items lassen sich genauso markieren: ziehen verschiebt sie,
            //T loescht sie (ein gate darunter hat vorrang)
            if (clicked == null) clicked = Organize.at(wp);

            if (clicked != null)
            {
                inspected_set.Clear();
                inspected_set.Add(clicked);
                Global.inspected = clicked;
                Global.state = GlobalState.inspecting;
                Global.drag_offset = wp - new Vector2(clicked.cell_x * Global.cell_size,
                                                       clicked.cell_y * Global.cell_size);
            }
        }

        // rechts-klick: benutzen/platzieren (der klick des bau-modus)
        if (Raylib.IsMouseButtonPressed(MouseButton.Right))
            world_right_click(wp, cable_mode);
    }

    /// <summary>
    /// Ein rechts-klick in die welt: das ist der "benutzen/platzieren"-klick
    /// des bau-modus. Eigene methode, damit die gesamte verteilung (pins,
    /// lever/uhr, organize-ebene, gates, constructs) an EINER stelle steht.
    /// </summary>
    static void world_right_click(Vector2 wp, bool cable_mode)
    {
        Pin p = World.pin_at(wp);
        if (cable_mode)
        {
            GateBase over = World.gate_at(wp);
            if (p != null)
            {
                // pin right-click -> cableing mode (nur mit cable ausgewaehlt)
                Global.cable_start = p;
                Global.state = GlobalState.cableing;
                return;
            }
            if (over is LEVER levCable)
            {
                //lever bleibt auch mit cable-werkzeug anklickbar
                levCable.toggle();
                return;
            }
            if (over is CLOCK clockCable)
            {
                //uhr: rate neu einstellen
                ask_clock_rate(clockCable, fresh: false);
                return;
            }
            return; //cable-werkzeug platziert keine gates
        }

        //organize-ebene (beschriftungen und rahmen): sie schwebt ueber der
        //welt und hat ihre eigene ablage - deshalb zuerst pruefen
        if (Global.selected_gate is Type organize_type && is_organize(organize_type))
        {
            (int ocx, int ocy) = Global.cell_at(wp);

            if (organize_type == typeof(LABEL))
            {
                if (Organize.at(wp) is LABEL existing)
                {
                    //beschriftung aendern (leerer text loescht sie)
                    ask_label_text(existing, fresh: false);
                    return;
                }

                //frisch platzieren und direkt nach dem text fragen
                var label = new LABEL();
                Organize.place(label, ocx, ocy);
                ask_label_text(label, fresh: true);
                return;
            }                if (organize_type == typeof(BORDER))
                {
                    //wie im speicher-modus: erster klick = erste ecke, zweiter = zweite
                    Organize.border_click(Global.selected_item, ocx, ocy);
                    return;
                }

            return;
        }

        GateBase g = World.gate_at(wp);
        if (g is LEVER lev)
        {
            // lever right-click toggles (user input happens between ticks)
            lev.toggle();
            return;
        }

        if (g is CLOCK clock)
        {
            //uhr right-click: nach der neuen rate fragen
            ask_clock_rate(clock, fresh: false);
            return;
        }

        if (g is CONST32 constant)
        {
            //32-bit-konstante right-click: nach der neuen zahl fragen
            ask_const_value(constant, fresh: false);
            return;
        }

        if (Global.selected_item != null)
        {
            (int cx, int cy) = Global.cell_at(wp);

            if (Global.selected_gate != null)
            {
                GateBase new_gate = GateRegistry.create(Global.selected_gate);
                if (new_gate != null && World.place(new_gate, cx, cy))
                {
                    World.kick();
                    //eine frisch platzierte uhr fragt direkt nach ihrer rate
                    if (new_gate is CLOCK new_clock) ask_clock_rate(new_clock, fresh: true);
                    //und eine frisch platzierte konstante nach ihrer zahl
                    if (new_gate is CONST32 new_const) ask_const_value(new_const, fresh: true);
                }
            }
            else if (Global.selected_item is ConstructDef construct)
            {
                //ein construct ist eine ganze gruppe: sie wird nur platziert,
                //wenn nichts im weg ist
                if (construct.place_at(cx, cy)) World.kick();
            }
        }
    }

    /// <summary>Ist dieser inventar-eintrag ein organize-item (beschriftung/rahmen)?</summary>
    static bool is_organize(Type t) => t != null && typeof(OrganizeItem).IsAssignableFrom(t);

    /// <summary>
    /// Nach dem text einer beschriftung fragen (das vorhandene eingabe-system,
    /// genau wie bei der taktrate einer uhr). Ein leerer text entfernt die
    /// beschriftung wieder.
    /// </summary>
    static void ask_label_text(LABEL label, bool fresh)
    {
        string prompt = fresh ? "label text:" : $"label text (now \"{label.text}\"):";

        Global.begin_input(numeric: false,
                           initial: fresh ? "" : label.text,
                           prompt: prompt,
                           commit: text =>
                           {
                               if (string.IsNullOrWhiteSpace(text)) Organize.remove(label);
                               else label.set_text(text);
                           },
                           //esc: eine gerade platzierte, noch namenlose beschriftung
                           //wieder wegnehmen (sonst bliebe sie unsichtbar liegen)
                           cancel: fresh ? () => Organize.remove(label) : null);
    }

    /// <summary>
    /// Das kabel-werkzeug aufgeben (esc): erst ein laufendes ziehen/markieren
    /// abbrechen, dann das kabeln selbst beenden (Global.leave_connecting_mode:
    /// halbfertiges kabel weg, werkzeug aus, zurueck ins bauen). Das werkzeug
    /// geht mit aus, weil sonst die farben-liste stehen bliebe - esc soll
    /// wirklich wieder bauen.
    /// </summary>
    static void cancel_cableing()
    {
        end_inspecting();
        Global.leave_connecting_mode();
    }

    /// <summary>
    /// Den zweiten pin anklicken. Esc wird schon in update_modes behandelt,
    /// hier also nicht mehr.
    /// </summary>
    static void update_cableing(Vector2 wp)
    {
        Global.cable_hover = World.pin_at(wp);

        if (Raylib.IsMouseButtonPressed(MouseButton.Right))
        {
            Pin p = World.pin_at(wp);
            if (p != null && !ReferenceEquals(p, Global.cable_start))
            {
                // one output + one input required; same kind cancels.
                // Ausserdem muessen beide pins gleich viele bits tragen:
                // eine normale leitung passt nicht auf einen 8-bit-pin.
                if (p.is_input() != Global.cable_start.is_input() && p.bits == Global.cable_start.bits)
                {
                    //bereits verbunden? dieser klick trennt sie wieder
                    Wire existing = Wire.find_between(Global.cable_start, p);
                    if (existing != null)
                    {
                        existing.destroy(null);

                        //der getrennte eingang muss auf unverbunden zurueckfallen
                        Pin in_pin = p.is_input() ? p : Global.cable_start;
                        if (in_pin.gate is GateBase driven) World.eval_gate_recursive(driven);
                    }
                    else
                    {
                        //die leitung bekommt die gerade gewaehlte farbe (Wire.color_index)
                        var w = new Wire();
                        if (!w.connect_undirected(Global.cable_start, p)) return;

                        // wires are instant: the driven gate must re-evaluate,
                        // and so must everything downstream of it
                        Pin in_pin = p.is_input() ? p : Global.cable_start;
                        if (in_pin.gate is GateBase driven) World.eval_gate_recursive(driven);
                    }
                    World.kick();
                }
                Global.cable_start = null;
                Global.state = GlobalState.building;
            }
            else if (p == null)
            {
                //clicked nothing -> back to building (keine wegpunkte mehr:
                //ein kabel gehört nur zu zwei pins)
                Global.cable_start = null;
                Global.state = GlobalState.building;
            }
            //klick auf den start-pin selbst: nichts tun (bewusst, damit der
            //starter nicht versehentlich "abgebrochen" wirkt)
        }
    }

    static void update_inspecting(Vector2 wp)
    {
        // T deletes the marked gate (oder die markierte beschriftung/den rahmen)
        if (Raylib.IsKeyPressed(KeyboardKey.T))
        {
            GateBase target = Global.dragged ?? Global.inspected;
            if (target != null)
            {
                if (target is OrganizeItem organize) Organize.remove(organize);
                else World.remove(target);

                inspected_set.Remove(target);
                Global.dragged = null;
                Global.inspected = null;
                Global.state = GlobalState.building;
            }
            return;
        }

        // while the left button is down, the marked gate follows the mouse
        if (Global.dragged == null && Raylib.IsMouseButtonDown(MouseButton.Left) && Global.inspected != null)
        {
            Global.dragged = Global.inspected;
            Global.drag_offset = wp - new Vector2(
                Global.inspected.cell_x * Global.cell_size,
                Global.inspected.cell_y * Global.cell_size);

            //ein organize-item schwebt: es muss nicht aus dem grid gehoben werden
            if (Global.inspected is not OrganizeItem)
                World.begin_drag(Global.inspected);
        }

        if (Global.dragged != null)
        {
            (int cx, int cy) = Global.cell_at(wp - Global.drag_offset);
            Global.dragged.cell_x = cx;
            Global.dragged.cell_y = cy;

            if (Raylib.IsMouseButtonReleased(MouseButton.Left))
            {
                if (Global.dragged is OrganizeItem)
                {
                    //frei schwebend: nichts zu pruefen, die position steht schon
                }
                else if (World.is_free_at_drag(Global.dragged))
                    World.commit_drag(Global.dragged);
                else
                    World.abort_drag(Global.dragged);

                Global.dragged = null;
                Global.state = GlobalState.building;
            }
        }
    }

    static void end_inspecting()
    {
        if (Global.dragged != null)
        {
            if (Global.dragged is not OrganizeItem) World.abort_drag(Global.dragged);
            Global.dragged = null;
        }
        Global.inspected = null;
        inspected_set.Clear();
        Global.state = GlobalState.building;
    }

    // ---- drawing -------------------------------------------------------------------

    static void draw_frame()
    {
        Raylib.BeginDrawing();
        Raylib.ClearBackground(Global.frame_color);   // = the letterbox borders (dark gray by default)

        // scissor off the borders so nothing bleeds into them
        Raylib.BeginScissorMode((int)Global.content_offset_x, (int)Global.content_offset_y,
                                (int)(CONTENT_W * Global.content_scale), (int)(CONTENT_H * Global.content_scale));

        //inside the content area the background is black
        Raylib.DrawRectangle((int)Global.content_offset_x, (int)Global.content_offset_y,
                             (int)(CONTENT_W * Global.content_scale), (int)(CONTENT_H * Global.content_scale),
                             Color.Black);

        Raylib.BeginMode2D(Global.camera);
        draw_wires();
        var drawn = new HashSet<IGate>();   // multi-cell gates sit on many keys, draw once
        foreach (var kv in World.gate_grid)
            if (kv.Value is GateBase g && drawn.Add(g) && g.visible(Global.camera))
                g.draw();
        draw_overlays();
        Raylib.EndMode2D();

        //inventory list, top-left in content space - aber NICHT im cabling-mode
        //(c-gedrueckt oder aktiv am verbinden): dort steht stattdessen die
        //farben-liste des kabel-werkzeugs. Waehrend einer eingabe steht dort
        //das eingabefeld - das bleibt auch im spectate-modus stehen, denn die
        //taktrate einer uhr stellt man dort ein. Sonst steht im spectate-modus
        //(f1) gar nichts: das ist der modus ohne ui.
        if (Global.state == GlobalState.inputting)
        {
            draw_input(Global.content_offset_x, Global.content_offset_y, Global.content_scale);
        }
        else if (Global.state == GlobalState.searching)
        {
            //die inventar-suche (ctrl+f) steht statt des inventars da
            Search.draw(Global.content_offset_x, Global.content_offset_y);
        }
        else if (!Global.spectating && (Global.state == GlobalState.cableing || Global.cable_tool_active))
        {
            ColorMenu.draw(Global.content_offset_x, Global.content_offset_y, Global.content_scale);
        }
        else if (!Global.spectating && Global.state == GlobalState.saving)
        {
            //im speicher-modus steht statt des inventars das werkzeug-menue da
            SaveTools.draw(Global.content_offset_x, Global.content_offset_y, Global.content_scale);
        }
        else if (!Global.spectating)
        {
            Inventory.draw(Global.content_offset_x, Global.content_offset_y, Global.content_scale);
        }

        Raylib.EndScissorMode();
        Raylib.EndDrawing();
    }

    /// <summary>
    /// Eingabefeld statt inventar: prompt, getippter text und ein blinkender
    /// cursor. Nur bestehende farben (grau/orange wie die inventar-liste).
    /// </summary>
    static void draw_input(float ox, float oy, float scale)
    {
        float font_size = Global.inventory_fontsize * scale;
        float line = Global.inventory_line_height * scale;

        if (Global.input_prompt.Length > 0)
            Raylib.DrawTextEx(Global.font, Global.input_prompt,
                new Vector2(ox + 10 * scale, oy + 10 * scale), font_size, Global.letter_spacing, Color.LightGray);

        Vector2 typed_pos = new Vector2(ox + 10 * scale, oy + 10 * scale + line);
        Raylib.DrawTextEx(Global.font, Global.input_text, typed_pos, font_size, Global.letter_spacing, Color.Orange);

        //blinkender cursor direkt hinter dem getippten text (~2x pro sekunde).
        //die breite kommt aus dem drawTextEx-mass von raylib (siehe
        //Global.drawn_text_width) - so steht der cursor genau am textende,
        //auch wenn das feld noch leer ist.
        //bei einer frage (ja/nein) gibt es nichts zu tippen, also auch keinen cursor
        bool blink = ((int)(Raylib.GetTime() * 2.0)) % 2 == 0;
        if (blink && !Global.input_readonly)
        {
            float typed_width = Global.text_advance(Global.font, Global.input_text, font_size);
            Raylib.DrawTextEx(Global.font, "_", new Vector2(typed_pos.X + typed_width, typed_pos.Y),
                font_size, Global.letter_spacing, Color.LightGray);
        }
    }

    static void draw_wires()
    {
        foreach (Wire w in World.wires)
        {
            if (w.output == null || w.input == null) continue;
            // culled: only draw wires with an on-screen endpoint
            if (Global.point_on_screen(w.output.center(), Global.camera) ||
                Global.point_on_screen(w.input.center(), Global.camera))
                w.draw(Global.camera);
        }

        // cableing preview: exakt dieselbe bezier-kurve wie die spaetere echte
        // leitung, in der gewaehlten farbe - und schon auf den gehoverten pin
        // geschnappt, wenn einer darunter liegt
        if (Global.state == GlobalState.cableing && Global.cable_start != null)
            Wire.draw_preview_curve(Global.cable_start, Global.cable_hover, mouse_world());
    }

    static void draw_overlays()
    {
        //organize-ebene: beschriftungen und rahmen liegen ueber der schaltung.
        //Sie gehoeren zur schaltung selbst (sie werden im construct gespeichert)
        //und bleiben deshalb auch im spectate-modus sichtbar.
        Organize.draw(Global.camera);

        //im spectate-modus (f1) gibt es sonst KEINE overlays: keine vorschauen,
        //kein pin-highlight, keine markierung - nur die schaltung
        if (Global.spectating) return;

        // hovered pin highlight: nur im cable-gebrauch (cable gewaehlt oder cableing)
        if (Global.cable_hover != null &&
            (Global.state == GlobalState.cableing || Global.cable_tool_active))
            Raylib.DrawRectangleRec(Global.cable_hover.rect(), new Color(255, 255, 0, 110));

        //vorschau eines organize-eintrags: er schwebt, also ohne kollisions-
        //pruefung - mit umriss, damit auch eine leere beschriftung sichtbar ist
        if (Global.state == GlobalState.building && is_organize(Global.selected_gate) &&
            !Global.cable_tool_active)
        {
            (int cx, int cy) = Global.cell_at(mouse_world());
            if (GateRegistry.create(Global.selected_gate) is OrganizeItem ghost)
            {
                ghost.cell_x = cx;
                ghost.cell_y = cy;
                ghost.draw();
                ghost.draw_preview_outline(cx, cy);
            }
        }

        // ghost preview of the selected gate in building mode
        // (none while the cable tool is active, none while hovering a lever
        //  so the lever stays clickable without the preview covering it;
        //  ueber dem inventar wird normal gezeichnet - platzieren geht ueberall)
        GateBase hover_gate = World.gate_at(mouse_world());
        if (Global.state == GlobalState.building && Global.selected_item != null &&
            !is_organize(Global.selected_gate) &&
            hover_gate is not LEVER && hover_gate is not CLOCK && hover_gate is not CONST32 &&
            !Global.cable_tool_active)
        {
            (int cx, int cy) = Global.cell_at(mouse_world());

            if (Global.selected_gate != null)
            {
                GateBase ghost = GateRegistry.create(Global.selected_gate);
                if (ghost != null)
                {
                    ghost.cell_x = cx; ghost.cell_y = cy;
                    Color old = Global.standart_color;
                    Global.standart_color = new Color(255, 255, 255, 120);
                    ghost.draw();
                    Global.standart_color = old;
                }
            }
            else if (Global.selected_item is ConstructDef construct)
            {
                //construct-vorschau: alle gates der gruppe, halbdurchsichtig
                construct.draw_ghost(cx, cy);
            }
        }

        //rahmen-werkzeug: die flaeche, die gerade aufgezogen wird
        if (Global.state == GlobalState.building && Organize.has_first)
            Organize.draw_pending_preview(mouse_world());

        //speicher-modus: die markierte flaeche als vorschau (der rahmen folgt
        //der maus, solange erst eine ecke gesetzt ist)
        if (Global.state == GlobalState.saving)
            Selection.draw_preview(mouse_world());

        // highlight the marked gate in inspecting mode
        if (Global.state == GlobalState.inspecting && Global.inspected != null)
        {
            (int w, int h) = Global.inspected.get_cell_size();
            Raylib.DrawRectangleLinesEx(new Rectangle(
                Global.inspected.cell_x * Global.cell_size, Global.inspected.cell_y * Global.cell_size,
                w * Global.cell_size, h * Global.cell_size), 3f, Color.SkyBlue);
        }
    }
}
