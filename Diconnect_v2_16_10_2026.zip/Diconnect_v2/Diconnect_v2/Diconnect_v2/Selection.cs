using Raylib_cs;
using System;
using System.Collections.Generic;
using System.Numerics;

namespace Diconnect_v2
{
    /// <summary>
    /// Die auswahl im speicher-modus (in zellen).
    ///
    /// Ein bereich ist nur gueltig, wenn jedes gate, das er schneidet, auch
    /// VOLLSTAENDIG in ihm liegt - ein angeschnittenes gate verwirft die
    /// auswahl (siehe Regel in valid()).
    ///
    /// Der zustand liegt ausserhalb der welt: er ueberlebt einen wechsel in
    /// den bau-modus und wieder zurueck, bis der marker neu angesetzt wird.
    /// </summary>
    internal static class Selection
    {
        /// <summary>Erste ecke des markers (nur wenn der marker einmal geklickt wurde).</summary>
        public static bool has_first;
        public static (int x, int y) first;

        /// <summary>Bestaetigte, gueltige auswahl.</summary>
        public static bool has_region;
        public static (int x1, int y1, int x2, int y2) region;

        public static void clear()
        {
            has_first = false;
            has_region = false;
            first = (0, 0);
            region = (0, 0, 0, 0);
        }

        // ---- geometrie ----------------------------------------------------------------

        /// <summary>Der bereich zwischen zwei ecken, unabhaengig von der reihenfolge.
        /// Auch das rahmen-werkzeug (organize-ebene) rechnet damit.</summary>
        public static (int x1, int y1, int x2, int y2) rect_between((int x, int y) a, (int x, int y) b)
        {
            return (Math.Min(a.x, b.x), Math.Min(a.y, b.y),
                    Math.Max(a.x, b.x), Math.Max(a.y, b.y));
        }

        static (int x, int y, int w, int h) gate_cells(GateBase g)
        {
            (int w, int h) = g.get_cell_size();
            return (g.cell_x, g.cell_y, w, h);
        }

        /// <summary>Liegt dieses gate (bzw. organize-item) vollstaendig in dem bereich?</summary>
        public static bool fully_inside(GateBase g, (int x1, int y1, int x2, int y2) r)
        {
            (int x, int y, int w, int h) = gate_cells(g);
            return x >= r.x1 && y >= r.y1 && x + w - 1 <= r.x2 && y + h - 1 <= r.y2;
        }

        static bool intersects(GateBase g, (int x1, int y1, int x2, int y2) r)
        {
            (int x, int y, int w, int h) = gate_cells(g);
            return !(x + w - 1 < r.x1 || x > r.x2 || y + h - 1 < r.y1 || y > r.y2);
        }

        /// <summary>Alle gates der welt, jedes genau einmal.</summary>
        static List<GateBase> all_gates()
        {
            var seen = new HashSet<GateBase>();
            var list = new List<GateBase>();
            foreach (var kv in World.gate_grid)
                if (kv.Value is GateBase g && seen.Add(g))
                    list.Add(g);
            return list;
        }

        /// <summary>
        /// ALLES auf der karte: die gates und die organize-ebene (beschriftungen
        /// und rahmen). Beide sind GateBase, also reicht eine liste fuer die
        /// gemeinsame rechnung. Ein organize-item liegt nie im gate_grid, doppelte
        /// eintraege gibt es deshalb nicht.
        /// </summary>
        static List<GateBase> everything()
        {
            List<GateBase> list = all_gates();
            foreach (OrganizeItem item in Organize.items) list.Add(item);
            return list;
        }

        /// <summary>
        /// Regel: schneidet der bereich ein gate, ohne es vollstaendig zu
        /// umschliessen, ist er ungueltig (und wird verworfen).
        /// </summary>
        public static bool valid((int x1, int y1, int x2, int y2) r)
        {
            foreach (GateBase g in all_gates())
                if (intersects(g, r) && !fully_inside(g, r)) return false;
            return true;
        }

        /// <summary>Liegt dieses gate vollstaendig in der bestaetigten auswahl?</summary>
        public static bool contains_gate(GateBase g)
        {
            return has_region && fully_inside(g, region);
        }

        /// <summary>Liegt diese zelle in der bestaetigten auswahl?</summary>
        public static bool inside_region(int cell_x, int cell_y)
        {
            return has_region &&
                   cell_x >= region.x1 && cell_x <= region.x2 &&
                   cell_y >= region.y1 && cell_y <= region.y2;
        }

        /// <summary>Alle gates, die vollstaendig in der auswahl liegen (jedes einmal).</summary>
        static List<GateBase> gates_inside()
        {
            var list = new List<GateBase>();
            foreach (GateBase g in all_gates())
                if (fully_inside(g, region)) list.Add(g);
            return list;
        }

        // ---- verschieben der markierten flaeche ----------------------------------------

        /// <summary>Was ein linksklick im speicher-modus bedeutet.</summary>
        public enum DragResult
        {
            /// <summary>Der klick gehoert dem werkzeug (oder es passiert nichts).</summary>
            none,
            /// <summary>Ein zug laeuft oder hat gerade verschoben: nichts anderes tun.</summary>
            dragging,
            /// <summary>Losgelassen ohne zu ziehen: es war ein normaler werkzeug-klick.</summary>
            clicked
        }

        //links gedrueckt IN der auswahl: der zug ist vorgemerkt, aber noch nicht
        //sicher - erst eine bewegung macht daraus ein verschieben
        static bool armed;
        static (int x, int y) grab;

        /// <summary>Verschiebt ein zug gerade die markierte flaeche?</summary>
        public static bool moving;

        /// <summary>Um wie viele zellen die flaeche gerade verschoben wird.</summary>
        public static (int dx, int dy) move_delta;

        /// <summary>Einen laufenden zug vergessen (esc, modus-wechsel, werkzeug).</summary>
        public static void cancel_move()
        {
            armed = false;
            moving = false;
            move_delta = (0, 0);
        }

        /// <summary>
        /// Linksklick und ziehen: wer IN der markierten flaeche drueckt und dann
        /// zieht, verschiebt alles, was darin liegt - die gates mit ihren
        /// leitungen, die beschriftungen und die rahmen (siehe move_region).
        ///
        /// Ohne bewegung bleibt es der normale klick des gewaehlten werkzeugs:
        /// der kommt erst beim LOSLASSEN zurueck (DragResult.clicked), damit man
        /// die markierte flaeche nicht versehentlich schon beim druecken
        /// wegschiebt oder loescht.
        /// </summary>
        public static DragResult handle_drag(Vector2 world_pos)
        {
            return drag_step(Raylib.IsMouseButtonPressed(MouseButton.Left),
                             Raylib.IsMouseButtonReleased(MouseButton.Left),
                             Global.cell_at(world_pos));
        }

        /// <summary>
        /// Derselbe ablauf, nur mit uebergebenem maus-zustand und uebergebener
        /// zelle: so laesst sich ein ganzes ziehen (druecken, bewegen, loslassen)
        /// ohne echte maus durchspielen.
        /// </summary>
        public static DragResult drag_step(bool pressed, bool released, (int x, int y) cell)
        {
            if (!has_region) { cancel_move(); return DragResult.none; }

            if (!armed)
            {
                if (!pressed || !inside_region(cell.x, cell.y)) return DragResult.none;

                armed = true;
                grab = cell;
                return DragResult.dragging;
            }

            move_delta = (cell.x - grab.x, cell.y - grab.y);
            if (move_delta != (0, 0)) moving = true;

            if (released)
            {
                (int dx, int dy) = move_delta;
                bool was_moving = moving;
                cancel_move();

                if (was_moving) move_region(dx, dy);
                else return DragResult.clicked;   //es war kein ziehen
            }

            return DragResult.dragging;
        }

        /// <summary>
        /// Passt die markierte flaeche um (dx, dy) zellen verschoben in die welt?
        /// Geprueft wird gegen die gates, die NICHT mitwandern - die mitwandern
        /// sind beim rechnen schon woanders.
        /// </summary>
        public static bool can_move(int dx, int dy)
        {
            if (!has_region || (dx == 0 && dy == 0)) return false;

            var walking = new HashSet<GateBase>(gates_inside());

            foreach (GateBase g in walking)
            {
                (int x, int y, int w, int h) = gate_cells(g);
                for (int cx = x + dx; cx < x + dx + w; cx++)
                    for (int cy = y + dy; cy < y + dy + h; cy++)
                        if (World.gate_grid.TryGetValue((cx, cy), out IGate? other) &&
                            !(other is GateBase ob && walking.Contains(ob)))
                            return false;
            }

            return true;
        }

        /// <summary>
        /// Die markierte flaeche verschieben: alles, was vollstaendig darin liegt,
        /// rueckt um (dx, dy) zellen weiter - gates (ihre leitungen haengen an den
        /// pins und wandern mit), beschriftungen und rahmen. Die markierung wandert
        /// mit, damit man mehrfach ziehen kann. Passt das ziel nicht, bleibt alles,
        /// wie es war. Meldet, ob verschoben wurde.
        /// </summary>
        public static bool move_region(int dx, int dy)
        {
            if (!can_move(dx, dy)) return false;

            List<GateBase> gates = gates_inside();
            List<OrganizeItem> items = Organize.inside(region);

            //erst ALLE alten zellen freigeben, dann die neuen belegen: sonst
            //kollidiert ein gate mit seinem eigenen alten platz
            foreach (GateBase g in gates)
            {
                (int x, int y, int w, int h) = gate_cells(g);
                for (int cx = x; cx < x + w; cx++)
                    for (int cy = y; cy < y + h; cy++)
                        World.gate_grid.Remove((cx, cy));
            }

            foreach (GateBase g in gates)
            {
                g.cell_x += dx;
                g.cell_y += dy;

                (int x, int y, int w, int h) = gate_cells(g);
                for (int cx = x; cx < x + w; cx++)
                    for (int cy = y; cy < y + h; cy++)
                        World.gate_grid[(cx, cy)] = g;
            }

            //beschriftungen und rahmen schweben (sie liegen nicht im grid): bei
            //ihnen ist nur die zelle zu setzen
            foreach (OrganizeItem item in items)
            {
                item.cell_x += dx;
                item.cell_y += dy;
            }

            region = (region.x1 + dx, region.y1 + dy, region.x2 + dx, region.y2 + dy);
            has_first = false;
            return true;
        }

        // ---- werkzeuge ----------------------------------------------------------------

        /// <summary>
        /// Ein klick des markers: der erste setzt die erste ecke, der zweite
        /// die zweite. Ist der bereich ungueltig, wird die auswahl verworfen.
        /// </summary>
        public static void marker_click(int cell_x, int cell_y)
        {
            if (!has_first)
            {
                first = (cell_x, cell_y);
                has_first = true;
                has_region = false;
                return;
            }

            var r = rect_between(first, (cell_x, cell_y));
            has_first = false;

            if (valid(r))
            {
                region = r;
                has_region = true;
            }
            else
            {
                clear();   //ein gate wird angeschnitten -> auswahl abgebrochen
            }
        }

        /// <summary>
        /// "mark all": die kleinste bounding-box, die noch alles auf der karte
        /// enthaelt - gates, beschriftungen und rahmen (sie ist damit immer gueltig).
        /// </summary>
        public static void mark_all()
        {
            var contents = everything();
            if (contents.Count == 0)
            {
                clear();
                return;
            }

            int x1 = int.MaxValue, y1 = int.MaxValue, x2 = int.MinValue, y2 = int.MinValue;
            foreach (GateBase g in contents)
            {
                (int x, int y, int w, int h) = gate_cells(g);
                x1 = Math.Min(x1, x);
                y1 = Math.Min(y1, y);
                x2 = Math.Max(x2, x + w - 1);
                y2 = Math.Max(y2, y + h - 1);
            }

            has_first = false;
            var r = (x1, y1, x2, y2);
            if (valid(r))
            {
                region = r;
                has_region = true;
            }
            else
            {
                clear();
            }
        }

        // ---- loeschen ------------------------------------------------------------------

        /// <summary>
        /// Alles loeschen, was in der markierten flaeche liegt (gates mit ihren
        /// leitungen, beschriftungen und rahmen). Weil das nicht rueckgaengig zu
        /// machen ist, wird vorher gefragt: enter = ja, esc = nein.
        /// </summary>
        public static void delete_selected()
        {
            if (!has_region) return;
            Global.begin_confirm("delete? yes [enter] no [esc]", () => delete_region(region));
        }

        /// <summary>Den inhalt eines bereichs entfernen (ohne nachfrage).</summary>
        public static void delete_region((int x1, int y1, int x2, int y2) rect)
        {
            //erst sammeln, dann loeschen - waehrend des loeschens darf die liste
            //nicht veraendert werden
            var gates = new List<GateBase>();
            foreach (GateBase g in all_gates())
                if (fully_inside(g, rect)) gates.Add(g);

            foreach (GateBase g in gates) World.remove(g);   //nimmt seine leitungen mit

            foreach (OrganizeItem item in Organize.inside(rect)) Organize.remove(item);

            World.kick();
        }

        /// <summary>Auswahl als construct speichern - der name kommt aus der eingabe.</summary>
        public static void save_selected()
        {
            if (!has_region) return;

            //zurueck in den speicher-modus, wenn der name steht
            Global.begin_input(numeric: false, initial: "", prompt: "construct name:",
                               commit: commit_name);
        }

        static void commit_name(string typed)
        {
            string name = ConstructStore.sanitize(typed);
            if (name.Length == 0) return;

            ConstructDef def = ConstructStore.capture(name, region);
            if (def.gates.Count == 0) return;

            if (ConstructStore.save(def))
            {
                //neues construct sofort im inventar (kategorie "constructs")
                ConstructStore.load();
                Inventory.refresh();
            }
        }

        /// <summary>Kurzer text fuer die anzeige im speicher-modus.</summary>
        public static string describe()
        {
            if (has_region)
                return $"area {Math.Abs(region.x2 - region.x1) + 1}x{Math.Abs(region.y2 - region.y1) + 1} cells";
            if (has_first) return "marker: pick 2nd corner";
            return "no area marked";
        }

        // ---- zeichnen ----------------------------------------------------------------

        /// <summary>
        /// Die auswahl als vorschau: der bestaetigte bereich orange, ein
        /// gerade gezogener bereich orange wenn er gueltig ist, sonst rot
        /// (er wuerde beim zweiten klick verworfen). Beim verschieben kommt das
        /// ziel dazu (siehe draw_preview).
        /// </summary>
        public static void draw_preview(Vector2 mouse_world)
        {
            if (has_region)
            {
                draw_rect(region, Global.selection_color, (byte)50);

                //ein laufender zug zeigt ZUSAETZLICH, wo die flaeche landet:
                //orange = das ziel passt, rot = dort steht etwas im weg
                if (moving)
                {
                    var target = (region.x1 + move_delta.dx, region.y1 + move_delta.dy,
                                  region.x2 + move_delta.dx, region.y2 + move_delta.dy);
                    draw_area(target, can_move(move_delta.dx, move_delta.dy));
                }
                return;
            }

            if (!has_first) return;

            (int cx, int cy) = Global.cell_at(mouse_world);
            var r = rect_between(first, (cx, cy));
            draw_area(r, valid(r));
        }

        /// <summary>
        /// Einen bereich als vorschau zeichnen: gueltig = orange, ungueltig
        /// (wuerde verworfen) = rot. Auch das rahmen-werkzeug benutzt das.
        /// </summary>
        public static void draw_area((int x1, int y1, int x2, int y2) r, bool ok)
        {
            draw_rect(r, ok ? Global.selection_color : Global.activecolor, ok ? (byte)50 : (byte)40);
        }

        static void draw_rect((int x1, int y1, int x2, int y2) r, Color c, byte fill_alpha)
        {
            int x = r.x1 * Global.cell_size;
            int y = r.y1 * Global.cell_size;
            int w = (r.x2 - r.x1 + 1) * Global.cell_size;
            int h = (r.y2 - r.y1 + 1) * Global.cell_size;

            Raylib.DrawRectangle(x, y, w, h, new Color(c.R, c.G, c.B, fill_alpha));
            Raylib.DrawRectangleLinesEx(new Rectangle(x, y, w, h), 3f, c);
        }
    }
}
