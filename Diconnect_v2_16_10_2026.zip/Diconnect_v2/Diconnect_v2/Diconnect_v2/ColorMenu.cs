using Raylib_cs;
using System.Numerics;

namespace Diconnect_v2
{
    /// <summary>
    /// Die farben-liste des kabel-werkzeugs: beim kabeln steht statt des
    /// inventars diese liste da, ihre eintraege sind die farben aus
    /// Global.wire_colors (color[n] gehoert zu wire_color_names[n]).
    ///
    /// Bedient wird sie wie das inventar: w/s und das mausrad waehlen, die
    /// auswahl laeuft um.
    ///
    /// Jeder name steht in SEINER farbe - aber ausgegraut. Nur die gerade
    /// gewaehlte farbe wird in ihrer vollen farbe gezeigt (im inventar ist der
    /// gewaehlte eintrag stattdessen orange).
    ///
    /// Die gewaehlte farbe ist die farbe der naechsten leitung und der vorschau
    /// (siehe Global.active_wire_color).
    /// </summary>
    internal static class ColorMenu
    {
        /// <summary>Ueberschrift ueber der liste - beim kabeln haengt man
        /// gerade einen zweiten pin an. Darunter bleibt ein element platz.</summary>
        public const string title = "connecting";

        /// <summary>Zeile, in der die erste farbe steht: die ueberschrift belegt
        /// zeile 0, zeile 1 bleibt leer (ein element abstand).</summary>
        public const int first_row = 2;

        /// <summary>Merkt sich, dass der spieler w/s und das rad benutzt, wie im inventar.</summary>
        public static void do_input()
        {
            if (Raylib.GetMouseWheelMove() < 0) move(+1);
            if (Raylib.GetMouseWheelMove() > 0) move(-1);

            if (Raylib.IsKeyPressed(KeyboardKey.S)) move(+1);
            if (Raylib.IsKeyPressed(KeyboardKey.W)) move(-1);
        }

        /// <summary>Eine farbe weiter (dir=+1) oder zurueck (dir=-1), mit umlauf.</summary>
        public static void move(int dir)
        {
            int count = Global.wire_colors.Length;
            Global.active_wire_color = ((Global.active_wire_color + dir) % count + count) % count;
        }

        public static void draw(float ox, float oy, float scale)
        {
            float font_size = Global.inventory_fontsize * scale;
            float line = Global.inventory_line_height * scale;

            Raylib.DrawTextEx(Global.font, title,
                new Vector2(ox + 10 * scale, oy + 10 * scale),
                font_size, Global.letter_spacing, Color.Orange);

            for (int i = 0; i < Global.wire_colors.Length && i < Global.wire_color_names.Length; i++)
            {
                Color c = i == Global.active_wire_color
                    ? Global.wire_color_of(i)          //die gewaehlte: ihre aktive farbe
                    : Global.wire_color_passive(i);    //die anderen: ausgegraut

                //die namen fangen eine zeile SPÄTER an als die ueberschrift:
                //zwischen "connecting" und der liste bleibt ein element platz
                Raylib.DrawTextEx(Global.font, Global.wire_color_names[i],
                    new Vector2(ox + 10 * scale, oy + 10 * scale + line * (i + first_row)),
                    font_size, Global.letter_spacing, c);
            }
        }
    }
}
