using Raylib_cs;
using System;
using System.Collections.Generic;
using System.Numerics;

namespace Diconnect_v2
{
    /// <summary>Ein werkzeug im speicher-menue.</summary>
    internal class ToolEntry : IMenuEntry
    {
        public readonly string id;

        public ToolEntry(string id, string label)
        {
            this.id = id;
            this.label = label;
        }

        public readonly string label;

        public string display_name => label;

        //feste reihenfolge im menue: mark all, marker, save
        public string sort_key => id;
    }

    /// <summary>
    /// Der speicher-modus (ctrl+s): statt des inventars steht hier ein
    /// werkzeug-menue, das sich genau wie das inventar bedienen laesst
    /// (w/s waehlt, a/d blaettert, mausrad scrollt, unten kategorie + seite).
    ///
    /// Ein linksklick in die welt wendet das gewaehlte werkzeug an:
    ///   "mark all" - kleinste bounding-box um alles auf der karte
    ///   "marker"   - klick 1: erste ecke, klick 2: zweite ecke
    ///   "save"     - die auswahl als construct speichern (fragt nach dem namen)
    ///   "delete"   - alles in der auswahl loeschen (fragt vorher nach)
    ///
    /// Achtung: wer in der MARKIERTEN flaeche drueckt und dann ZIEHT, verschiebt
    /// sie (gates mit ihren leitungen, beschriftungen und rahmen) - das werkzeug
    /// greift dann nicht. Ohne bewegung bleibt es der normale klick, der kommt
    /// erst beim loslassen (siehe Selection.handle_drag und Program.update_saving).
    /// </summary>
    internal static class SaveTools
    {
        public static readonly ToolEntry DELETE = new ToolEntry("delete", "delete");
        public static readonly ToolEntry MARK_ALL = new ToolEntry("mark_all", "mark all");
        public static readonly ToolEntry MARKER = new ToolEntry("marker", "marker");
        public static readonly ToolEntry SAVE = new ToolEntry("save", "save");

        public static Menu menu = new Menu("tools");

        public static void init()
        {
            menu.set_pages(new List<(string category, List<IMenuEntry> items)>
            {
                ("tools", new List<IMenuEntry> { DELETE, MARK_ALL, MARKER, SAVE }),
            });
        }

        /// <summary>Das gewaehlte werkzeug (null auf einem blank).</summary>
        public static ToolEntry selected_tool => menu.get_selected() as ToolEntry;

        /// <summary>Das gewaehlte werkzeug auf eine welt-zelle anwenden.</summary>
        public static void use(int cell_x, int cell_y)
        {
            ToolEntry t = selected_tool;
            if (t == null) return;

            if (ReferenceEquals(t, MARK_ALL)) Selection.mark_all();
            else if (ReferenceEquals(t, MARKER)) Selection.marker_click(cell_x, cell_y);
            else if (ReferenceEquals(t, SAVE)) Selection.save_selected();
            else if (ReferenceEquals(t, DELETE)) Selection.delete_selected();
        }

        public static void do_input() => menu.do_input();

        public static bool contains_window(Vector2 window_mouse, float ox, float oy, float scale)
        {
            return menu.contains_window(window_mouse, ox, oy, scale);
        }

        /// <summary>Das werkzeug-menue (gleiche bedienung wie das inventar).</summary>
        public static void draw(float ox, float oy, float scale)
        {
            menu.draw(ox, oy, scale);

            //unter der seitenanzeige: was gerade markiert ist
            float font_size = Global.inventory_fontsize * scale;
            float line = Global.inventory_line_height * scale;
            int rows = menu.items_per_page + 1;   //eintraege + seitenanzeige

            Raylib.DrawTextEx(Global.font, Selection.describe(),
                new Vector2(ox + 10 * scale, oy + 10 * scale + line * rows),
                font_size, Global.letter_spacing, Global.selection_color);
        }
    }
}
