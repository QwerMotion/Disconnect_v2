using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// Base class for every gate. Deriving a gate needs ONE file:
    /// set width/height (cells), pin counts, override evaluate(), done.
    /// </summary>
    internal abstract class GateBase : IGate
    {
        // ---- identity & placement ------------------------------------------------------

        public string name = "gate";

        /// <summary>Top-left cell of the gate inside the gate grid. Pins do NOT take cells.</summary>
        public int cell_x, cell_y;

        /// <summary>
        /// Size in grid cells: automatically as big as the name needs (Raylib
        /// MeasureTextEx) and as high as the pins need - at least 1x1.
        /// Gates can ignore this with <see cref="fixed_size"/> (e.g. AND/OR 2x2).
        /// </summary>
        public (int width, int height)? fixed_size;

        public (int width, int height) get_cell_size()
        {
            if (fixed_size != null) return fixed_size.Value;

            (int w, int _) = Global.measure_gate_cells(num_inputs, num_outputs, name);

            //hoehe: alle pins muessen uebereinander passen. Ein 8-bit-pin ist
            //hoeher als ein normaler, die reihen kommen also aus Pin.height.
            //Liegen eingang und ausgang auf derselben seite, teilen sie sich
            //deren stapel - die hoehe ist dann die summe beider (siehe pins_on).
            int tallest = Math.Max(side_stack_height(PinSide.left), side_stack_height(PinSide.right));
            int h = Math.Max(1, (int)Math.Ceiling((tallest + 2f * Global.pin_size) / Global.cell_size));
            return (w, h);
        }

        static int total_height(int[] heights)
        {
            int total = 0;
            for (int i = 0; i < heights.Length; i++) total += heights[i];
            return total;
        }

        // ---- pin sides ------------------------------------------------------------------

        /// <summary>Auf welcher seite der box die eingaenge sitzen (standart links).</summary>
        public virtual PinSide input_side => PinSide.left;

        /// <summary>Auf welcher seite der box die ausgaenge sitzen (standart rechts).</summary>
        public virtual PinSide output_side => PinSide.right;

        /// <summary>
        /// Liegen eingaenge und ausgaenge auf DERSELBEN seite, teilen sie sich
        /// deren stapel: die eingaenge oben, die ausgaenge darunter. Genau das
        /// machen RL/LR - beide pins an einer kante, damit eine leitung dort
        /// wenden kann (siehe gates/RL.cs).
        /// </summary>
        public bool pins_share_side => input_side == output_side;

        /// <summary>
        /// Die pins, die auf dieser seite uebereinander liegen, von oben nach
        /// unten. Ohne geteilte seite ist das genau die eingangs- bzw. die
        /// ausgangs-liste; auf einer geteilten stehen die eingaenge zuerst.
        /// </summary>
        public Pin[] pins_on(PinSide side)
        {
            if (!pins_share_side)
                return side == input_side ? inputs : outputs;

            var stack = new List<Pin>();
            if (input_side == side) stack.AddRange(inputs);
            if (output_side == side) stack.AddRange(outputs);
            return stack.ToArray();
        }

        /// <summary>Hoehe aller pins einer seite (fuer die box-hoehe).</summary>
        int side_stack_height(PinSide side)
        {
            int total = 0;
            foreach (Pin p in pins_on(side)) total += p.height;
            return total;
        }

        /// <summary>
        /// Hoehen und platz (von oben) eines pins innerhalb der seite, auf der er
        /// sitzt - genau das, was <see cref="Global.pin_rect"/> braucht. Eine
        /// quelle fuer zeichnen und treffen.
        /// </summary>
        public (int[] heights, int slot) side_stack(Pin pin)
        {
            Pin[] stack = pins_on(pin.input ? input_side : output_side);
            var heights = new int[stack.Length];
            int slot = 0;
            for (int i = 0; i < stack.Length; i++)
            {
                heights[i] = stack[i].height;
                if (ReferenceEquals(stack[i], pin)) slot = i;
            }
            return (heights, slot);
        }

        /// <summary>Does the common draw show the name text? Gates like LEVER draw their own.</summary>
        public bool draw_name = true;

        public abstract int num_inputs { get; }
        public abstract int num_outputs { get; }

        public Pin[] inputs;
        public Pin[] outputs;

        /// <summary>
        /// Die id, unter der dieses gate in einer construct-datei steht.
        ///
        /// Standart ist der KLASSENNAME - ein neues gate muss das also gar
        /// nicht ueberschreiben, und der name kann nicht auseinanderlaufen.
        /// Wer es doch ueberschreibt, muss denselben namen zurueckgeben:
        /// passt die id nicht zum typ (klassischer copy-paste-fehler in einer
        /// neuen gate-datei), speichert ConstructStore das gate trotzdem unter
        /// seinem klassennamen und warnt einmal auf der konsole.
        /// </summary>
        public virtual string type_id() => GetType().Name;

        /// <summary>
        /// Der eigene zustand fuer das speichern als construct: freie
        /// key/value-paare, die in die json wandern. Gates OHNE zustand
        /// liefern nichts; zustands-gates (flipflops, lever, uhren) ueberschreiben
        /// genau diese beiden methoden - neue gates brauchen also nichts sonst.
        /// </summary>
        public virtual Dictionary<string, string> save_state() => new Dictionary<string, string>();

        /// <summary>Den gespeicherten zustand wiederherstellen (gegenstueck zu save_state).</summary>
        public virtual void load_state(Dictionary<string, string> state) { }

        protected List<bool> saved_input_values = new();
        protected List<bool> saved_output_values = new();

        protected GateBase()
        {
            int ni = num_inputs, no = num_outputs;
            inputs = new Pin[ni];
            for (int i = 0; i < ni; i++) inputs[i] = new Pin(this, true, i) { name = "IN" + i };
            outputs = new Pin[no];
            for (int i = 0; i < no; i++) outputs[i] = new Pin(this, false, i) { name = "OUT" + i };
        }

        public int id { get; private set; } = World.next_gate_id();

        // ---- state: IGate ---------------------------------------------------------------

        protected List<bool> new_outputs = new();
        bool outputs_changed;

        /// <summary>
        /// Die pins flach als bit-liste: ein 8-bit-pin liefert acht eintraege
        /// (MSB zuerst), ein normaler einen. `evaluate` sieht also nur bits -
        /// ein gate mit 8-bit-pins rechnet nicht anders als die anderen.
        /// </summary>
        static List<bool> flatten(Pin[] pins)
        {
            var bits = new List<bool>();
            foreach (Pin p in pins)
                for (int b = 0; b < p.bits; b++) bits.Add(p.bit_state[b]);
            return bits;
        }

        public bool read()
        {
            List<bool> ins = new List<bool>();
            foreach (Pin p in inputs)
                for (int b = 0; b < p.bits; b++) ins.Add(p.bit_from_wire(b));

            new_outputs = evaluate(ins);

            //zu kurz/zu lang: mit den alten ausgangs-bits auffuellen bzw. kappen
            List<bool> current = flatten(outputs);
            while (new_outputs.Count < current.Count) new_outputs.Add(current[new_outputs.Count]);
            while (new_outputs.Count > current.Count) new_outputs.RemoveAt(new_outputs.Count - 1);

            outputs_changed = false;
            for (int i = 0; i < current.Count; i++)
                if (new_outputs[i] != current[i]) { outputs_changed = true; break; }
            return outputs_changed;
        }

        public bool write()
        {
            bool changed = outputs_changed;

            int k = 0;
            foreach (Pin p in outputs)
                for (int b = 0; b < p.bits; b++, k++) p.bit_state[b] = new_outputs[k];

            foreach (Pin p in inputs)
                for (int b = 0; b < p.bits; b++) p.bit_state[b] = p.bit_from_wire(b);

            return changed;
        }

        /// <summary>
        /// The gate's logic: given the input vector, return the OUTPUT values
        /// it WANTS (they are applied later by write()).
        /// For stateful gates, cache internal state here (e.g. latches).
        /// </summary>
        protected abstract List<bool> evaluate(List<bool> inputs);

        /// <summary>Alle eingaenge als bits (ein 8-bit-pin liefert acht).</summary>
        public List<bool> get_inputs() => flatten(inputs);

        /// <summary>Alle ausgaenge als bits (ein 8-bit-pin liefert acht).</summary>
        public List<bool> get_outputs() => flatten(outputs);

        public List<IGate> get_fanout()
        {
            var fan = new List<IGate>();
            foreach (Pin p in outputs)
                foreach (Wire w in p.wires)
                    if (w.input != null && !fan.Contains(w.input.gate))
                        fan.Add(w.input.gate);
            return fan;
        }

        // ---- interaction -----------------------------------------------------------------

        /// <summary>User interaction happens between ticks (e.g. lever toggle).</summary>
        public virtual void on_right_click(GateBase self, bool pressed, Vector2 world_pos) { }

        /// <summary>Called once per frame for per-frame things (blink timers on traps, etc.).</summary>
        public virtual void frame_update(float dt) { }

        /// <summary>Future custom info text / titles per state (inspecting mode).</summary>
        public virtual string info_text() { return name; }

        public Pin pin_at(Vector2 world_pos)
        {
            foreach (Pin p in inputs) if (p.hit(world_pos)) return p;
            foreach (Pin p in outputs) if (p.hit(world_pos)) return p;
            return null;
        }

        // ---- rendering --------------------------------------------------------------------

        /// <summary>Cull test: is this gate's bounding box (incl. pins) visible in the camera view?</summary>
        public bool visible(Camera2D cam)
        {
            (int w, int h) = get_cell_size();
            float px = cell_x * Global.cell_size - Global.pin_size;
            float py = cell_y * Global.cell_size - Global.pin_size;
            float pw = w * Global.cell_size + 2 * Global.pin_size;
            float ph = h * Global.cell_size + 2 * Global.pin_size;
            return Raylib.CheckCollisionRecs(
                new Rectangle(px, py, pw, ph), Global.camera_rect(cam));
        }

        public virtual void draw()
        {
            (int w, int h) = get_cell_size();
            Global.draw_common(cell_x, cell_y, w, h, num_inputs, num_outputs,
                               draw_name ? name : "", inputs, outputs);
            draw_costum();
        }

        /// <summary>Custom visuals for gates that need more (displays, levers, lamps). Optional.</summary>
        public virtual void draw_costum() { }

        public void draw_common() { draw(); }
    }
}
