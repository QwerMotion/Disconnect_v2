using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// An instant connection between one output pin and one input pin.
    /// No gate delay: a wire's state is simply its driving output pin's state.
    ///
    /// Eine leitung hat eine farbe (index in Global.wire_colors) und traegt so
    /// viele bits wie ihre pins: ein 8-bit-kabel wird als stapel aus acht
    /// kurven gezeichnet, eine reihe pro bit.
    /// </summary>
    internal class Wire : IWire
    {
        public Pin output;
        public Pin input;

        /// <summary>Die farbe dieser leitung (index in Global.wire_colors).
        /// Neue leitungen bekommen die gerade gewaehlte farbe.</summary>
        public int color_index = Global.active_wire_color;

        /// <summary>Die farbe, in der diese leitung gezeichnet wird.</summary>
        public Color color => Global.wire_color_of(color_index);

        public Wire() { }

        public Wire(Pin output_pin, Pin input_pin)
        {
            output = output_pin;
            input = input_pin;
        }

        /// <summary>Wie viele bits diese leitung traegt (1 oder 8) - beide enden gleich.</summary>
        public int bits => output != null ? output.bits : (input != null ? input.bits : 1);

        // ---- IWire ------------------------------------------------------------------

        public bool get_state() => output.bit(0);
        public (Ipin output, Ipin input) get_connection() => (output, input);

        public bool connect(Ipin output_pin, Ipin input_pin)
        {
            if (output_pin.is_input() == input_pin.is_input()) return false;
            Pin op = output_pin.is_input() ? (Pin)input_pin : (Pin)output_pin;
            Pin ip = output_pin.is_input() ? (Pin)output_pin : (Pin)input_pin;
            connect_undirected(op, ip);
            return true;
        }

        // ---- helpers ------------------------------------------------------------------

        /// <summary>Real connect: only a valid output->input pair will register this wire.</summary>
        public bool connect_undirected(Pin a, Pin b)
        {
            // decide real direction
            Pin op, ip;
            if (!a.input && b.input) { op = a; ip = b; }
            else if (a.input && !b.input) { op = b; ip = a; }
            else return false; // both same kind

            //eine leitung traegt an beiden enden gleich viele bits: 1 bit auf
            //8 bit ist keine verbindung
            if (op.bits != ip.bits) return false;

            output = op;
            input = ip;

            output.wires.Add(this);   // output can feed many
            input.wires.Add(this);    // input kann jetzt MEHERE fan-in-traeger haben (or)

            World.register(this);
            return true;
        }

        /// <summary>
        /// The wire between these two pins, if one exists (null otherwise).
        /// Direction-independent: pins can be passed in any order.
        /// </summary>
        public static Wire find_between(Pin a, Pin b)
        {
            if (a == null || b == null) return null;
            if (a.bits != b.bits) return null;   //verschiedene breiten passen nie

            Pin from, to;
            if (!a.input && b.input) { from = a; to = b; }
            else if (a.input && !b.input) { from = b; to = a; }
            else return null; // same kind can never be wired

            foreach (Wire w in World.wires)
                if (w.output == from && w.input == to) return w;
            return null;
        }

        public void destroy(List<Wire> removal_notification_list)
        {
            if (output == null && input == null) return;
            // unlink from pins
            if (output != null && output.wires.Contains(this)) output.wires.Remove(this);
            if (input != null && input.wires.Contains(this)) input.wires.Remove(this);
            output = null;
            input = null;
            World.unregister(this);
        }

        /// <summary>Der abstand der beiden kontrollpunkte vom jeweiligen pin -
        /// er waechst mit der entfernung der pins.</summary>
        public static float control_distance(Vector2 a, Vector2 b)
            => MathF.Max(24f, MathF.Min(120f, MathF.Abs(b.X - a.X) * 0.4f));

        /// <summary>
        /// Die beiden kontrollpunkte der kurve: sie liegen EXAKT waagrecht neben
        /// ihren pins, und zwar nach AUSSEN - auf der seite, auf der der pin an
        /// seiner box sitzt (siehe <see cref="Pin.side"/>). Dadurch steht die
        /// kurve an beiden enden senkrecht zur kante: ein ausgang auf der rechten
        /// seite faehrt nach rechts los, ein eingang auf der rechten seite kommt
        /// von rechts an (genau das haben RL und LR). Frueher zeigte der
        /// kontrollpunkt IMMER nach rechts bzw. links, was fuer einen eingang auf
        /// der rechten seite die kurve einmal um die box herum fuehrte.
        ///
        /// Ohne pin-seite (freies ende, z.b. der mauszeiger) zeigt der
        /// kontrollpunkt stattdessen zum anderen ende hin - das ist dieselbe
        /// waagrechte abfahrt wie bei einem normalen pin.
        /// </summary>
        public static (Vector2 c1, Vector2 c2) curve_controls(Vector2 a, Vector2 b, PinSide? a_side, PinSide? b_side)
        {
            float dx = control_distance(a, b);

            float a_dir = a_side != null ? outward(a_side.Value) : (b.X >= a.X ? 1f : -1f);
            float b_dir = b_side != null ? outward(b_side.Value) : (a.X >= b.X ? 1f : -1f);

            return (new Vector2(a.X + dx * a_dir, a.Y),
                    new Vector2(b.X + dx * b_dir, b.Y));
        }

        /// <summary>Von der box weg: rechts +x, links -x.</summary>
        static float outward(PinSide side) => side == PinSide.right ? 1f : -1f;

        /// <summary>
        /// Eine glatte kubische bezier-kurve STRIKT zwischen den beiden pins
        /// (keine mittel-/wegpunkte): die kontrolle-punkte liegen waagrecht neben
        /// ihren pins (siehe curve_controls), dadurch steht die kurve an beiden
        /// endpunkten senkrecht zur kante (waagrechte ankunft/abfahrt) und
        /// schwingt dann im bogen zum ziel.
        /// </summary>
        static void draw_smooth_curve(Vector2 a, Vector2 b, Color c, float thickness, PinSide? a_side, PinSide? b_side)
        {
            (Vector2 c1, Vector2 c2) = curve_controls(a, b, a_side, b_side);

            //kubische bezier: start, kontrollpunkte, ziel - die kurve startet
            //exakt am start-pin und endet exakt am ziel-pin
            Raylib.DrawSplineBezierCubic(
                new Vector2[] { a, c1, c2, b },
                4, thickness, c);
        }

        public void draw(Camera2D cam)
        {
            if (output == null || input == null) return;

            //die eigene farbe bei signal, die ausgegraute form wenn das bit TIEF
            //liegt (wie stark, steht in Global.wire_grey_amount)
            Color high = color;
            Color low = Global.wire_color_passive(color_index);

            //ein 8-bit-kabel ist derselbe bogen, nur acht mal gestapelt - eine
            //kurve pro bit, eng beieinander (Global.wire8_spacing)
            for (int bit = 0; bit < bits; bit++)
            {
                Vector2 offset = Global.line_offset(bits, bit);
                draw_smooth_curve(output.center() + offset, input.center() + offset,
                                  output.bit(bit) ? high : low, Global.wire_thickness,
                                  output.side, input.side);
            }
        }

        /// <summary>
        /// Preview: dieselbe bezier-kurve wie die echte leitung, in der gerade
        /// gewaehlten farbe (und bei 8 bit genauso gestapelt).
        ///
        /// Die echte leitung laeuft IMMER vom ausgang zum eingang - nur so steht
        /// die kurve an beiden enden richtig (siehe draw_smooth_curve). Beginnt
        /// der user deshalb an einem EINGANGS-pin, wird die vorschau vom
        /// maus-ende (das spaeter der ausgang wird) zu diesem pin gezeichnet,
        /// sonst boege sie sich in die falsche richtung.
        /// </summary>
        public static void draw_preview_curve(Pin start, Pin hover, Vector2 mouse)
        {
            if (start == null) return;

            int bits = start.bits;
            Color c = Global.selected_wire_color;

            //das andere ende: der gehoverte pin, wenn er wirklich passt
            //(andere richtung, gleiche breite) - sonst die maus
            Pin? other = hover != null && !ReferenceEquals(hover, start) &&
                         hover.bits == bits && hover.input != start.input ? hover : null;

            for (int bit = 0; bit < bits; bit++)
            {
                //derselbe versatz wie beim echten kabel (Global.line_offset) -
                //die vorschau liegt also genau dort, wo die leitung haengen wird
                Vector2 offset = Global.line_offset(bits, bit);
                Vector2 pin_end = start.center() + offset;
                Vector2 other_end = other != null ? other.center() + offset : mouse + offset;

                //das andere ende: ein echter pin kennt seine seite selbst, ein
                //freies ende (die maus) zeigt zum pin hin (null)
                PinSide? other_side = other?.side;

                if (start.input)
                    draw_smooth_curve(other_end, pin_end, c, Global.wire_thickness + 1f, other_side, start.side);
                else
                    draw_smooth_curve(pin_end, other_end, c, Global.wire_thickness + 1f, start.side, other_side);
            }
        }
    }
}
