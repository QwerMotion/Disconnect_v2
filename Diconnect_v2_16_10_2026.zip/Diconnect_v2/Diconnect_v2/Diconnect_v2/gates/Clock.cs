using System;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// Eine uhr: wie ein lever (keine eingaenge, ein ausgang), aber sie
    /// toggelt ihren ausgang selbst. Nach dem platzieren (und bei jedem
    /// rechts-klick) wird gefragt, wie oft pro sekunde sie umschalten soll:
    /// 0.5 = alle 2 sekunden, 10 = 10x pro sekunde.
    /// </summary>
    [GateCategory("basic")]
    internal class CLOCK : GateBase
    {
        public override int num_inputs => 0;
        public override int num_outputs => 1;
        public override string type_id() => "CLOCK";

        /// <summary>Umschaltungen pro sekunde.</summary>
        public float hz = 1f;

        //wie viel zeit seit dem letzten umschalten vergangen ist
        float accumulator;

        public CLOCK()
        {
            name = "clock";
            draw_name = false;
            fixed_size = (1, 1);
            outputs[0].name = "OUT";
        }

        /// <summary>Rate aus einer nutzereingabe uebernehmen (unparsbar = bleibt).</summary>
        public void set_rate(string text)
        {
            if (text != null)
            {
                text = text.Trim().Replace(',', '.');
                if (float.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out float value) && value > 0f)
                    hz = Math.Clamp(value, 0.01f, 1000f);
            }
            accumulator = 0f;
            World.kick();
        }

        /// <summary>Ausgang sofort kippen, fanout neu auswerten (wires sind instant).</summary>
        public void toggle()
        {
            outputs[0].state = !outputs[0].state;
            foreach (IGate f in get_fanout())
                World.schedule(f);
            World.kick();
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            //keine eingaenge: den angelegten pegel behalten, sonst wuerde die
            //naechste auswertung die uhr zuruecksetzen
            return new List<bool> { outputs[0].state };
        }

        /// <summary>Echtzeit: die uhr laeuft unabhaengig von ticks_per_frame in der frame-schleife.</summary>
        public override void frame_update(float dt)
        {
            if (hz <= 0f || dt <= 0f) return;

            accumulator += dt;
            float period = 1f / hz;

            //auch mehrere umschaltungen pro frame sind moeglich (hohe frequenz)
            while (accumulator >= period)
            {
                accumulator -= period;
                toggle();
            }
        }

        public override string info_text() => $"clock {hz:0.##}/s";

        // ---- zustand speichern/laden (constructs) --------------------------------------

        public override Dictionary<string, string> save_state()
        {
            return new Dictionary<string, string>
            {
                { "hz", hz.ToString(CultureInfo.InvariantCulture) },
            };
        }

        public override void load_state(Dictionary<string, string> state)
        {
            if (state == null || !state.TryGetValue("hz", out string v)) return;
            if (float.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out float value) && value > 0f)
                hz = Math.Clamp(value, 0.01f, 1000f);
            accumulator = 0f;
        }

        public override void draw_costum()
        {
            //wie der lever: grosses 0/1, rot wenn der ausgang an ist
            (int w, int h) = get_cell_size();
            int px = cell_x * Global.cell_size;
            int py = cell_y * Global.cell_size;
            int pw = w * Global.cell_size;
            int ph = h * Global.cell_size;

            string text = outputs[0].state ? "1" : "0";
            Color col = outputs[0].state ? Global.activecolor : Global.standart_color;

            Vector2 size = Raylib.MeasureTextEx(Global.font, text, Global.font_size, Global.letter_spacing);
            Raylib.DrawTextEx(Global.font, text,
                new Vector2(px + (pw - size.X) / 2f, py + (ph - size.Y) / 2f),
                Global.font_size, Global.letter_spacing, col);
        }
    }
}
