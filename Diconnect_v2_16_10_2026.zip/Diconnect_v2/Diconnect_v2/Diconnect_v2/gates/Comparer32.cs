using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// 32-bit-vergleicher (16.16 fixed point): ist die OBERE zahl groesser als
    /// die untere? Ein einziges 1-bit-ergebnis - 1 = ja, 0 = nein.
    ///
    /// Die entscheidung faellt zwischen den beiden zahlen, nicht zwischen ihren
    /// roh-werten: -1 > -2 ist wahr, obwohl der roh-wert von -1 groesser
    /// aussieht als der von -2 (zweierkomplement). TC entscheidet also auch
    /// hier, ob beide zahlen vorzeichenlos oder vorzeichenbehaftet gelesen
    /// werden.
    /// </summary>
    [GateCategory("32bit")]
    internal class COMPARER32 : TwoNumber32
    {
        public override int num_outputs => 1;

        public COMPARER32()
        {
            name = "cmp32";
            //2x5: so schmal wie die anderen rechen-gates
            fixed_size = (2, 5);
            outputs[0].name = "A>B";
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            (double a, double b) = operands(inputs);
            return new List<bool> { a > b };
        }
    }
}
