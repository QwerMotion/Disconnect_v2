using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// Ein identity-gate (1x1 zellen): ein eingang, ein ausgang, der wert wird
    /// unveraendert durchgereicht. Es macht nichts mit dem signal, es verteilt
    /// es nur - praktisch als abzweigung, um eine leitung sauber weiterzufuehren.
    /// </summary>
    internal class IDENTITY : GateBase
    {
        public override int num_inputs => 1;
        public override int num_outputs => 1;
        public override string type_id() => "IDENTITY";

        public IDENTITY()
        {
            name = "ID";
            // 1x1 zellen, damit es sich wie die anderen kleinen gates verhaelt
            fixed_size = (1, 1);
            inputs[0].name = "IN";
            outputs[0].name = "OUT";
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            return new List<bool> { inputs[0] };
        }
    }
}
