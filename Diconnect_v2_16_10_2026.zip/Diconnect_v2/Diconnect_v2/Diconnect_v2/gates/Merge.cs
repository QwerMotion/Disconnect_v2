using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// Acht einzelne bits auf ein 8-bit-kabel (2x3 zellen): die eingaenge sind
    /// acht normale pins, der ausgang ist EIN 8-bit-pin.
    ///
    /// Das gegenstueck zu SPLIT und genauso gedankenlos: pin n hinein ist reihe
    /// n hinaus. Oben (index 0) liegt das MSB.
    /// </summary>
    [GateCategory("bits")]
    internal class MERGE : GateBase
    {
        public override int num_inputs => 8;
        public override int num_outputs => 1;

        public MERGE()
        {
            name = "merge";
            //platz fuer acht einzelne pins und den hohen 8-bit-pin
            fixed_size = (2, 3);

            for (int i = 0; i < num_inputs; i++)
                inputs[i].name = i == 0 ? "MSB"
                               : i == num_inputs - 1 ? "LSB"
                               : "bit" + (num_inputs - 1 - i);

            outputs[0].name = "OUT";   //acht bits: MSB (oben) bis LSB (unten)
            outputs[0].bits = 8;
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            //acht bits hinein, acht bits hinaus - reihe fuer reihe unveraendert
            return new List<bool>(inputs);
        }
    }
}
