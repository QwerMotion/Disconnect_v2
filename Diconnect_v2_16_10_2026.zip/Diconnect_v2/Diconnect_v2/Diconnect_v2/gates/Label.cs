using Raylib_cs;
using System;
using System.Collections.Generic;
using System.Numerics;

namespace Diconnect_v2
{
    /// <summary>
    /// Eine beschriftung: 1x1 zelle auf der organize-ebene, nur zur
    /// orientierung. Beim platzieren (und bei jedem rechts-klick darauf) wird
    /// nach ihrem text gefragt; sie zeichnet nur diesen text, sonst nichts.
    /// Ein leerer text entfernt sie wieder.
    /// </summary>
    [GateCategory("organize")]
    internal class LABEL : OrganizeItem
    {
        public override string type_id() => "LABEL";

        /// <summary>Der angezeigte text.</summary>
        public string text = "";

        public LABEL()
        {
            name = "label";
            fixed_size = (1, 1);
        }

        public void set_text(string value)
        {
            text = value == null ? "" : value.Trim();
        }

        public override string info_text() => text;

        /// <summary>Abstand vom linken zellrand bis zum textanfang.</summary>
        public const int text_padding = 4;

        /// <summary>
        /// Position (linke obere ecke) des textes: er beginnt links in der zelle
        /// und laeuft nach rechts (linksbuendig), nur senkrecht sitzt er mittig.
        /// Gemeinsame mathematik mit dem zeichnen, damit beides gleich bleibt.
        /// </summary>
        public Vector2 text_pos(string value)
        {
            (int w, int h) = get_cell_size();
            Vector2 m = Raylib.MeasureTextEx(Global.display_font, value, Global.label_fontsize, Global.letter_spacing);

            return new Vector2(cell_x * Global.cell_size + text_padding,
                               cell_y * Global.cell_size + (h * Global.cell_size - m.Y) / 2f);
        }

        public override void draw()
        {
            if (string.IsNullOrEmpty(text)) return;

            //standart-raylib-schrift: der text kommt vom user, die pixy-schrift
            //kennt nicht alle zeichen
            Raylib.DrawTextEx(Global.display_font, text, text_pos(text),
                Global.label_fontsize, Global.letter_spacing, Global.standart_color);
        }

        // ---- zustand speichern/laden (constructs) --------------------------------------

        public override Dictionary<string, string> save_state()
        {
            return new Dictionary<string, string> { { "text", text } };
        }

        public override void load_state(Dictionary<string, string> state)
        {
            if (state == null) return;
            if (state.TryGetValue("text", out string value)) text = value;
        }
    }
}
