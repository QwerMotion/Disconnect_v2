using System;
using System.Collections.Generic;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// D-flipflop: D und CLK (2x2 zellen), ein ausgang Q.
    /// Bei steigender taktflanke uebernimmt Q den wert von D, sonst wird gehalten.
    /// </summary>
    [GateCategory("latches")]
    internal class DFF : FlipFlop
    {
        public override int num_inputs => 2;
        public override string type_id() => "DFF";

        public DFF()
        {
            name = "D";
            inputs[0].name = "D";
            inputs[1].name = "CLK";
            outputs[0].name = "Q";
        }

        protected override bool next_state(List<bool> inputs)
        {
            return inputs[0];   //D uebernehmen
        }
    }
}
