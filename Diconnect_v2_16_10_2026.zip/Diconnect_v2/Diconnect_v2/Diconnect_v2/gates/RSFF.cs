using System;
using System.Collections.Generic;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// RS-flipflop: S, R und CLK (2x2 zellen), ein ausgang Q.
    /// Der takt sitzt MITTIG zwischen S und R (pin-reihenfolge S, CLK, R).
    /// Bei steigender taktflanke:
    ///   S=1, R=0 -> Q=1 (setzen)
    ///   S=0, R=1 -> Q=0 (ruecksetzen)
    ///   S=R=0   -> halten
    ///   S=R=1   -> ungueltig, es wird gehalten
    /// </summary>
    [GateCategory("latches")]
    internal class RSFF : FlipFlop
    {
        public override int num_inputs => 3;
        public override string type_id() => "RSFF";

        //takt in der mitte: S, CLK, R
        protected override int clk_index => 1;

        public RSFF()
        {
            name = "SR-FF";
            inputs[0].name = "S";
            inputs[1].name = "CLK";
            inputs[2].name = "R";
            outputs[0].name = "Q";
        }

        protected override bool next_state(List<bool> inputs)
        {
            bool s = inputs[0], r = inputs[2];
            if (s && !r) return true;
            if (r && !s) return false;
            return q;   //halten (auch im ungueltigen fall S=R=1)
        }
    }
}
