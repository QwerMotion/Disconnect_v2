using System;
using System.Collections.Generic;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// JK-flipflop: J, K und CLK (2x2 zellen), ein ausgang Q.
    /// Der takt sitzt MITTIG zwischen J und K (pin-reihenfolge J, CLK, K).
    /// Bei steigender taktflanke:
    ///   J=0, K=0 -> halten
    ///   J=1, K=0 -> Q=1 (setzen)
    ///   J=0, K=1 -> Q=0 (ruecksetzen)
    ///   J=1, K=1 -> toggeln
    /// </summary>
    [GateCategory("latches")]
    internal class JKFF : FlipFlop
    {
        public override int num_inputs => 3;
        public override string type_id() => "JKFF";

        //takt in der mitte: J, CLK, K
        protected override int clk_index => 1;

        public JKFF()
        {
            name = "JK-FF";
            inputs[0].name = "J";
            inputs[1].name = "CLK";
            inputs[2].name = "K";
            outputs[0].name = "Q";
        }

        protected override bool next_state(List<bool> inputs)
        {
            bool j = inputs[0], k = inputs[2];
            if (j && k) return !q;   //toggeln
            if (j) return true;      //setzen
            if (k) return false;     //ruecksetzen
            return q;                //halten
        }
    }
}
