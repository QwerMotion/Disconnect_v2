using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// Gemeinsame basis der flipflops (RS, JK, D, T): 2x2 zellen, ein
    /// gespeicherter zustand Q (ein ausgang) und die flankenlogik.
    ///
    /// Alle flipflops sind flankengesteuert: der takt-pin (clk_index) ist der
    /// takt (CLK). Nur bei einer steigenden flanke (0 -> 1) uebernimmt
    /// next_state(); sonst bleibt Q einfach gespeichert.
    ///
    /// Der name (JK-FF, SR-FF, D, T) steht oben links in der box, so wie bei
    /// allen anderen gates - der gespeicherte wert wird NICHT angezeigt.
    /// </summary>
    internal abstract class FlipFlop : GateBase
    {
        /// <summary>Der gespeicherte zustand (letzter uebernommener wert).</summary>
        protected bool q;

        //takt-pegel der letzten auswertung, fuer die flankenerkennung
        bool last_clk;

        protected FlipFlop()
        {
            fixed_size = (2, 2);   //alle flipflops sind 2x2 zellen
        }

        public override int num_outputs => 1;

        /// <summary>Index des takt-pins. Flipflops mit zwei signal-eingaengen
        /// (JK, RS) legen den takt in die MITTE, D und T behalten ihn unten.</summary>
        protected virtual int clk_index => num_inputs - 1;

        protected override List<bool> evaluate(List<bool> inputs)
        {
            bool clk = inputs[clk_index];
            if (clk && !last_clk)
                q = next_state(inputs);   //steigende flanke: neuen wert uebernehmen
            last_clk = clk;

            return new List<bool> { q };
        }

        /// <summary>Welchen wert Q bei einer steigenden taktflanke annehmen soll.</summary>
        protected abstract bool next_state(List<bool> inputs);

        // ---- zustand speichern/laden (constructs) --------------------------------------

        public override Dictionary<string, string> save_state()
        {
            return new Dictionary<string, string>
            {
                { "q", q ? "1" : "0" },
                { "clk", last_clk ? "1" : "0" },
            };
        }

        public override void load_state(Dictionary<string, string> state)
        {
            if (state == null) return;
            if (state.TryGetValue("q", out string qv)) q = qv != "0";
            if (state.TryGetValue("clk", out string cv)) last_clk = cv != "0";
            if (outputs.Length > 0) outputs[0].state = q;
        }
    }
}
