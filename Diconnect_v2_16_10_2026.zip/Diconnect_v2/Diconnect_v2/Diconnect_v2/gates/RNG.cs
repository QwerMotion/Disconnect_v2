using System;
using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// Ein zufalls-generator (1x1 zellen): ein takt-eingang (CLK), ein ausgang.
    ///
    /// Ein neues bit gibt es NUR bei einem takt-impuls, also bei einem echten
    /// wechsel von tief nach hoch am CLK-pin. Ohne impuls passiert nichts:
    ///
    ///   * beim platzieren steht das gate auf 0 (es wuerfelt nicht von selbst)
    ///   * ein hoher takt bleibt ein einziges bit (kein nachwuerfeln)
    ///   * eine fallende flanke wuerfelt nicht
    ///   * ein takt, der schon hoch liegt wenn das gate auftaucht, gilt nicht
    ///     als impuls: erst tief, dann hoch ist ein impuls (siehe last_clk)
    ///
    /// Ein takt-impuls liefert also genau ein bit.
    ///
    /// Wie jedes normale gate zeichnet es nur seinen namen und seine box -
    /// den wert sieht man an den pins (und mit Tab an ihren namen).
    /// </summary>
    internal class RNG : GateBase
    {
        public override int num_inputs => 1;
        public override int num_outputs => 1;
        public override string type_id() => "RNG";

        /// <summary>Das gewuerfelte bit (der ausgang).</summary>
        public bool bit;

        //takt-pegel der letzten auswertung, fuer die flankenerkennung.
        //startet HOCH: der erste pegel, den das gate sieht, ist nie ein impuls -
        //ein takt, der beim platzieren schon anliegt, muss erst wieder tief und
        //dann hoch gehen (ein echter impuls eben).
        bool last_clk = true;

        public RNG()
        {
            name = "rng";
            fixed_size = (1, 1);
            inputs[0].name = "CLK";
            outputs[0].name = "OUT";

            //kein wuerfeln beim bauen: bit bleibt 0 bis zum ersten takt-impuls
        }

        /// <summary>Ein zufaelliges bit.</summary>
        public static bool next_bit() => Random.Shared.Next(2) == 1;

        protected override List<bool> evaluate(List<bool> inputs)
        {
            bool clk = inputs[0];
            if (clk && !last_clk) bit = next_bit();   //nur der impuls tief -> hoch wuerfelt
            last_clk = clk;
            return new List<bool> { bit };
        }

        public override string info_text() => $"rng {(bit ? 1 : 0)}";

        // ---- zustand speichern/laden (constructs) --------------------------------------

        public override Dictionary<string, string> save_state()
        {
            return new Dictionary<string, string>
            {
                { "bit", bit ? "1" : "0" },
                { "clk", last_clk ? "1" : "0" },   //takt-pegel: sonst gäbe es beim laden eine flanke
            };
        }

        public override void load_state(Dictionary<string, string> state)
        {
            if (state == null) return;
            if (state.TryGetValue("bit", out string b)) bit = b != "0";
            if (state.TryGetValue("clk", out string c)) last_clk = c != "0";
            outputs[0].state = bit;   //der ausgang ist sofort wieder so wie beim speichern
        }
    }
}
