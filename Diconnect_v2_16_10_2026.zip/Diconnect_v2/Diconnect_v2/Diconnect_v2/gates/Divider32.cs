using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// 32-bit-teiler (16.16 fixed point), wie ein taschenrechner:
    /// OBERE zahl / untere zahl.
    ///
    /// Das ergebnis braucht 16 bruchstellen, die der roh-wert auch hat - die
    /// zahl wird deshalb als zahl dividiert und neu gerundet, nicht als
    /// bit-schieberei (siehe Number32).
    ///
    /// Durch 0 teilen ist nicht darstellbar (unendlich passt nicht in 32 bit):
    /// das gate schreibt dann 0.
    /// </summary>
    [GateCategory("32bit")]
    internal class DIVIDER32 : TwoNumber32
    {
        public override int num_outputs => 4;

        public DIVIDER32()
        {
            name = "div32";
            //2x5: so schmal wie die anderen rechen-gates
            fixed_size = (2, 5);
            set_result_pins();
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            (double a, double b) = operands(inputs);
            return raw_bits(raw_of(a / b));
        }
    }
}
