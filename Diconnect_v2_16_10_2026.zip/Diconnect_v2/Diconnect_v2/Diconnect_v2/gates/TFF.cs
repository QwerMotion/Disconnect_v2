using System;
using System.Collections.Generic;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// T-flipflop: T und CLK (2x2 zellen), ein ausgang Q.
    /// Bei steigender taktflanke: T=1 -> toggeln, T=0 -> halten.
    /// </summary>
    [GateCategory("latches")]
    internal class TFF : FlipFlop
    {
        public override int num_inputs => 2;
        public override string type_id() => "TFF";

        public TFF()
        {
            name = "T";
            inputs[0].name = "T";
            inputs[1].name = "CLK";
            outputs[0].name = "Q";
        }

        protected override bool next_state(List<bool> inputs)
        {
            return inputs[0] ? !q : q;
        }
    }
}
