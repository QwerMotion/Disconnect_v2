using System;
using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// Ein zufalls-generator fuer ein ganzes byte (2x3 zellen): ein takt-eingang
    /// (CLK) und 8 ausgaenge.
    ///
    /// Ein neues byte gibt es NUR bei einem takt-impuls, also bei einem echten
    /// wechsel von tief nach hoch am CLK-pin. Ohne impuls passiert nichts:
    ///
    ///   * beim platzieren steht das gate auf 0 (es wuerfelt nicht von selbst)
    ///   * ein hoher takt bleibt ein einziges byte (kein nachwuerfeln)
    ///   * eine fallende flanke wuerfelt nicht
    ///   * ein takt, der schon hoch liegt wenn das gate auftaucht, gilt nicht
    ///     als impuls: erst tief, dann hoch ist ein impuls (siehe last_clk)
    ///
    /// Ein takt-impuls liefert also genau ein byte.
    ///
    /// Wie jedes normale gate zeichnet es nur seinen namen und seine box -
    /// den wert sieht man an den pins (und mit Tab an ihren namen).
    ///
    /// Pin-reihenfolge (pin_rect zeichnet index 0 ganz OBEN): der oberste
    /// ausgang (index 0) ist das MSB, der unterste (index 7) das LSB - genau
    /// wie bei den anzeigen (siehe DIGIT/ASCII).
    /// </summary>
    internal class RNG8 : GateBase
    {
        public override int num_inputs => 1;
        public override int num_outputs => 8;
        public override string type_id() => "RNG8";

        /// <summary>Das gewuerfelte byte (0-255).</summary>
        public int value;

        //takt-pegel der letzten auswertung, fuer die flankenerkennung.
        //startet HOCH: der erste pegel, den das gate sieht, ist nie ein impuls -
        //ein takt, der beim platzieren schon anliegt, muss erst wieder tief und
        //dann hoch gehen (ein echter impuls eben).
        bool last_clk = true;

        public RNG8()
        {
            name = "rng8";
            //8 pins brauchen hoehe, damit neben jedem pin platz ist
            fixed_size = (2, 3);
            inputs[0].name = "CLK";
            name_pins();

            //kein wuerfeln beim bauen: value bleibt 0 bis zum ersten takt-impuls
        }

        void name_pins()
        {
            for (int i = 0; i < num_outputs; i++)
                outputs[i].name = i == 0 ? "MSB" : (i == num_outputs - 1 ? "LSB" : "bit" + (num_outputs - 1 - i));
        }

        /// <summary>Ein zufaelliges byte.</summary>
        public static int next_byte() => Random.Shared.Next(256);

        /// <summary>Den wert auf die 8 ausgangs-pins legen (index 0 = msb).</summary>
        void apply()
        {
            for (int bit = 0; bit < num_outputs; bit++)
                outputs[bit].state = ((value >> (num_outputs - 1 - bit)) & 1) != 0;
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            bool clk = inputs[0];
            if (clk && !last_clk) value = next_byte();   //nur der impuls tief -> hoch wuerfelt
            last_clk = clk;

            var result = new List<bool>();
            for (int bit = 0; bit < num_outputs; bit++)
                result.Add(((value >> (num_outputs - 1 - bit)) & 1) != 0);
            return result;
        }

        public override string info_text() => $"rng8 {value}";

        // ---- zustand speichern/laden (constructs) --------------------------------------

        public override Dictionary<string, string> save_state()
        {
            return new Dictionary<string, string>
            {
                { "value", value.ToString() },
                { "clk", last_clk ? "1" : "0" },   //takt-pegel: sonst gäbe es beim laden eine flanke
            };
        }

        public override void load_state(Dictionary<string, string> state)
        {
            if (state == null) return;
            if (state.TryGetValue("value", out string v) && int.TryParse(v, out int parsed))
                value = Math.Clamp(parsed, 0, 255);
            if (state.TryGetValue("clk", out string c)) last_clk = c != "0";
            apply();   //die pins sind sofort wieder so wie beim speichern
        }
    }
}
