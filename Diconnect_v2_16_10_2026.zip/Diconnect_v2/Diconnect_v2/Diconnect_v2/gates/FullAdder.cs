using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// Ein volladdierer (2x2 zellen, kategorie "basic"): drei eingaenge und zwei
    /// ausgaenge, alles einzelne bits.
    ///
    ///   eingaenge  (von oben)  a, b, carry
    ///   ausgaenge  (von oben)  sum, carry_out
    ///
    ///   sum       = a XOR b XOR carry
    ///   carry_out = (a AND b) OR (carry AND (a XOR b))
    ///
    /// Die pin-reihenfolge ist absichtlich so gewaehlt (a oben, b in der mitte,
    /// carry unten): der uebertrag liegt damit immer am unteren rand der box.
    /// Reiht man mehrere stufen aneinander (ein ripple-carry-adder), wandert der
    /// carry nie mitten in einen pin-stapel, und die beiden pins heissen
    /// ausdruecklich carry und carry_out - ein vertauschtes paar ist damit auf
    /// einen blick zu sehen (hotkey tab).
    /// </summary>
    [GateCategory("basic")]
    internal class FULLADDER : GateBase
    {
        public override int num_inputs => 3;
        public override int num_outputs => 2;

        public FULLADDER()
        {
            name = "FA";
            fixed_size = (2, 2);

            inputs[0].name = "a";          //oben
            inputs[1].name = "b";          //mitte
            inputs[2].name = "carry";      //unten

            outputs[0].name = "sum";       //oben
            outputs[1].name = "carry_out"; //unten
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            bool a = inputs[0];
            bool b = inputs[1];
            bool carry = inputs[2];

            //zwei halbaddierer hintereinander: erst a+b, dann + carry
            bool half_sum = a ^ b;

            return new List<bool>
            {
                half_sum ^ carry,                    //sum
                (a && b) || (carry && half_sum),     //carry_out
            };
        }
    }
}
