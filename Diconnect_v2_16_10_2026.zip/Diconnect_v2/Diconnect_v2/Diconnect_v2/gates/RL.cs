using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// Die laufrichtung einer leitung drehen (1x1 zellen, kategorie "basic"):
    /// ein eingang und ein ausgang, beide auf der RECHTEN kante der box - der
    /// eingang oben, der ausgang darunter. Das gegenstueck LR tut dasselbe links.
    ///
    /// Eine leitung, die von rechts kommt, endet hier am oberen pin; die naechste
    /// leitung faengt am unteren pin an derselben kante an und laeuft von dort
    /// weiter. So kann ein strang an einer kante wenden, ohne dass man dafuer ein
    /// anderes gate verbiegt oder die leitung quer durch die schaltung zieht.
    ///
    /// Gerechnet wird nichts: der wert geht unveraendert durch (wie IDENTITY, nur
    /// mit beiden pins an einer kante). Wie jedes gate kostet auch dieses eine
    /// taktstufe - eine leitung selbst ist dagegen sofort.
    ///
    /// Beide pins liegen auf einer seite, weil <see cref="input_side"/> und
    /// <see cref="output_side"/> dieselbe seite nennen; sie teilen sich dann
    /// deren stapel (siehe GateBase.pins_on).
    /// </summary>
    [GateCategory("basic")]
    internal class RL : GateBase
    {
        public override int num_inputs => 1;
        public override int num_outputs => 1;

        //beide pins an der rechten kante (der eingang liegt oben, weil die
        //eingaenge im stapel zuerst kommen)
        public override PinSide input_side => PinSide.right;
        public override PinSide output_side => PinSide.right;

        public RL()
        {
            name = "RL";
            fixed_size = (1, 1);
            inputs[0].name = "IN";
            outputs[0].name = "OUT";
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            return new List<bool> { inputs[0] };
        }
    }
}
