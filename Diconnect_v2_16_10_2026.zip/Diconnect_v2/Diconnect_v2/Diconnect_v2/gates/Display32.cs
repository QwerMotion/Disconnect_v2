using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// Eine anzeige fuer 32-bit-zahlen (16.16 fixed point): keine ausgaenge,
    /// vier 8-bit-kabel eingang und ganz unten das 1-bit-TC des displays - wie
    /// beim kleinen DISPLAY ist der unterste pin der zweierkomplement-ausloeser.
    ///
    /// Pin-reihe von oben: B3 B2 B1 B0 TC, also das hoechste byte der zahl
    /// zuerst (B3/B2 = der ganze teil, B1/B0 = der bruchteil).
    ///
    /// TC aus = vorzeichenlos (0 .. 65535.99998), an = zweierkomplement
    /// (-32768 .. 32767.99998). Gezeigt wird die zahl mit bis zu fuenf
    /// nachkommastellen und ohne ueberfluessige nullen ("3.75", "-0.5", "12") -
    /// die kleinste stufe von 16.16 ist 1/65536 = 0.00002, mehr stellen wuerden
    /// also nichts neues zeigen.
    /// </summary>
    [GateCategory("displays")]
    internal class DISPLAY32 : Number32
    {
        public override int num_inputs => 5;
        public override int num_outputs => 0;

        /// <summary>Der zuletzt gelesene wert (zwischen den ticks gemerkt).</summary>
        public double shown;

        public DISPLAY32()
        {
            name = "disp32";   //wird nicht gezeichnet (draw_name), nur der name des gates
            draw_name = false;
            //platz fuer die zahl und die fuenf pins - eine zelle breiter als
            //die automatische groesse (4x3), damit die zahl mehr raum hat
            fixed_size = (5, 3);

            for (int i = 0; i < 4; i++) inputs[i].bits = 8;
            name_bytes(inputs, 0, "B");
            inputs[4].name = "TC";
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            //der unterste pin (index 4) ist der ausloeser, die vier kabel davor
            //sind die zahl (kabel 0 zuerst, MSB-seite)
            bool twos_complement = inputs[32];
            shown = value_of(read_raw(inputs, 0), twos_complement);

            return new List<bool>();   //anzeige hat keine ausgaenge
        }

        public override string info_text() => $"display {format_value(shown)}";

        public override void draw_costum()
        {
            (int w, int h) = get_cell_size();
            int px = cell_x * Global.cell_size;
            int py = cell_y * Global.cell_size;
            int pw = w * Global.cell_size - 8;
            int ph = h * Global.cell_size - 8;

            //dunkler rahmen im lcd-look, wie bei den anderen anzeigen
            Raylib.DrawRectangle(px + 4, py + 4, pw, ph, new Color(20, 20, 20, 255));

            //standart-raylib-schrift: die pixy-schrift kennt nicht alle ascii-zeichen
            string text = format_value(shown);
            Font f = Global.display_font;

            //so gross wie moeglich, aber IMMER in die box: eine 32-bit-zahl kann
            //lang werden ("-32768", "0.00002"), dann wird die schrift kleiner
            float size = Global.font_size * 1.5f;
            Vector2 m = Raylib.MeasureTextEx(f, text, size, Global.letter_spacing);
            if (m.X > pw - 8 && m.X > 0f)
            {
                size *= (pw - 8) / m.X;
                m = Raylib.MeasureTextEx(f, text, size, Global.letter_spacing);
            }

            Raylib.DrawTextEx(f, text,
                new Vector2(px + 4 + (pw - m.X) / 2f, py + 4 + (ph - m.Y) / 2f),
                size, Global.letter_spacing, Color.Red);
        }
    }
}
