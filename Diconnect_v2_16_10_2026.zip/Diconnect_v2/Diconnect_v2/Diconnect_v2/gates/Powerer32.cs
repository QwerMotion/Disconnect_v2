using System;
using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// 32-bit-potenzierer (16.16 fixed point): OBERE zahl hoch untere zahl.
    /// Die obere zahl ist die basis, die untere der exponent - 2 hoch 3 = 8.
    ///
    /// Der exponent darf ein bruch sein, und genau das macht das gate
    /// interessant: 0.5 ist die 2. wurzel, 0.25 die 4. wurzel, 1.5 die
    /// quadratwurzel mal der zahl selbst.
    ///
    /// Gerechnet wird mit ganz normalem C#-potenzieren (Math.Pow) und dann
    /// zurueckgeschrieben (siehe Number32). Eine negative basis mit einem
    /// bruch-exponenten hat keine reelle loesung - das ergebnis ist NaN und das
    /// gate schreibt 0.
    /// </summary>
    [GateCategory("32bit")]
    internal class POWERER32 : TwoNumber32
    {
        public override int num_outputs => 4;

        public POWERER32()
        {
            name = "pow32";
            //2x5: so schmal wie die anderen rechen-gates
            fixed_size = (2, 5);
            set_result_pins();
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            (double a, double b) = operands(inputs);
            return raw_bits(raw_of(Math.Pow(a, b)));
        }
    }
}
