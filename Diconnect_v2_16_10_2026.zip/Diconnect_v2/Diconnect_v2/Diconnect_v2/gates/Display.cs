using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// A display gate: no outputs, 9 inputs. Visual pins top->bottom are:
    /// MSB ... LSB, then the two's-complement trigger at the very bottom.
    ///
    /// trigger LOW  = unsigned: value = IN1 + 2*IN2 + ... + 128*IN8   (0..255)
    /// trigger HIGH = two's complement: negative numbers included (-128..127)
    /// </summary>
    [GateCategory("displays")]
    internal class Display : GateBase
    {
        public override int num_inputs => 9;
        public override int num_outputs => 0;
        public override string type_id() => "DISPLAY";

        int shown_value;

        public Display()
        {
            name = "display";
            draw_name = false;
            //9 pins brauchen platz: 4x3 zellen, fest, damit die zahl immer passt
            fixed_size = (4, 3);
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            // pin_rect reiht die pins von OBEN (index 0) nach UNTEN (index 8).
            // unten (index 8) = trigger, darueber lsb (index 7) bis msb (index 0).
            bool twos_complement = inputs[8];

            int value = 0;
            for (int bit = 0; bit < 8; bit++)
                if (inputs[7 - bit]) value |= 1 << bit;

            shown_value = twos_complement && (value & 0x80) != 0 ? value - 256 : value;
            return new List<bool>();   // display hat keine ausgaenge
        }

        public override void draw_costum()
        {
            (int w, int h) = get_cell_size();
            int px = cell_x * Global.cell_size;
            int py = cell_y * Global.cell_size;
            int pw = w * Global.cell_size - 8;
            int ph = h * Global.cell_size - 8;

            // dunkler rahmen "lcd-look"
            Raylib.DrawRectangle(px + 4, py + 4, pw, ph, new Color(20, 20, 20, 255));

            //standart-raylib-schrift: die pixy-schrift kennt nicht alle ascii-zeichen
            string number = shown_value.ToString();
            Font f = Global.display_font;
            float size = Global.font_size * 2f;
            Vector2 m = Raylib.MeasureTextEx(f, number, size, Global.letter_spacing);

            //mittig im "lcd"
            Raylib.DrawTextEx(f, number,
                new Vector2(px + 4 + (pw - m.X) / 2f, py + 4 + (ph - m.Y) / 2f),
                size, Global.letter_spacing, Color.Red);
        }
    }
}
