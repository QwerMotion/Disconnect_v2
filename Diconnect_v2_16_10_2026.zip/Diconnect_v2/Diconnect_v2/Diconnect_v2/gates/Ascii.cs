using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// Ascii-anzeige: 8 eingaenge, keine ausgaenge. Zeigt das zeichen zum
    /// binaerwert der pins (druckbare zeichen 32-126), sonst den zahlenwert.
    ///
    /// Der oberste pin (index 0) ist das MSB, der unterste (index 7) das LSB.
    /// </summary>
    [GateCategory("displays")]
    internal class ASCII : GateBase
    {
        public override int num_inputs => 8;
        public override int num_outputs => 0;
        public override string type_id() => "ASCII";

        //letzter ausgerechneter wert (0-255), zwischen den ticks gemerkt
        public int shown_value;

        public ASCII()
        {
            name = "ascii";
            draw_name = false;
            //8 pins brauchen hoehe, und das zeichen soll gross lesbar sein
            fixed_size = (2, 3);
            name_pins();
        }

        void name_pins()
        {
            for (int i = 0; i < num_inputs; i++)
                inputs[i].name = i == 0 ? "MSB" : (i == num_inputs - 1 ? "LSB" : "bit" + (num_inputs - 1 - i));
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            //index 0 = oberster pin = msb ... unterster = lsb (bit0)
            int value = 0;
            for (int bit = 0; bit < num_inputs; bit++)
                if (inputs[num_inputs - 1 - bit]) value |= 1 << bit;

            shown_value = value;
            return new List<bool>();   //anzeige hat keine ausgaenge
        }

        public override void draw_costum()
        {
            (int w, int h) = get_cell_size();
            int px = cell_x * Global.cell_size;
            int py = cell_y * Global.cell_size;
            int pw = w * Global.cell_size - 8;
            int ph = h * Global.cell_size - 8;

            //dunkler rahmen im lcd-look, wie beim grossen display
            Raylib.DrawRectangle(px + 4, py + 4, pw, ph, new Color(20, 20, 20, 255));

            //druckbares zeichen als buchstabe, alles andere (steuerzeichen) als zahl
            string text = shown_value >= 32 && shown_value < 127
                ? ((char)shown_value).ToString()
                : shown_value.ToString();

            //standart-raylib-schrift: die pixy-schrift kennt nicht alle ascii-zeichen
            Font f = Global.display_font;
            float size = Global.font_size * 2f;
            Vector2 m = Raylib.MeasureTextEx(f, text, size, Global.letter_spacing);
            Raylib.DrawTextEx(f, text,
                new Vector2(px + 4 + (pw - m.X) / 2f, py + 4 + (ph - m.Y) / 2f),
                size, Global.letter_spacing, Color.Red);
        }
    }
}
