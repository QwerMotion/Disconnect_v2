using System;
using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// Ein zaehler fuer 32-bit-zahlen (16.16 fixed point): 2x 8-bit-kabel
    /// ausgang - der GANZE teil der zahl, und weil der 16 bit breit ist, ist
    /// das ein 16-bit-zaehler (0 .. 65535).
    ///
    /// Zwei eingaenge: CLK und RESET.
    ///
    ///   * CLK: gezaehlt wird nur bei einem takt-impuls, also bei einem echten
    ///     wechsel von tief nach hoch - genau wie bei RNG8. Eine fallende
    ///     flanke zaehlt nicht, ein hoher takt zaehlt einmal, und ein takt, der
    ///     schon hoch liegt, wenn das gate auftaucht, ist kein impuls.
    ///   * RESET: liegt er hoch, steht der zaehler auf 0 (und zwar sofort, nicht
    ///     erst beim naechsten takt). Der takt wird waehrend des resets trotzdem
    ///     mitverfolgt: das LOSLASSEN von reset ist kein takt-impuls.
    ///
    /// Gezaehlt wird in ganzen schritten (der bruchteil bleibt 0), also
    /// 0, 1, 2, ... - bei 65535 geht es wieder auf 0.
    /// </summary>
    [GateCategory("32bit")]
    internal class COUNTER32 : Number32
    {
        public override int num_inputs => 2;
        public override int num_outputs => 2;

        /// <summary>Der ganze teil der zahl (0 .. 65535).</summary>
        public int value;

        //takt-pegel der letzten auswertung, fuer die flankenerkennung.
        //startet HOCH: der erste pegel, den das gate sieht, ist nie ein impuls -
        //ein takt, der beim platzieren schon anliegt, muss erst wieder tief und
        //dann hoch gehen (ein echter impuls eben).
        bool last_clk = true;

        public COUNTER32()
        {
            name = "cnt32";
            //2x2: schmal wie die anderen, nur so hoch wie die zwei kabel-pins
            fixed_size = (2, 2);
            inputs[0].name = "CLK";
            inputs[1].name = "RESET";

            //der ganze teil als zwei bytes: oben das hohe (bit 15-8), unten das tiefe
            outputs[0].bits = 8;
            outputs[1].bits = 8;
            outputs[0].name = "HI";
            outputs[1].name = "LO";
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            bool clk = inputs[0];
            bool reset = inputs[1];

            if (reset) value = 0;                                  //reset haelt ihn auf 0
            else if (clk && !last_clk) value = (value + 1) & 0xFFFF;   //nur die steigende flanke zaehlt

            last_clk = clk;   //auch waehrend reset mitgefuehrt: loslassen ist kein takt

            //WICHTIG: hier nur den GEWUENSCHTEN ausgang zurueckgeben - die pins
            //NICHT selbst schreiben. read() vergleicht das ergebnis mit den pins,
            //um zu merken, ob sich etwas geaendert hat (GateBase.write meldet das
            //dann der fanout). Wer die pins hier schon setzt, macht daraus "nichts
            //geaendert": der zaehler zaehlt zwar, aber anzeige, lampe und jedes
            //weitere gate dahinter erfahren vom neuen wert nie etwas (erst das
            //loeschen einer fanin weckt sie wieder auf).
            //Genau so machen es auch RNG/RNG8 - apply() gibt es nur fuers laden.
            return bits_of(value);
        }

        /// <summary>Den ganzen teil sofort auf die zwei ausgangs-kabel legen. Nur fuers
        /// LADEN: nach einem construct stimmt der zaehler damit vor dem ersten tick
        /// (in evaluate darf das nicht passieren, siehe dort).</summary>
        void apply()
        {
            List<bool> bits = bits_of(value);
            for (int i = 0; i < 16; i++)
            {
                if (i < 8) outputs[0].set_bit(i, bits[i]);
                else outputs[1].set_bit(i - 8, bits[i]);
            }
        }

        /// <summary>Der ganze teil als 16 bit, MSB zuerst.</summary>
        static List<bool> bits_of(int v)
        {
            var bits = new List<bool>();
            for (int i = 15; i >= 0; i--) bits.Add(((v >> i) & 1) != 0);
            return bits;
        }

        public override string info_text() => $"counter {value}";

        // ---- zustand speichern/laden (constructs) --------------------------------------

        public override Dictionary<string, string> save_state()
        {
            return new Dictionary<string, string>
            {
                { "value", value.ToString() },
                { "clk", last_clk ? "1" : "0" },   //takt-pegel: sonst gäbe es beim laden eine flanke
            };
        }

        public override void load_state(Dictionary<string, string> state)
        {
            if (state == null) return;
            if (state.TryGetValue("value", out string v) && int.TryParse(v, out int parsed))
                value = Math.Clamp(parsed, 0, 0xFFFF);
            if (state.TryGetValue("clk", out string c)) last_clk = c != "0";
            apply();   //die pins sind sofort wieder so wie beim speichern
        }
    }
}
