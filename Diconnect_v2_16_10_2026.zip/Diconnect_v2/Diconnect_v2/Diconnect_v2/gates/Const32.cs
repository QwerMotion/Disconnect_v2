using System;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// Eine konstante 32-bit-zahl (16.16 fixed point, 2x3 zellen): KEINE
    /// eingaenge, vier 8-bit-kabel ausgang - naemlich genau die zahl, die der
    /// user eingetippt hat.
    ///
    /// Ein RECHTS-KLICK auf das gate fragt nach der zahl (genau wie ein
    /// rechts-klick auf eine uhr nach ihrer rate fragt, siehe
    /// Program.ask_const_value). Getippt werden duerfen ziffern, EIN
    /// trennzeichen und ein fuehrendes minus; '.' und ',' gelten dabei beide als
    /// dezimaltrenner (Global.input_accepts im zahlen-modus, set_value liest
    /// beide).
    ///
    /// Die zahl wird als ROH-WERT gespeichert, also als genau die bits, die auch
    /// auf den kabeln liegen (siehe Number32). "-1.5" ist damit das
    /// zweierkomplement von 1.5: wer mit TC liest, sieht -1.5, wer ohne TC
    /// liest, 65534.5. Was sich nicht in 32 bit darstellen laesst, laeuft um;
    /// unlesbarer text laesst den wert stehen (wie eine uhr ihre rate behaelt).
    /// </summary>
    [GateCategory("32bit")]
    internal class CONST32 : Number32
    {
        public override int num_inputs => 0;
        public override int num_outputs => 4;

        /// <summary>Der eingetippte wert als 16.16-roh-wert (genau das, was ausgegeben wird).</summary>
        public uint raw;

        public CONST32()
        {
            name = "val32";
            //schmal (2 zellen) und gerade so hoch, dass die vier kabel-pins
            //uebereinander passen
            fixed_size = (2, 3);

            for (int i = 0; i < 4; i++) outputs[i].bits = 8;
            name_bytes(outputs, 0, "R");
        }

        /// <summary>
        /// Den wert aus einer nutzereingabe uebernehmen (der gegenpart zu
        /// CLOCK.set_rate). Unlesbarer text oder nur "-" laesst den wert stehen.
        /// </summary>
        public void set_value(string text)
        {
            if (text == null) return;

            string cleaned = text.Trim().Replace(',', '.');   //',' und '.' sind beide der trenner
            if (double.TryParse(cleaned, NumberStyles.Float, CultureInfo.InvariantCulture, out double value))
                raw = raw_of(value);

            //die pins sofort setzen (wie Lever.toggle - zwischen den ticks ist
            //das erlaubt) und die fanout neu auswerten lassen
            apply();
            foreach (IGate f in get_fanout()) World.schedule(f);
            World.kick();
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            //keine eingaenge: einfach die gespeicherte zahl ausgeben. Die pins
            //werden NICHT hier gesetzt - das macht write() (wer hier schreibt,
            //macht aus einer aenderung ein "nichts geaendert" und erstickt damit
            //seine eigene fanout, siehe README und Counter32).
            return raw_bits(raw);
        }

        /// <summary>Die vier kabel sofort auf den gespeicherten wert legen - nach dem
        /// laden aus einem construct (vor dem ersten tick) und nach einer eingabe.</summary>
        void apply()
        {
            List<bool> bits = raw_bits(raw);
            int k = 0;
            foreach (Pin p in outputs)
                for (int b = 0; b < p.bits; b++, k++) p.set_bit(b, bits[k]);
        }

        public override string info_text() => $"const {format_value(value_of(raw, true))}";

        // ---- zustand speichern/laden (constructs) --------------------------------------

        public override Dictionary<string, string> save_state()
        {
            return new Dictionary<string, string> { { "raw", raw.ToString("x8") } };
        }

        public override void load_state(Dictionary<string, string> state)
        {
            if (state != null && state.TryGetValue("raw", out string v) &&
                uint.TryParse(v, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out uint parsed))
                raw = parsed;

            apply();   //die pins sind sofort wieder so wie beim speichern
        }

        public override void draw_costum()
        {
            //die eingetippte zahl unter dem namen zeigen: sonst sieht man nur
            //die bits auf den pins und weiss nicht, was das gate ausgibt
            (int w, int h) = get_cell_size();
            int px = cell_x * Global.cell_size;
            int py = cell_y * Global.cell_size;
            int pw = w * Global.cell_size - 16;

            int top = py + Global.font_size + 12;              //unter dem namen
            int bottom = py + h * Global.cell_size - 8;
            if (bottom - top < 8) return;

            string text = format_value(value_of(raw, true));
            Font f = Global.display_font;

            //die zahl soll in die box passen, auch wenn sie lang wird
            float size = Global.font_size * 0.75f;
            Vector2 m = Raylib.MeasureTextEx(f, text, size, Global.letter_spacing);
            if (m.X > pw && m.X > 0f)
            {
                size *= pw / m.X;
                m = Raylib.MeasureTextEx(f, text, size, Global.letter_spacing);
            }

            Raylib.DrawTextEx(f, text,
                new Vector2(px + 8 + (pw - m.X) / 2f, top + (bottom - top - m.Y) / 2f),
                size, Global.letter_spacing, Color.Red);
        }
    }
}
