using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// Ein 8-bit-kabel auf acht einzelne bits (2x3 zellen): der eingang ist EIN
    /// 8-bit-pin, die ausgaenge sind acht normale pins.
    ///
    /// Oben (index 0) liegt das MSB - genau wie die oberste reihe des
    /// 8-bit-pins und wie bei RNG8. Gerechnet wird nichts: bit n hinein ist pin
    /// n hinaus, das gate wechselt nur die form (acht bits in einer leitung
    /// werden acht leitungen mit je einem bit).
    /// </summary>
    [GateCategory("bits")]
    internal class SPLIT : GateBase
    {
        public override int num_inputs => 1;
        public override int num_outputs => 8;

        public SPLIT()
        {
            name = "split";
            //platz fuer den hohen 8-bit-pin und fuer acht einzelne pins
            fixed_size = (2, 3);

            inputs[0].name = "IN";     //acht bits: MSB (oben) bis LSB (unten)
            inputs[0].bits = 8;

            for (int i = 0; i < num_outputs; i++)
                outputs[i].name = i == 0 ? "MSB"
                                : i == num_outputs - 1 ? "LSB"
                                : "bit" + (num_outputs - 1 - i);
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            //acht bits hinein, acht bits hinaus - reihe fuer reihe unveraendert
            return new List<bool>(inputs);
        }
    }
}
