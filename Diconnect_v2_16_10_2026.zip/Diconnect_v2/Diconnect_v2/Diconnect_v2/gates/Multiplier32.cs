using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// 32-bit-multiplizierer (16.16 fixed point): obere zahl * untere zahl.
    ///
    /// Das produkt zweier 16.16-zahlen hat 32 bruchstellen, gebraucht werden 16:
    /// das ergebnis wird also gerundet und zurueckgeschrieben - aber nicht als
    /// bit-schieberei, sondern als zahl in C# (siehe Number32).
    ///
    /// Ganzzahlige fixpunkt-multiplikation laesst sich so nicht zusammensetzen
    /// (das skaliert wieder hoch), dafuer rechnet das gate wie ein normaler
    /// taschenrechner - 2.5 * 4 = 10, nicht 40.
    /// </summary>
    [GateCategory("32bit")]
    internal class MULTIPLIER32 : TwoNumber32
    {
        public override int num_outputs => 4;

        public MULTIPLIER32()
        {
            name = "mul32";
            //2x5: so schmal wie die anderen rechen-gates
            fixed_size = (2, 5);
            set_result_pins();
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            (double a, double b) = operands(inputs);
            return raw_bits(raw_of(a * b));
        }
    }
}
