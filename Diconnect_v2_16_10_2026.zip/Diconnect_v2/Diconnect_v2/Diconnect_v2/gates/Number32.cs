using System;
using System.Collections.Generic;
using System.Globalization;

namespace Diconnect_v2
{
    /// <summary>
    /// Gemeinsame basis der 32-bit-gates: eine zahl liegt als VIER 8-bit-kabel
    /// an (32 bit), gerechnet wird in normalen C#-zahlen.
    ///
    /// Format: 16.16 fixed point - die obersten 16 bit sind der ganze teil, die
    /// untersten 16 der bruchteil: wert = roh / 65536. Ein ganzes ist also
    /// 65536 roh-schritte, die kleinste stufe 1/65536. Genau deshalb ist
    /// COUNTER32 "nur ein 16-bit-zaehler": er zaehlt den ganzen teil.
    ///
    /// Vorzeichen: der roh-wert ist 32 bit. Das eigene TC-eingang
    /// (zweierkomplement) entscheidet, wie sie gelesen werden - aus =
    /// vorzeichenlos (0 .. 65535.99998), an = zweierkomplement
    /// (-32768 .. 32767.99998).
    ///
    /// Alles laeuft ueber die roh-werte, damit es genau EINE umrechnung gibt:
    /// read_raw/value_of hinein, raw_of/raw_bits hinaus. Was nicht in 32 bit
    /// passt, laeuft um (wie bei jedem C#-int).
    /// </summary>
    internal abstract class Number32 : GateBase
    {
        /// <summary>So viele bits des roh-werts gehoeren zum bruchteil (16.16).</summary>
        public const int fraction_bits = 16;

        /// <summary>Ein ganzes in roh-schritten (2^16 = 65536).</summary>
        public const double scale = 65536.0;

        /// <summary>Der umlauf des roh-werts (2^32).</summary>
        const double raw_range = 4294967296.0;

        // ---- roh <-> zahl ---------------------------------------------------------------

        /// <summary>32 bits ab offset als roh-wert (offset zeigt auf das MSB).</summary>
        public static uint read_raw(List<bool> bits, int offset)
        {
            uint raw = 0;
            for (int i = 0; i < 32; i++)
            {
                raw <<= 1;
                if (bits[offset + i]) raw |= 1;
            }
            return raw;
        }

        /// <summary>Roh-wert als zahl: TC an = zweierkomplement, aus = vorzeichenlos.</summary>
        public static double value_of(uint raw, bool twos_complement)
            => (twos_complement ? (int)raw : (long)raw) / scale;

        /// <summary>
        /// Zahl als roh-wert. Was keine 32-bit-darstellung hat, wird 0: NaN und
        /// unendlich (teilung durch 0, wurzel aus einer negativen zahl). Was zu
        /// gross ist, laeuft um - wie bei jedem C#-int, denn mehr als 32 bit hat
        /// das gate nicht.
        /// </summary>
        public static uint raw_of(double value)
        {
            if (double.IsNaN(value) || double.IsInfinity(value)) return 0;

            //erst in GANZEN einheiten umlaufen (2^32 roh = 65536 ganze), dann
            //skalieren: sonst koennte eine riesige zahl (2 hoch 1015) schon beim
            //multiplizieren unendlich werden, statt einfach umzulaufen
            double units = value % scale;
            double scaled = Math.Round(units * scale, MidpointRounding.AwayFromZero);

            double wrapped = scaled % raw_range;
            if (wrapped < 0) wrapped += raw_range;
            if (wrapped < 0 || wrapped >= raw_range) return 0;   //nur zur sicherheit
            return (uint)wrapped;
        }

        /// <summary>Ein roh-wert als seine 32 bits, MSB zuerst (vier 8-bit-kabel).</summary>
        public static List<bool> raw_bits(uint raw)
        {
            var bits = new List<bool>();
            for (int i = 31; i >= 0; i--) bits.Add(((raw >> i) & 1) != 0);
            return bits;
        }

        /// <summary>
        /// Vier aufeinanderfolgende pins als die vier bytes EINER zahl benennen:
        /// der erste (oberste) ist das hoechste byte (praefix 3), der letzte das
        /// niedrigste (praefix 0) - genau die pin-reihe von oben nach unten.
        /// </summary>
        public static void name_bytes(Pin[] pins, int offset, string prefix)
        {
            for (int i = 0; i < 4; i++) pins[offset + i].name = prefix + (3 - i);
        }

        /// <summary>Eine zahl so schreiben, wie die anzeige sie zeigt: bis zu
        /// fuenf nachkommastellen, ohne ueberfluessige nullen.</summary>
        public static string format_value(double value)
            => value.ToString("0.#####", CultureInfo.InvariantCulture);

        /// <summary>Eine zahl mit ALLEN stellen schreiben - fuer das eingabefeld
        /// einer konstante: der roh-wert hat hoechstens 16 bruchstellen, laesst
        /// sich also genau hinschreiben (format_value rundet fuer die anzeige auf
        /// fuenf stellen, was beim erneuten eingeben minimal verlieren koennte).</summary>
        public static string format_exact(double value)
            => value.ToString("0.#################", CultureInfo.InvariantCulture);
    }

    /// <summary>
    /// Basis der gates mit ZWEI zahlen: acht 8-bit-kabel - die OBERE zahl auf
    /// pin 0-3, die UNTERE auf pin 4-7 - und ganz unten das 1-bit-eingang TC,
    /// das das zweierkomplement ein- und ausschaltet.
    ///
    /// Pin-reihe von oben: A3 A2 A1 A0 B3 B2 B1 B0 TC. A3 ist das hoechste
    /// byte der oberen zahl, A0 das niedrigste.
    /// </summary>
    internal abstract class TwoNumber32 : Number32
    {
        public override int num_inputs => 9;

        /// <summary>Index des TC-bits im flachen bit-vektor: acht kabel sind 64 bits.</summary>
        protected const int toggle_bit = 64;

        protected TwoNumber32()
        {
            for (int i = 0; i < 8; i++) inputs[i].bits = 8;
            name_bytes(inputs, 0, "A");
            name_bytes(inputs, 4, "B");
            inputs[8].name = "TC";
        }

        /// <summary>Die beiden zahlen so, wie das gate sie liest.</summary>
        protected static (double a, double b) operands(List<bool> bits)
        {
            bool twos_complement = bits[toggle_bit];
            return (value_of(read_raw(bits, 0), twos_complement),
                    value_of(read_raw(bits, 32), twos_complement));
        }

        /// <summary>Die vier 8-bit-ergebnis-kabel einrichten (R3..R0).</summary>
        protected void set_result_pins()
        {
            for (int i = 0; i < 4; i++) outputs[i].bits = 8;
            name_bytes(outputs, 0, "R");
        }
    }
}
