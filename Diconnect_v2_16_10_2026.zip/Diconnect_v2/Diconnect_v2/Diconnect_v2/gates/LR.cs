using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// Die laufrichtung einer leitung drehen (1x1 zellen, kategorie "basic"):
    /// ein eingang und ein ausgang, beide auf der LINKEN kante der box - der
    /// eingang oben, der ausgang darunter. Das spiegelbild von RL.
    ///
    /// Eine leitung, die von links kommt, endet hier am oberen pin; die naechste
    /// leitung faengt am unteren pin an derselben kante an und laeuft von dort
    /// weiter. So kann ein strang an dieser kante wenden.
    ///
    /// Gerechnet wird nichts: der wert geht unveraendert durch (wie IDENTITY, nur
    /// mit beiden pins an einer kante). Wie jedes gate kostet auch dieses eine
    /// taktstufe - eine leitung selbst ist dagegen sofort.
    /// </summary>
    [GateCategory("basic")]
    internal class LR : GateBase
    {
        public override int num_inputs => 1;
        public override int num_outputs => 1;

        //beide pins an der linken kante (der eingang liegt oben)
        public override PinSide input_side => PinSide.left;
        public override PinSide output_side => PinSide.left;

        public LR()
        {
            name = "LR";
            fixed_size = (1, 1);
            inputs[0].name = "IN";
            outputs[0].name = "OUT";
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            return new List<bool> { inputs[0] };
        }
    }
}
