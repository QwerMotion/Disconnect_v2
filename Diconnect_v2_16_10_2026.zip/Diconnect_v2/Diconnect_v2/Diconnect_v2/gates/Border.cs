using Raylib_cs;
using System;
using System.Collections.Generic;
using System.Numerics;

namespace Diconnect_v2
{
    /// <summary>
    /// Ein rahmen auf der organize-ebene, nur zum anzeigen: er zeichnet NUR
    /// seinen umriss, nichts wird gefuellt (auch nicht halbdurchsichtig) - die
    /// flaeche bleibt frei, damit die schaltung darunter unveraendert zu sehen
    /// ist.
    ///
    /// Er wird wie im speicher-modus mit zwei klicks aufgezogen (erste ecke,
    /// zweite ecke) und hat keine weitere funktion - er liegt ueber der
    /// schaltung, ohne etwas zu blockieren.
    /// </summary>
    [GateCategory("organize")]
    internal class BORDER : OrganizeItem
    {
        public override string type_id() => "BORDER";

        public BORDER()
        {
            name = "border";
            fixed_size = (1, 1);   //vorschau: 1x1, die groesse kommt erst aus den zwei klicks
        }

        public override void set_size(int width_cells, int height_cells)
        {
            fixed_size = (Math.Max(1, width_cells), Math.Max(1, height_cells));
        }

        public override void draw()
        {
            (int w, int h) = get_cell_size();
            int px = cell_x * Global.cell_size;
            int py = cell_y * Global.cell_size;
            int pw = w * Global.cell_size;
            int ph = h * Global.cell_size;

            //nur der umriss: die flaeche wird NICHT gefuellt, auch nicht
            //halbdurchsichtig - man soll die schaltung darunter unveraendert
            //sehen (ein rahmen ist eine markierung, keine flaeche)
            Raylib.DrawRectangleLinesEx(new Rectangle(px, py, pw, ph), 3f, Global.border_color);
        }
    }
}
