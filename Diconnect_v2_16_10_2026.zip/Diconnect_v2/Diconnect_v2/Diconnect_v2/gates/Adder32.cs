using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>
    /// 32-bit-addierer (16.16 fixed point): obere zahl + untere zahl.
    ///
    /// Gerechnet wird in normalen C#-zahlen (siehe Number32): die bits werden
    /// gelesen, die zahlen addiert und das ergebnis wieder als 32 bit
    /// geschrieben. Was nicht in 32 bit passt, laeuft um.
    /// </summary>
    [GateCategory("32bit")]
    internal class ADDER32 : TwoNumber32
    {
        public override int num_outputs => 4;

        public ADDER32()
        {
            name = "add32";
            //2x5: schmal (die kabel brauchen HOEHE, nicht breite) und hoch genug
            //fuer die neun pins - so wie alle rechen-gates
            fixed_size = (2, 5);
            set_result_pins();
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            (double a, double b) = operands(inputs);
            return raw_bits(raw_of(a + b));
        }
    }
}
