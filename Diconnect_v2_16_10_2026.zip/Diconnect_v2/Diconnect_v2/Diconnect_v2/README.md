# Diconnect_v2

A gate-level circuit sandbox: place gates on a grid, wire their pins together by hand and
watch the signals propagate. Gates are C# classes, saved sub-circuits ("constructs") are
JSON files.

C# / .NET 8 with [Raylib-cs](https://github.com/ChrisDill/Raylib-cs).

```
dotnet run
```

Run it from the project folder: `fonts/` and `constructs/` are read relative to the working
directory.

## Controls

| Input | What it does |
| --- | --- |
| `W` / `S`, mouse wheel | Move through the inventory list - or, while cabling, through the wire colours |
| `A` / `D` | Previous / next inventory page |
| Right-click | Place or use the selected entry: places a gate or construct, toggles a lever, asks a clock for its rate or a 32-bit constant for its number, edits a label, or draws a border (two clicks) |
| Left-click | Mark a gate, label or border: drag moves it, `T` deletes it. In saving mode a drag that *starts inside* the marked area moves everything inside it - gates with their wires, labels and borders (see "Saving mode") |
| `C` | Cable tool on/off. With it, right-click a pin to start a wire and right-click a second pin to finish (the same two pins again = disconnect). In this mode the inventory is replaced by the colour list |
| `Esc` | Abandon what is going on: the cable tool (an unfinished wire *and* the colour list), a drag, the saving mode, the spectate mode |
| `I` / `O`, arrow keys | Zoom in / out, pan - holding `Shift` pans `Global.cam_speed_fast` times faster (default 4x). `I`/`O` with `Shift` held zoom *smoothly* instead: no step at all, just `Global.zoom_smooth_steps_per_second` steps per second for as long as the key is down, so the picture starts gliding on the first frame instead of jumping |
| `Tab` | Show the pin names (nothing in spectate mode) |
| `Ctrl+S` | Saving mode (tools: `delete`, `mark all`, `marker`, `save`), `Esc` leaves it |
| `Ctrl+F` | Inventory search: type to filter every gate and construct (no six-per-page limit), `↑`/`↓` or the wheel scroll the list, `Enter` or a click on a row takes that entry into the inventory, `Esc` (or a click beside the list) leaves |
| `F1` | Spectate mode on/off: no UI at all, see "Spectate mode" |
| `Enter` / `Esc` while typing | Confirm / cancel the prompt |

## Layout

```
Program.cs        main loop, modes, input, drawing of the frame
Global.cs         globals: sizes, colors, fonts, camera, text input, shared geometry
World.cs          the grid, gate/wire registry and the tick engine
GateBase.cs       what every gate derives from
GateRegistry.cs   finds all gates and builds the inventory pages
Inventory.cs      the inventory list (gates + constructs)
Menu.cs           the generic text menu (inventory and saving tools both use it)
SaveTools.cs      the saving mode: its four tools
Search.cs         the inventory search (Ctrl+F): filter, scroll, take an entry
Selection.cs      the marked area: rules, preview, moving it, save, delete
ColorMenu.cs      the wire colours list shown while cabling
Construct.cs      construct model, JSON store, placing a construct
Organize.cs       the organize plane: OrganizeItem (base of labels/borders) and Organize
gates/            one file per gate (plus the shared bases FlipFlop and Number32)
constructs/       saved constructs (<name>.json)
fonts/            the UI font
```

`gates/` is the only folder you need to touch to add a gate.

## How the simulation works

Wires are instant: an input pin reads the state of the output pin driving it (several wires
on one input behave like an OR). A gate only delays by one tick - each tick every scheduled
gate computes its new outputs (`read()`), applies them (`write()`) and, if anything changed,
schedules its fan-out for the next tick. A circuit of depth N therefore needs N ticks.
`Global.ticks_per_frame` decides how many ticks a frame runs; clocks (`frame_update`) run in
real time instead.

## Searching the inventory (Ctrl+F)

`Ctrl+F` opens a search over the whole inventory - every gate and every construct, not one
page of six. With an empty query the complete list is shown, so it also doubles as a way to
browse everything at once. Typing filters the names (case-insensitive, the text may sit
anywhere in the name) and the list follows every keystroke.

`↑`/`↓` and the mouse wheel scroll through the matches; the view scrolls with the selection,
so the highlighted row is always on screen, and a footer says how many entries there are and
which part is on screen. Note that `W`/`S` deliberately do *not* page here (unlike the
inventory): in a search you type names, and `s` turns up in plenty of them (`split`).

`Enter` takes the entry the list has highlighted, a **left click on a row** takes exactly that
row - and either way the *inventory* selection is set to it, page and row following from the
entry (`Inventory.select_index`), so you land on the right page when you go back to building.
`Esc`, or a click beside the list, closes the search without touching the inventory selection.
All of these endings return to building, and opening the search drops whatever was running (a
half-finished wire, a drag, the cable tool, the saving mode).

## Spectate mode (F1)

`F1` hides the whole UI: no inventory, no colour list, no tool menu, no previews and no
highlights - just the circuit. Labels and borders stay, because they are part of the drawing
(they are saved with a construct, not drawn by the app). The simulation keeps running, so
clocks tick and signals move.

What still works is everything that needs no building: a **lever** toggles and a **clock**
asks for its rate - with either mouse button, since there is nothing else left to click - and
the camera still pans and zooms (arrow keys, `Shift` for speed, `Shift` for the smooth `I`/`O`
zoom). `Esc` - or `F1`
again - goes back to building; whatever was going on (an unfinished wire, a marked area, the
saving mode) is dropped while entering.

## Saving mode (Ctrl+S)

`Ctrl+S` replaces the inventory with the tool list (`mark all`, `marker`, `save`, `delete` -
see `SaveTools`) and `Esc` leaves it; a click in the world applies the selected tool.

As soon as an area is marked (shown in orange), **dragging inside it moves everything in it**:
the gates lying completely inside (their wires hang on their pins and come along), plus their
labels and borders. While the mouse is down the target area is drawn too - orange when it
fits, red when something that stays behind is in the way - and the marked area travels with
its contents, so a second drag picks up where the first ended. Pressing inside the area and
releasing without moving is still an ordinary tool click, so `marker`, `delete` and `save`
behave exactly as before.

## Wire colours

`Global.wire_colors` is the palette and `Global.wire_color_names` its names - the two lists
are index-parallel, `wire_colors[n]` belongs to `wire_color_names[n]` (red, green, yellow,
blue, magenta, white). `Global.active_wire_color` is the selected index; a new `Wire`
remembers it in `Wire.color_index`, so **each wire keeps the colour it was drawn with**
(changing the selection later recolours nothing, and constructs save the index).

While the cable tool is on, `ColorMenu` replaces the inventory: `W`/`S` and the wheel pick a
colour. Every name is shown in *its* colour but greyed out (`Global.wire_color_passive`);
only the selected one is drawn in its full colour (`Global.wire_color_of`) - the inventory
highlights with orange instead. The same colour is used for the wire being dragged, including
its preview, so the preview always shows what the next right-click will produce.

How strongly "greyed out" is greyed out is one number: `Global.wire_grey_amount`
(0 = the full colour, 1 = nothing but grey; default 0.7, i.e. 30% colour + 70% dark grey).
It applies to the passive form of every colour, so the colour list and the wires always
agree.

A wire also *shows* its level: **high = its own colour, low = the greyed-out form of it**.
(`Wire.color_index` still stores which colour it was drawn with; only the way it is painted
depends on the drive.) Each of the eight lines of an 8-bit cable follows its own bit, and the
pins keep saying red = high, white = low as before.

## 8-bit pins and cables

A `Pin` carries `bits` bits - 1 by default, or 8. An 8-bit pin is still *one* pin slot: it is
`Global.pin8_size` pixels tall (default 32, so a row is 4px - a byte should not eat the map)
and shows its eight bits as stacked rows, row 0 (top) being the MSB - the same order the pin
names `MSB`...`LSB` use. Drawing and hit-testing share `Global.pin_rect`, which distributes
the pins of a side using `Pin.height` and falls back to the old arithmetic when every pin is
1 bit.

An 8-bit **cable** is eight copies of the same curve, stacked - one per bit. How far apart
those eight lines lie is its own setting, `Global.wire8_spacing` (default 4px): a cable is not
a pin drawing and stays compact even when the pin is tall. The stack sits centred on the pin,
row 0 (MSB) on top; if `wire8_spacing` happens to equal a pin row (`pin8_size / 8`), the lines
land on the rows exactly. Cable and preview share the offset maths (`Global.line_offset`), so
the preview is drawn where the wire will hang.

An 8-bit cable only connects to an 8-bit pin: `Wire.connect_undirected` refuses a pair with
different widths, and `Wire.find_between` never reports one, so a normal wire cannot be
attached to an 8-bit pin. In the tick engine nothing is special about a bundle:
`GateBase.read`/`write` flatten the pins into bits (`MSB` first) and `evaluate` simply sees
eight values for an 8-bit pin.

Two gates adapt between the two worlds, both 2x3 cells and both in the `bits` category:
`SPLIT` (one 8-bit input -> eight 1-bit outputs) and `MERGE` (eight 1-bit inputs -> one 8-bit
output). Since the bit order is the same on both sides, both are pure rewiring.

## Single-sided pins (RL / LR)

`RL` and `LR` are two 1x1 identities (one input, one output, nothing computed - like `IDENTITY`)
that put **both pins on the same edge**: `RL` on the right, `LR` on the left, the input always
the upper one. A wire arriving from that side ends on the upper pin, and the next wire leaves
the lower pin of the same edge, so a run can turn around at an edge instead of being dragged
back across the circuit.

Both sit in the `basic` category, and like every gate they cost one tick - only a wire itself
is instant (see "How the simulation works").

The wire curve follows the pin, not the gate: a wire leaves or reaches every pin on the side
that pin sits on (`Pin.side`, i.e. `input_side`/`output_side`), so it meets the box
perpendicular. A wire into `RL` therefore arrives from the *right*, and one out of `LR` leaves
to the *left* - the curve used to assume every output is on the right and every input on the
left, which sent it around the box on these two gates.

For a gate author: which edge a pin sits on comes from `input_side` and `output_side` on
`GateBase` (default left / right). Naming the **same** side for both puts the two stacks on one
edge - inputs first, then outputs (`GateBase.pins_on`, `pins_share_side`). `Pin.rect` feeds
that into `Global.pin_rect`, which is the one rectangle both drawing and hit-testing use, so a
gate with custom sides needs no drawing code at all.

## The full adder

`FULLADDER` (2x2 cells, `basic`, box label "FA") is one 1-bit full adder: `a` (top), `b`
(middle) and `carry` (bottom) in, `sum` (top) and `carry_out` (bottom) out.

```
sum       = a XOR b XOR carry
carry_out = (a AND b) OR (carry AND (a XOR b))
```

The pin order keeps the carry at the bottom edge of the box, so chaining stages (a
ripple-carry adder) never puts it in the middle of a pin stack - and the pins are literally
named `carry` and `carry_out`, so a swapped pair is visible with the `Tab` overlay.

## 32-bit fixed point numbers

Eight gates work on 32-bit numbers instead of single bits or bytes: `ADDER32`, `MULTIPLIER32`,
`DIVIDER32`, `POWERER32` and `COMPARER32` (all on the `32bit` inventory page, which sits at the
end of the inventory list), plus `COUNTER32` and `CONST32` (on `32bit` too) and `DISPLAY32`
(with the other displays). A C# class name cannot start with a digit, so the classes end in `32`
(`adder32` in the inventory and in the save files) while the box itself carries a short label
instead of the whole name: `add32`, `mul32`, `div32`, `pow32`, `cmp32`, `cnt32` and `val32` (the
display draws no name at all, like the other displays). Every one of them is **two cells wide** -
what the six cable rows and the eight-pin stack need is *height*, not width - and only the
display is wider (five cells), because it has to hold a number.

The format is **16.16 fixed point**: the top 16 of the 32 bits are the whole part, the bottom 16
the fraction, so `value = raw / 65536` - one whole is 65536 raw steps and the smallest step is
`1/65536 = 0.0000152...`. A pin carries at most eight bits, so **one number is four byte cables**.

How those bits are read is switched by a single input, `TC`: **off** they are unsigned
(`0 .. 65535.99998`), **on** they are two's complement (`-32768 .. 32767.99998`). It is always the
*lowest* pin of the gate, so it sits at the bottom of the pin stack - the same place the trigger
of the small `DISPLAY` sits.

The five two-number gates share one layout, the upper number first:

```
   A3   upper number, highest byte first
   A2
   A1
   A0
   B3   lower number, highest byte first
   B2
   B1
   B0
   TC   1 bit: two's complement on/off
```

`ADDER32`, `MULTIPLIER32`, `DIVIDER32` and `POWERER32` answer with the same four byte cables
(`R3 R2 R1 R0`, highest byte first). `COMPARER32` answers with **one bit**: is the upper number
greater than the lower one (`A > B`, 1 = yes). `DIVIDER32` divides the upper number by the lower
one; `POWERER32` raises the upper number (the base) to the lower one (the exponent), and a
fractional exponent is allowed - `0.5` takes the 2nd root, `0.25` the 4th root, `1.5` the square
root times the number itself.

**What they compute.** Every gate reads its inputs, converts them to ordinary C# numbers and
converts the result back - one shared conversion in `Number32`, not bit tricks:

* `+`, `*`, `/` and `Math.Pow` on the values, so `2.5 * 4` is `10`, not `40`.
* **A result that does not fit 32 bits wraps**, exactly like a C# `int`: `32767.5 + 1` becomes
  `-32767.5` with two's complement, `65535.5 + 1` becomes `0.5` without it.
* **NaN and infinity become 0**, because 32 bits cannot hold them: `x / 0` is 0, and so is the
  root of a negative number (`-4 ^ 0.5`). Raising to 0 is 1 (`Math.Pow(0, 0)`) and stays a
  number.

`COUNTER32` counts the whole part - which is why it is only a 16-bit counter, the fraction can
never be anything but 0. `CLK` (top) counts on a **rising edge only**: a falling edge, a clock
held high and a clock that is already high when the gate is placed are all not a pulse, exactly
like `RNG8`. `RESET` (bottom) holds it at 0 while it is high, clock edges included, and letting
`RESET` go is not a pulse either. Its output is the whole part as **two byte cables**: `HI`
(bits 15..8) on top, `LO` (bits 7..0) below - wired into a 32-bit gate's two highest bytes, the
number is the same again (as long as it is positive).

`DISPLAY32` shows the value like the other displays (no outputs): four byte cables in
(`B3 B2 B1 B0`, highest byte first - `B3`/`B2` are the whole part, `B1`/`B0` the fraction) plus
the `TC` trigger at the bottom. It prints up to five decimals without trailing zeros (`3.75`,
`-0.5`, `12`, `0.00002`) and shrinks the font when a number gets long, so `65535.99998` still
fits into its box.

`CONST32` (`val32`) is the number you type in: no inputs, four byte cables out, and a
**right-click asks for the number** - the same prompt a clock gets for its rate, and a freshly
placed one asks straight away. Only digits, one decimal separator and a leading minus can be
typed, and `.` and `,` are both read as the decimal point. The value is stored as the 16.16 raw
bits, so `-1.5` is the two's complement of 1.5: read with `TC` it is -1.5, read without it is
65534.5. The box shows the number under its name (the pins only show the bits), and a construct
saves it like any other gate state. It is the one 32-bit gate with no `TC` input: which reading
is meant is decided by the gate the cable goes to.

Wiring is as strict as everywhere: a byte cable only joins a byte pin, so a 1-bit signal needs a
`MERGE` in front of it and a `SPLIT` behind it - the one exception is the `TC` input, which is an
ordinary 1-bit pin and takes an ordinary wire.

## Adding a new gate

**1. One file in `gates/`, one class.** The class name is the gate's identity everywhere -
in the inventory, in the JSON and in the registry - so name it what you want to see.

**2. Derive from `GateBase`** and give it its pin counts and its logic:

```csharp
using System.Collections.Generic;

namespace Diconnect_v2
{
    internal class XOR : GateBase
    {
        public override int num_inputs => 2;
        public override int num_outputs => 1;

        public XOR()
        {
            name = "XOR";             // what the box shows (default "gate")
            fixed_size = (2, 2);      // cells; omit and the size is measured from the name and pins
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            return new List<bool> { inputs[0] ^ inputs[1] };
        }
    }
}
```

That is the whole minimum: file in, gate available. `GateRegistry.init()` finds every
non-abstract `GateBase` subclass by reflection, so the inventory, the placement ghost,
saving and loading all pick it up with no registry edit - the inventory shows the class name
lowercased, sorted by class name, in the category from step 3. A category with more than six
entries spills onto a second page automatically.

**The one thing `evaluate` must not do: write the pins.** It returns the outputs the gate
*wants*; `read()` compares that with the pins to notice a change, and only `write()` applies it -
which is also what tells the fan-out to re-evaluate. A gate that sets its own output pins *inside*
`evaluate` always looks unchanged to that comparison, so its state moves while nothing wired
behind it ever hears about it: a counter written that way counts happily, yet the display, the
lamp and the next gate all stay frozen until some unrelated edit (deleting an upstream gate,
loading a construct) forces a re-evaluation. Writing pins after the fact belongs in `load_state`
(see the `apply()` in `RNG`, `RNG8` and `COUNTER32`), and the two gates that must set a pin from
user input (`Lever`, `Clock`) do it in `toggle()`, outside `evaluate`.

**3. Optional finishing touches.**

* `[GateCategory("basic")]` above the class puts the gate on that inventory page. Without
  it the gate lands in `basic`. Gates are grouped by this string, so a new value creates a
  new page - placed alphabetically among the others, and a category that spills over six
  entries continues on the next page. The order of the pages is `GateRegistry.compare_categories`:
  alphabetical, except the categories listed in `GateRegistry.trailing_pages` (`32bit` today),
  which go last - so the biggest blocks come after the small building blocks instead of before
  them (alphabetically `"32bit"` would be the very first page).
* Pin names for the `Tab` overlay: `inputs[0].name = "J";`, `outputs[0].name = "Q";`
  (default `IN0`, `OUT0`, ...).
* An 8-bit pin: `inputs[0].bits = 8;` in the constructor turns that slot into a single pin
  carrying eight bits - see the section on byte-wide gates below and `SPLIT`/`MERGE`.
  `evaluate` still takes and returns a flat list of bits (MSB first).
* `input_side` / `output_side` (`PinSide.left` / `PinSide.right`) move the pins to another
  edge; naming the same side for both stacks input and output there - see the `RL`/`LR` section.
* `draw_costum()` draws extra visuals inside the box (see `Lever`, `LAMP`, `Display`) - it
  runs after the common box, name and pins are drawn.
* `frame_update(float dt)` runs once per frame for things that must not depend on ticks
  (see `Clock`).
* `info_text()` is the one-line description used for inspection.

**4. Box size.** With `fixed_size` set, the gate is exactly that many cells. Without it the
width comes from the drawn name and the height from the pin count; check that a name like
`XOR` actually fits in a 1x1 box (`Raylib.MeasureTextEx`) before choosing a size.

### Writing a byte-wide gate (8-bit pins)

Byte-wide pins are what makes bigger blocks cheap: one pin carries eight bits, so an adder
needs two input pins and two output pins instead of sixteen wires to click. It is one
constructor line per pin:

```csharp
inputs[0].bits = 8;   // this slot is now a byte, bit 0 (MSB) in the top row
```

`evaluate` keeps its shape - a flat `List<bool>` in, a flat `List<bool>` out:

* **In:** every pin contributes its bits in pin order, and inside one bundle bit 0 (MSB)
down to bit 7 (LSB). So with `inputs[0].bits = 8`, the value `inputs[0]`...`inputs[7]` is the
first byte and `inputs[8]` is the first bit of the next pin.
* **Out:** the returned list is written back the same way: the first eight entries fill an
8-bit `outputs[0]`, the ninth is the first bit of `outputs[1]`. **Return exactly as many bits
as your output side has** - too few and those bits keep their previous value, too many are
dropped.
* **Pins can mix widths**: bytes in, a byte out and a single-bit carry, all in one gate.
* **The tick engine does not care.** Change detection compares every bit of a pin, so flipping
bit 5 of an 8-bit output schedules the fan-out exactly like bit 0 does.

A complete byte adder - one gate file, nothing else:

```csharp
using System.Collections.Generic;

namespace Diconnect_v2
{
    /// <summary>Two bytes in, the sum byte and the carry out.</summary>
    [GateCategory("bits")]
    internal class ADD8 : GateBase
    {
        public override int num_inputs => 2;    // A, B (8 bits each)
        public override int num_outputs => 2;   // SUM (8 bits), COUT (1 bit)

        public ADD8()
        {
            name = "add8";
            fixed_size = (2, 3);   // an 8-bit pin is pin8_size (default 32) high

            inputs[0].bits = 8;    // A
            inputs[1].bits = 8;    // B
            outputs[0].bits = 8;   // SUM

            inputs[0].name = "A";
            inputs[1].name = "B";
            outputs[0].name = "SUM";
            outputs[1].name = "COUT";
        }

        protected override List<bool> evaluate(List<bool> inputs)
        {
            int sum = to_byte(inputs, 0) + to_byte(inputs, 8);

            List<bool> result = from_byte(sum & 0xFF);
            result.Add(sum > 0xFF);   // COUT is an ordinary one-bit pin
            return result;
        }

        /// <summary>Eight bits from offset as a number (bit 0 = MSB).</summary>
        static int to_byte(List<bool> bits, int offset)
        {
            int value = 0;
            for (int i = 0; i < 8; i++)
                if (bits[offset + i]) value |= 1 << (7 - i);
            return value;
        }

        /// <summary>A number as eight bits, MSB first.</summary>
        static List<bool> from_byte(int value)
        {
            var bits = new List<bool>();
            for (int i = 7; i >= 0; i--) bits.Add(((value >> i) & 1) != 0);
            return bits;
        }
    }
}
```

Two things to keep in mind when you wire such a block:

* **8-bit only connects to 8-bit** (a normal wire cannot be attached to an 8-bit pin, on
  purpose), so put `SPLIT`/`MERGE` at the edges when the rest of the circuit is one bit wide -
  and stay wide inside the block, which is the point of it.
* **Name the pins MSB ... LSB** (`SPLIT`, `MERGE` and `RNG8` all use "MSB", "bit6" ... "LSB"),
  because the row you see on top is bit 0.

A pin carries at most **8** bits today (`Global.pin8_rows`, backed by `Pin.bit_state`). A
32-bit ALU is therefore four byte busses (or SPLIT/MERGE at the seams between blocks) - which is
exactly what the 32-bit gates below are built on; if you ever want one wider bundle, raise those
two together - the flattening, the change detection and the wiring are all width-agnostic,
`bits` is just a number.

## Integrating a gate into the save system

A construct file (`constructs/<name>.json`) stores gates with their type, their position
relative to the marked area, and their own state:

```json
{
  "version": 1,
  "name": "adder",
  "width": 5,
  "height": 5,
  "gates": [
    { "type": "LEVER", "x": 0, "y": 0, "state": { "on": "1" } },
    { "type": "XOR",   "x": 3, "y": 1, "state": {} }
  ],
  "wires": [ { "from_gate": 0, "from_pin": 0, "to_gate": 1, "to_pin": 0, "color": 0 } ],
  "organize": [
    { "type": "LABEL", "x": 0, "y": 2, "width": 1, "height": 1, "state": { "text": "clock" } }
  ]
}
```

What that means for a new gate:

* **Nothing, if the gate has no state.** It is saved as its type plus its position, and
  `evaluate` rebuilds everything after loading.
* **A parameterless constructor.** Loading uses `GateRegistry.create`, which calls
  `Activator.CreateInstance`.
* **`type_id()` is already handled.** It defaults to the class name, so do not override it.
  If an override points at a different type (the classic copy-paste slip when a new gate file
  starts as a copy of `AND`), `ConstructStore` saves the gate under its class name anyway and
  prints a warning on the console - a construct can never silently contain the wrong gate.
* **Stateful gates override two methods.** The keys are yours; the values are strings:

  ```csharp
  public override Dictionary<string, string> save_state()
      => new Dictionary<string, string> { { "q", q ? "1" : "0" } };

  public override void load_state(Dictionary<string, string> state)
  {
      if (state != null && state.TryGetValue("q", out string v)) q = v != "0";
  }
  ```

  `FlipFlop` (the stored value and the last clock level), `Lever` (`on`), `Clock` (`hz`) and
  `RNG`/`RNG8` (the rolled value and the last clock level) are the examples to copy.
  Restoring the last clock level matters: `load_state` runs before the first tick, so a
  flip-flop does not see a spurious edge and change its value on load.
  Setting the pin state as well (`outputs[0].state = ...`) makes the loaded circuit correct
  immediately instead of one tick later.
* **A clocked gate that produces a value** should roll only on a real clock pulse - a
  low-to-high change it observed itself. The `RNG` gates are the example: they hold their
  value at rest (nothing is generated while the gate is built or placed), a clock that is
  already high when the gate appears is not a pulse, and a clock held high never re-rolls.
  One pulse, one value.
* **Wires** are stored as indices into the two gates' pin arrays, so the pin order of your
  gate is part of the format: changing the order of `inputs[]` breaks already saved
  constructs that use it. Add new pins at the end. The pin **index** is the slot, not the
  bit: an 8-bit pin is one index, and changing a pin's `bits` between saves makes the wires
  on it come back as they are (the width only has to match again at both ends).
  `color` is the wire's index into `Global.wire_colors`; a file without the field loads as
  red (index 0).
* **What gets saved** is everything lying completely inside the marked area; a wire whose
  other end is outside is dropped, because that end cannot be rebuilt.

Labels and borders are not gates on the grid: they live on the organize plane (`Organize`,
docs in `Organize.cs`) and are written into the same file under `organize`. A new organize
item derives from `OrganizeItem`, gets `[GateCategory("organize")]`, overrides `type_id()`
(again: the class name is fine) and, if it needs one, `save_state`/`load_state`.

### Checklist

- [ ] `gates/YourGate.cs`, class derives from `GateBase`, parameterless constructor
- [ ] `num_inputs`, `num_outputs` and `evaluate` correct (try every input combination)
- [ ] box size chosen so the name fits; `fixed_size` when needed
- [ ] `[GateCategory(...)]` if it should not go to `basic`
- [ ] pin names set for the `Tab` overlay
- [ ] pins on a custom edge? `input_side` / `output_side` (`RL`/`LR`), hit-testing comes free
- [ ] `bits = 8` on the pins that carry a byte (`SPLIT`/`MERGE`/`ADD8`); `evaluate` still sees plain bits, MSB first
- [ ] with 8-bit pins: returned bit count equals the bits of the output side, and the pins are
      named MSB ... LSB
- [ ] `save_state`/`load_state` if the gate remembers anything
- [ ] new pins appended, never inserted in the middle
- [ ] place it, save a construct containing it, load it - the type must come back as your class
