using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Diconnect_v2
{
    /// <summary>A page in the inventory, e.g. "basic", "latches", "user".</summary>
    internal class GatePage
    {
        public string name;
        public List<Type> gate_types = new();

        public GatePage(string n) { name = n; }
    }

    internal static class GateRegistry
    {
        public static readonly List<GatePage> pages = new();
        static readonly Dictionary<string, Type> by_type_id = new();

        /// <summary>
        /// Kategorien, die NICHT alphabetisch einsortiert werden, sondern ans
        /// ENDE der seiten-reihenfolge gehoeren - in genau dieser reihenfolge.
        ///
        /// "32bit" steht hier, weil seine gates die groessten brocken sind: sie
        /// sollen hinter den kleinen bausteinen liegen und nicht davor.
        /// Alphabetisch waere "32bit" das erste blatt, denn '3' sortiert vor
        /// jedem buchstaben.
        /// </summary>
        static readonly string[] trailing_pages = { "32bit" };

        /// <summary>
        /// Die reihenfolge der inventar-seiten: erst alles alphabetisch (stabil,
        /// unabhaengig von der discovery-reihenfolge), danach die kategorien aus
        /// <see cref="trailing_pages"/> in ihrer listen-reihenfolge. Die seiten
        /// haengen nur am namen - wer eine neue kategorie anlegt, braucht hier
        /// nichts zu tun, sie reiht sich alphabetisch ein.
        /// </summary>
        public static int compare_categories(string a, string b)
        {
            int ra = trailing_rank(a), rb = trailing_rank(b);
            if (ra != rb) return ra.CompareTo(rb);
            return string.CompareOrdinal(a, b);
        }

        /// <summary>-1 = normale kategorie (alphabetisch), sonst der platz in der liste.</summary>
        static int trailing_rank(string category)
        {
            int index = Array.IndexOf(trailing_pages, category);
            return index < 0 ? -1 : index;
        }

        /// <summary>
        /// Builds the pages. Gates are grouped by [GateCategory] attributes,
        /// anything unattributed lands on "basic". Adding a new gate = one file,
        /// no registry edits needed.
        /// </summary>
        public static void init()
        {
            pages.Clear();
            by_type_id.Clear();

            var all = Assembly.GetExecutingAssembly().GetTypes()
                .Where(t => t.IsSubclassOf(typeof(GateBase)) && !t.IsAbstract)
                .OrderBy(t => t.Name)
                .ToList();

            Dictionary<string, GatePage> page_map = new();
            foreach (Type t in all)
            {
                string cat = t.GetCustomAttribute<GateCategoryAttribute>()?.category ?? "basic";

                if (!page_map.TryGetValue(cat, out GatePage page))
                {
                    page = new GatePage(cat);
                    page_map[cat] = page;
                    pages.Add(page);
                }
                page.gate_types.Add(t);
                by_type_id[t.Name.ToLowerInvariant()] = t;
            }

            //seiten in fester reihenfolge (alphabetisch, die grossen brocken
            //zuletzt - siehe compare_categories), damit die inventar-blaetter
            //unabhaengig von der discovery-reihenfolge stabil liegen
            pages.Sort((a, b) => compare_categories(a.name, b.name));
            foreach (GatePage p in pages) p.gate_types.Sort((a, b) => string.CompareOrdinal(a.Name, b.Name));
        }

        public static int page_count() => pages.Count;

        public static GatePage page(int index) => pages[Math.Clamp(index, 0, Math.Max(0, pages.Count - 1))];

        public static Type type_by_id(string id)
        {
            id = id.ToLowerInvariant();
            return by_type_id.TryGetValue(id, out var t) ? t : null;
        }

        public static GateBase create(Type t)
        {
            if (t == null) return null;
            return (GateBase)Activator.CreateInstance(t);
        }

        public static GateBase create(string type_id)
        {
            return create(type_by_id(type_id));
        }
    }

    /// <summary>Opt-in category for a gate file. Optional: gates without it go to "basic".</summary>
    [AttributeUsage(AttributeTargets.Class, Inherited = false)]
    internal class GateCategoryAttribute : Attribute
    {
        public readonly string category;
        public GateCategoryAttribute(string c) { category = c; }
    }
}
