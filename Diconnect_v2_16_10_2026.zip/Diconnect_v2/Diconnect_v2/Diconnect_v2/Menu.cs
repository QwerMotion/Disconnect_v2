using Raylib_cs;
using System;
using System.Collections.Generic;
using System.Numerics;

namespace Diconnect_v2
{
    /// <summary>Ein eintrag in einem menu (inventar, tools, ...).</summary>
    internal interface IMenuEntry
    {
        /// <summary>Was das menue anzeigt (wie im vorbild klein geschrieben).</summary>
        string display_name { get; }

        /// <summary>Sortierschluessel innerhalb der kategorie.</summary>
        string sort_key { get; }
    }

    /// <summary>Ein nativ implementiertes gate als menu-eintrag.</summary>
    internal class GateEntry : IMenuEntry
    {
        public readonly Type type;

        public GateEntry(Type t) { type = t; }

        public string display_name => type.Name.ToLowerInvariant();
        public string sort_key => type.Name;
    }

    /// <summary>
    /// Ein text-menue (angelehnt an das Disconnect Inventory): W/S waehlt
    /// innerhalb der seite, A/D blaettert, mausrad scrollt, unten steht
    /// "kategorie seite / seiten".
    ///
    /// Jede seite hat genau items_per_page plaetze und gehoert zu einer
    /// kategorie: die eintraege einer kategorie werden dafuer alphabetisch in
    /// bloecke geteilt. Passt eine kategorie nicht mehr auf eine seite,
    /// entsteht automatisch eine weitere seite. Der seitenzaehler zaehlt ALLE
    /// seiten (ueber alle kategorien). Ein unvollstaendiger block wird mit
    /// blanks aufgefuellt, damit jede seite gleich viel platz einnimmt.
    ///
    /// Das inventar und das speicher-menue sind zwei instanzen dieser klasse,
    /// damit sich beide gleich bedienen.
    /// </summary>
    internal class Menu
    {
        public readonly string name;

        //so viele eintraege (bzw. blanks) hat jede seite
        public int items_per_page = 6;

        //eintraege aller seiten, genau items_per_page pro seite; null = blank
        public List<IMenuEntry> elements = new();

        //parallel zu elements: der kategorie-name jeder seite (index = page)
        public List<string> page_categories = new();

        //globaler index ueber elements
        public int selected = 0;

        public Menu(string name) { this.name = name; }

        public int count => elements.Count;

        /// <summary>Ein blank-platzhalter (oder ein index ausserhalb) ist kein waehlbarer eintrag.</summary>
        public bool is_blank(int index) => index < 0 || index >= count || elements[index] == null;

        /// <summary>
        /// Die seiten neu aufbauen: pro kategorie ein (oder mehrere) blaetter,
        /// eintraege alphabetisch, leere plaetze als blanks.
        /// </summary>
        public void set_pages(List<(string category, List<IMenuEntry> items)> pages)
        {
            elements.Clear();
            page_categories.Clear();

            foreach ((string category, List<IMenuEntry> items) in pages)
            {
                List<IMenuEntry> sorted = new List<IMenuEntry>(items);
                sorted.Sort((a, b) => string.CompareOrdinal(a.sort_key, b.sort_key));

                for (int i = 0; i < sorted.Count; i += items_per_page)
                {
                    for (int slot = 0; slot < items_per_page; slot++)
                    {
                        int index = i + slot;
                        elements.Add(index < sorted.Count ? sorted[index] : null);
                    }

                    //passt die kategorie nicht auf eine seite, folgt hier die naechste
                    page_categories.Add(category);
                }
            }

            if (count > 0 && is_blank(selected)) selected = find_next(selected, +1);
            if (selected >= count) selected = find_next(0, +1);
        }

        static int get_max_pages_for(int cnt, int per_page) => cnt <= 0 ? 1 : (cnt + per_page - 1) / per_page;

        public int get_max_pages() => get_max_pages_for(count, items_per_page);

        public int get_current_page() => count == 0 ? 0 : selected / items_per_page;

        /// <summary>Kategorie ("basic", "constructs", "tools", ...) der seite.</summary>
        public string get_page_category(int page)
        {
            return page >= 0 && page < page_categories.Count ? page_categories[page] : "";
        }

        /// <summary>
        /// Fusszeile einer seite: kategorie + aktuelle seite / anzahl ALLER
        /// seiten (ueber alle kategorien).
        /// </summary>
        public string get_page_label(int page)
        {
            return $"{get_page_category(page)} {page + 1} / {get_max_pages()}";
        }

        /// <summary>
        /// Naechster (dir=+1) bzw. vorheriger (dir=-1) ECHTER eintrag innerhalb
        /// derselben seite, mit umlauf; blanks werden uebersprungen. So bleibt
        /// die auswahl immer auf einer seite.
        /// </summary>
        int find_next(int from, int dir)
        {
            if (count <= 0) return 0;

            int page_start = (from / items_per_page) * items_per_page;
            int len = Math.Min(page_start + items_per_page, count) - page_start;
            if (len <= 0) return from;

            int rel = from - page_start;
            for (int step = 1; step <= len; step++)
            {
                int index = page_start + ((rel + dir * step) % len + len) % len;
                if (!is_blank(index)) return index;
            }
            return from;
        }

        /// <summary>Auf eine seite wechseln (umlauf oben/unten), auswahl auf den ersten eintrag.</summary>
        public void go_to_page(int page)
        {
            if (count <= 0) return;

            int mp = get_max_pages();
            if (page >= mp) page = 0;
            else if (page < 0) page = mp - 1;

            selected = find_next(page * items_per_page, +1);
        }

        /// <summary>Einen eintrag weiter (dir=+1) oder zurueck (dir=-1), innerhalb der seite.</summary>
        public void move(int dir)
        {
            if (count <= 0) return;
            selected = find_next(selected, dir >= 0 ? +1 : -1);
        }

        /// <summary>Eingabe: w/s innerhalv der seite, a/d seitenwechsel, mausrad scrollt.</summary>
        public void do_input()
        {
            if (Raylib.GetMouseWheelMove() < 0) move(+1);
            if (Raylib.GetMouseWheelMove() > 0) move(-1);

            if (Raylib.IsKeyPressed(KeyboardKey.S)) move(+1);
            if (Raylib.IsKeyPressed(KeyboardKey.W)) move(-1);

            //seitenwechsel, umlaeufe ganz oben/unten
            if (Raylib.IsKeyPressed(KeyboardKey.A)) go_to_page(selected / items_per_page - 1);
            if (Raylib.IsKeyPressed(KeyboardKey.D)) go_to_page(selected / items_per_page + 1);
        }

        public IMenuEntry get_selected() => count == 0 ? null : elements[selected];

        /// <summary>Anzeige-name des eintrags an index i; ein blank-platzhalter hat keinen text.</summary>
        public string get_display_name(int index)
        {
            if (index < 0 || index >= count) return "";
            return elements[index]?.display_name ?? "";
        }

        // ---- zeichnen ----------------------------------------------------------------

        public void draw(float ox, float oy, float scale)
        {
            if (count <= 0) return;

            int page = selected / items_per_page;
            int page_start = page * items_per_page;
            float font_size = Global.inventory_fontsize * scale;
            float line = Global.inventory_line_height * scale;

            //immer items_per_page zeilen: blanks lassen ihren platz einfach leer
            for (int row = 0; row < items_per_page; row++)
            {
                int i = page_start + row;
                if (i >= count) continue;

                string label = get_display_name(i);
                if (label.Length == 0) continue;             //blank

                Color draw_color = i == selected ? Color.Orange : Color.LightGray;
                Raylib.DrawTextEx(Global.font, label,
                    new Vector2(ox + 10 * scale, oy + 10 * scale + line * row),
                    font_size, Global.letter_spacing, draw_color);
            }

            //seitenanzeige: kategorie + aktuelle seite / ALLE seiten (ueber alle
            //kategorien), fester platz unter der sechsten zeile, egal wie viele
            //eintraege die seite wirklich hat
            string page_text = get_page_label(page);
            Raylib.DrawTextEx(Global.font, page_text,
                new Vector2(ox + 10 * scale, oy + 10 * scale + line * items_per_page),
                font_size, Global.letter_spacing, Color.LightGray);
        }

        //fenster-pixel-bereich, in dem die liste liegt (fuer klick-masking)
        public Rectangle screen_rect(float ox, float oy, float scale)
        {
            float h = Global.inventory_fontsize + (items_per_page + 1) * Global.inventory_line_height;
            return new Rectangle(ox, oy, 200 * scale, h * scale + 10 * scale);
        }

        public bool contains_window(Vector2 window_mouse, float ox, float oy, float scale)
        {
            if (count <= 0) return false;
            return Raylib.CheckCollisionPointRec(window_mouse, screen_rect(ox, oy, scale));
        }
    }
}
