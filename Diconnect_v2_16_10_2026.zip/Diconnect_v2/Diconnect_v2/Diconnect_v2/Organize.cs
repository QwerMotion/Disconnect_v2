using Raylib_cs;
using System;
using System.Collections.Generic;
using System.Numerics;

namespace Diconnect_v2
{
    /// <summary>
    /// Ein eintrag der organize-ebene: eine beschriftung oder ein rahmen.
    ///
    /// Organize-items sind KEINE schaltungs-gates: sie haben keine pins, keine
    /// leitungen und liegen NICHT im gate_grid. Sie schweben auf ihrer eigenen
    /// ebene (siehe <see cref="Organize.items"/>), koennen also ueber gates
    /// und ueber einander liegen und blockieren nichts. Beim bauen werden sie
    /// genauso behandelt wie gates (auswahl im inventar, ghost, verschieben,
    /// T loescht), beim speichern eines constructs wandern sie mit in die json.
    ///
    /// Damit neue organize-items (z.b. eine notiz) ohne aenderung am rest
    /// funktionieren, reicht: von OrganizeItem erben, [GateCategory("organize")],
    /// type_id(), fertig.
    /// </summary>
    internal abstract class OrganizeItem : GateBase
    {
        public override int num_inputs => 0;
        public override int num_outputs => 0;

        protected OrganizeItem()
        {
            draw_name = false;   //organize-items zeichnen sich selbst
        }

        protected override List<bool> evaluate(List<bool> inputs) => new List<bool>();

        /// <summary>
        /// Umriss der belegten zellen - fuer die vorschau beim platzieren.
        /// Noetig, weil eine beschriftung nur ihren text zeichnet und ohne text
        /// sonst unsichtbar waere.
        /// </summary>
        public virtual void draw_preview_outline(int cell_x, int cell_y)
        {
            (int w, int h) = get_cell_size();
            Raylib.DrawRectangleLinesEx(new Rectangle(
                cell_x * Global.cell_size, cell_y * Global.cell_size,
                w * Global.cell_size, h * Global.cell_size), 2f,
                new Color(255, 255, 255, 120));
        }

        /// <summary>Groesse aus einer gespeicherten angabe setzen (constructs).</summary>
        public virtual void set_size(int width_cells, int height_cells) { }
    }

    /// <summary>
    /// Die organize-ebene selbst: die liste der items, ihr platzieren,
    /// das treffen mit der maus und das zeichnen - plus der zustand des
    /// rahmen-werkzeugs (zwei klicks wie im speicher-modus).
    /// </summary>
    internal static class Organize
    {
        /// <summary>Alle beschriftungen und rahmen der welt (reihenfolge = zeichenreihenfolge).</summary>
        public static List<OrganizeItem> items = new();

        //das rahmen-werkzeug: die erste ecke eines angeklickten rahmens
        public static bool has_first;
        public static (int x, int y) first;

        /// <summary>Der inventar-eintrag, mit dem der offene rahmen begonnen wurde -
        /// wechselt der eintrag, wird der offene rahmen verworfen (siehe keep_item).</summary>
        static object pending_item;

        public static void clear()
        {
            items.Clear();
            reset_marker();
        }

        public static void reset_marker()
        {
            has_first = false;
            first = (0, 0);
            pending_item = null;
        }

        /// <summary>
        /// Ein offener rahmen gehoert zu dem eintrag, mit dem er begonnen wurde:
        /// waehlt der user im inventar etwas anderes, wird er verworfen (genau
        /// einmal pro frame mit dem gerade aktiven eintrag aufrufen).
        /// </summary>
        public static void keep_item(object current_item)
        {
            if (!has_first) return;
            if (!ReferenceEquals(pending_item, current_item)) reset_marker();
        }

        /// <summary>Das oberste item an dieser stelle (zuletzt platziert gewinnt).</summary>
        public static OrganizeItem at(Vector2 world_pos)
        {
            (int cx, int cy) = Global.cell_at(world_pos);
            for (int i = items.Count - 1; i >= 0; i--)
            {
                OrganizeItem it = items[i];
                (int w, int h) = it.get_cell_size();
                if (cx >= it.cell_x && cx < it.cell_x + w &&
                    cy >= it.cell_y && cy < it.cell_y + h)
                    return it;
            }
            return null;
        }

        public static bool place(OrganizeItem item, int cell_x, int cell_y)
        {
            if (item == null) return false;
            item.cell_x = cell_x;
            item.cell_y = cell_y;
            items.Add(item);
            return true;
        }

        public static void remove(OrganizeItem item)
        {
            if (item != null) items.Remove(item);
        }

        /// <summary>
        /// Ein klick des rahmen-werkzeugs: der erste setzt die erste ecke, der
        /// zweite die zweite. Genau wie im speicher-modus wird ein rahmen, der
        /// ein gate anschneidet, aber nicht umschliesst, verworfen.
        /// </summary>
        public static void border_click(object item, int cell_x, int cell_y)
        {
            if (!has_first)
            {
                first = (cell_x, cell_y);
                has_first = true;
                pending_item = item;   //dieser eintrag haelt den offenen rahmen
                return;
            }

            var r = Selection.rect_between(first, (cell_x, cell_y));
            has_first = false;

            if (!Selection.valid(r)) return;   //ein gate wird angeschnitten -> nichts tun

            var border = new BORDER();
            border.set_size(r.x2 - r.x1 + 1, r.y2 - r.y1 + 1);
            place(border, r.x1, r.y1);
        }

        // ---- zeichnen ----------------------------------------------------------------

        public static void draw(Camera2D cam)
        {
            foreach (OrganizeItem it in items)
                if (it.visible(cam)) it.draw();
        }

        /// <summary>Die flaeche, die das rahmen-werkzeug gerade aufzieht.</summary>
        public static void draw_pending_preview(Vector2 mouse_world)
        {
            if (!has_first) return;

            (int cx, int cy) = Global.cell_at(mouse_world);
            var r = Selection.rect_between(first, (cx, cy));
            Selection.draw_area(r, Selection.valid(r));
        }

        // ---- constructs --------------------------------------------------------------

        /// <summary>Alle items, die vollstaendig in der auswahl liegen (fuer das speichern).</summary>
        public static List<OrganizeItem> inside((int x1, int y1, int x2, int y2) rect)
        {
            var list = new List<OrganizeItem>();
            foreach (OrganizeItem it in items)
                if (Selection.fully_inside(it, rect)) list.Add(it);
            return list;
        }
    }
}
