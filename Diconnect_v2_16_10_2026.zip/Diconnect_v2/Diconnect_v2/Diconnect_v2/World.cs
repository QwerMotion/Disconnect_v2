using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    internal static class World
    {
        public static Dictionary<(int cell_x, int cell_y), IGate> gate_grid = new Dictionary<(int cell_x, int cell_y), IGate>();
        public static List<IGate> current = new List<IGate>();
        public static List<IGate> next = new List<IGate>();
        public static List<Wire> wires = new List<Wire>();

        static int next_id = 1;
        public static int next_gate_id() => next_id++;

        /// <summary>Set when the user interacts between ticks so the next frame surely ticks.</summary>
        public static bool tick_kick;

        public static void reset()
        {
            gate_grid.Clear();
            wires.Clear();
            current.Clear();
            next.Clear();
            tick_kick = false;
        }

        // ---- registration ----------------------------------------------------------------

        public static void register(Wire w) { if (!wires.Contains(w)) wires.Add(w); }
        public static void unregister(Wire w) { wires.Remove(w); }

        // ---- grid helpers ------------------------------------------------------------------

        public static IGate at_cell(int x, int y)
        {
            gate_grid.TryGetValue((x, y), out IGate g);
            return g;
        }

        public static bool is_partially_free(GateBase g)
        {
            (int w, int h) = g.get_cell_size();
            for (int cx = g.cell_x; cx < g.cell_x + w; cx++)
                for (int cy = g.cell_y; cy < g.cell_y + h; cy++)
                    if (gate_grid.ContainsKey((cx, cy)))
                        return false;
            return true;
        }

        // ---- gate lifecycle ------------------------------------------------------------------

        public static bool place(GateBase g, int cell_x, int cell_y)
        {
            g.cell_x = cell_x;
            g.cell_y = cell_y;
            if (!is_partially_free(g)) return false;

            (int w, int h) = g.get_cell_size();
            for (int cx = cell_x; cx < cell_x + w; cx++)
                for (int cy = cell_y; cy < cell_y + h; cy++)
                    gate_grid[(cx, cy)] = g;

            // a placed gate must compute its first output -> its fanout follows one tick later
            schedule(g);
            return true;
        }

        /// <summary>Steht dieses gate (noch) in der welt? Beim ziehen ist es kurz draussen.</summary>
        public static bool is_placed(GateBase g) => g != null && at_cell(g.cell_x, g.cell_y) == g;

        public static void remove(GateBase g)
        {
            (int gw, int gh) = g.get_cell_size();

            //erst merken, welche gates von g getrieben wurden: ihre eingaenge
            //haengen nach dem loeschen in der luft und muessen neu ausgewertet
            //werden, sonst bleibt dort ein pins aktiv (rot) stehen
            var driven = new List<GateBase>();
            foreach (Wire wr in wires)
            {
                if (wr.output == null || wr.input == null) continue;
                if (wr.output.gate != g) continue;
                if (wr.input.gate is GateBase d && d != g && !driven.Contains(d)) driven.Add(d);
            }

            // drop wires connected to any of its pins
            var to_kill = new List<Wire>();
            foreach (Wire wr in wires)
            {
                if (wr.output == null || wr.input == null) continue;
                if (wr.output.gate == g || wr.input.gate == g) to_kill.Add(wr);
            }
            foreach (Wire wr in to_kill) wr.destroy(null);

            (int cx, int cy) = (g.cell_x, g.cell_y);
            for (int x = cx; x < cx + gw; x++)
                for (int y = cy; y < cy + gh; y++)
                    gate_grid.Remove((x, y));

            current.Remove(g);
            next.Remove(g);

            //die treiberlosen eingaenge fallen jetzt auf 0 zurueck (mit allem,
            //was daran haengt); gates, die mitgeloescht wurden, sind nicht mehr
            //platziert und werden uebersprungen
            foreach (GateBase d in driven)
                if (is_placed(d)) eval_gate_recursive(d);

            kick();
        }

        // ---- inspecting / dragging ---------------------------------------------------

        /// <summary>
        /// Lifts a gate out of the grid (freeing its cells) while keeping it alive
        /// so it can be dragged. Original position is remembered for abort.
        /// </summary>
        static Dictionary<IGate, (int x, int y)> drag_origins = new();

        public static void begin_drag(GateBase g)
        {
            (int gw, int gh) = g.get_cell_size();
            for (int x = g.cell_x; x < g.cell_x + gw; x++)
                for (int y = g.cell_y; y < g.cell_y + gh; y++)
                    gate_grid.Remove((x, y));
            drag_origins[g] = (g.cell_x, g.cell_y);
        }

        /// <summary>All cells below the (floating) gate are free?</summary>
        public static bool is_free_at_drag(GateBase g)
        {
            (int gw, int gh) = g.get_cell_size();
            for (int cx = g.cell_x; cx < g.cell_x + gw; cx++)
                for (int cy = g.cell_y; cy < g.cell_y + gh; cy++)
                    if (gate_grid.ContainsKey((cx, cy))) return false;
            return true;
        }

        public static void commit_drag(GateBase g)
        {
            (int gw, int gh) = g.get_cell_size();
            for (int cx = g.cell_x; cx < g.cell_x + gw; cx++)
                for (int cy = g.cell_y; cy < g.cell_y + gh; cy++)
                    gate_grid[(cx, cy)] = g;
            drag_origins.Remove(g);
        }

        public static void abort_drag(GateBase g)
        {
            if (drag_origins.TryGetValue(g, out (int x, int y) orig))
            {
                g.cell_x = orig.x;
                g.cell_y = orig.y;
            }
            commit_drag(g);
        }

        public static GateBase gate_at(Vector2 world_pos)
        {
            (int cx, int cy) = Global.cell_at(world_pos);
            gate_grid.TryGetValue((cx, cy), out IGate g);
            return g as GateBase;
        }

        public static Pin pin_at(Vector2 world_pos)
        {
            // pins don't occupy grid cells, so just test the pin rects of nearby gates
            (int cx, int cy) = Global.cell_at(world_pos);
            for (int x = cx - 1; x <= cx + 1; x++)
                for (int y = cy - 1; y <= cy + 1; y++)
                    if (gate_grid.TryGetValue((x, y), out IGate g))
                        if (g is GateBase gb)
                        {
                            Pin p = gb.pin_at(world_pos);
                            if (p != null) return p;
                        }
            return null;
        }

        public static void schedule(IGate g)
        {
            if (!next.Contains(g)) next.Add(g);
        }

        /// <summary>Called after wiring a connection -> the driven gate re-evaluates.</summary>
        public static void eval_gate_recursive(GateBase gate)
        {
            schedule(gate);
            List<IGate> fanout = gate.get_fanout();
            foreach (IGate f in fanout) schedule(f);
        }

        /// <summary>Force the tick pipeline to run on the next frame even at ticks_per_frame < 1.</summary>
        public static void kick() { tick_kick = true; }

        /// <summary>
        /// Per-frame update fuer jedes platzierte gate (uhren und andere
        /// zeitgeber laufen in echtzeit, unabhaengig von ticks_per_frame).
        /// Mehrzellige gates liegen auf mehreren grid-keys, also nur einmal.
        /// </summary>
        public static void frame_update_all(float dt)
        {
            var seen = new HashSet<IGate>();
            foreach (var kv in gate_grid)
                if (kv.Value != null && seen.Add(kv.Value) && kv.Value is GateBase g)
                    g.frame_update(dt);
        }

        // ---- the tick engine ----------------------------------------------------------------

        /// <summary>
        /// One simulation tick (exactly ONE batch):
        ///  1) every gate in `current` computes its next state (without applying),
        ///  2) all apply; changed gates push their fanout into `next`,
        ///  3) `next` becomes `current` for the next tick.
        /// Wires are instant - only the gates delay by one tick, so the deeper a
        /// circuit is, the more ticks it needs.
        /// </summary>
        public static void tick()
        {
            // scheduled work (from user input between ticks) becomes the current batch
            if (current.Count == 0)
            {
                if (next.Count == 0) { tick_kick = false; return; }
                (current, next) = (next, current);
                next.Clear();
            }

            List<IGate> batch = current;

            // phase 1: read/compute new outputs without applying
            foreach (IGate g in batch)
                g.read();

            // phase 2: apply; changed gates enqueue their fanout into next
            foreach (IGate g in batch)
            {
                bool changed = g.write();
                if (changed)
                    foreach (IGate f in g.get_fanout())
                        if (!next.Contains(f)) next.Add(f);
            }

            // next becomes the new current
            (current, next) = (next, current);
            next.Clear();
            tick_kick = false;
        }
    }
}
