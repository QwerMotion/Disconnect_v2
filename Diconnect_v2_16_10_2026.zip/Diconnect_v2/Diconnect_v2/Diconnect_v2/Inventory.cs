using Raylib_cs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace Diconnect_v2
{
    /// <summary>
    /// Das inventar: alle platzierbaren eintraege als text-liste.
    /// Seit dem speichern-system besteht es aus zwei sorten eintraegen:
    ///   * nativ in C# implementierte gates (kategorie aus [GateCategory])
    ///   * constructs (kategorie "constructs", aus constructs/*.json)
    ///
    /// Die ganze menue-mechanik (w/s/a/d, mausrad, seitenanzeige "kategorie
    /// seite / seiten") steckt in <see cref="Menu"/>; das inventar ist nur
    /// die zusammenstellung der seiten. Das speicher-menue benutzt dieselbe
    /// klasse mit anderen eintraegen.
    /// </summary>
    internal static class Inventory
    {
        static public Menu menu = new Menu("inventory");

        //so viele eintraege (bzw. blanks) hat jede inventar-seite
        static public int items_per_page
        {
            get => menu.items_per_page;
            set => menu.items_per_page = value;
        }

        static public List<IMenuEntry> elements => menu.elements;

        static public int selected
        {
            get => menu.selected;
            set => menu.selected = value;
        }

        /// <summary>Construct-json-dateien einlesen und das menue aufbauen.</summary>
        static public void init()
        {
            ConstructStore.load();
            refresh();
        }

        /// <summary>Die seiten neu aufbauen (nach dem speichern eines constructs).</summary>
        static public void refresh()
        {
            var pages = new List<(string category, List<IMenuEntry> items)>();

            //eine inventar-seite (bzw. mehrere, falls eine kategorie mehr als
            //items_per_page gates hat) pro gate-page
            foreach (GatePage page in GateRegistry.pages)
            {
                var items = new List<IMenuEntry>();
                foreach (Type t in page.gate_types) items.Add(new GateEntry(t));
                pages.Add((page.name, items));
            }

            //constructs bekommen ihre eigene kategorie - nur wenn es welche gibt
            if (ConstructStore.all.Count > 0)
            {
                var constructs = new List<IMenuEntry>();
                foreach (ConstructDef c in ConstructStore.all) constructs.Add(c);
                pages.Add(("constructs", constructs));
            }

            //kategorien in der reihenfolge des registers (alphabetisch, die
            //grossen brocken zuletzt - siehe GateRegistry.compare_categories),
            //damit die seiten stabil liegen
            pages.Sort((a, b) => GateRegistry.compare_categories(a.category, b.category));

            menu.set_pages(pages);
        }

        /// <summary>
        /// Eine eintrags-position direkt setzen. Seite UND zeile des inventars
        /// ergeben sich daraus (die seite ist selected / items_per_page), es muss
        /// also nichts weiter nachgezogen werden - die suche uebernimmt so einen
        /// treffer (siehe Search.choose).
        /// </summary>
        static public void select_index(int index)
        {
            if (menu.count == 0) return;
            menu.selected = Math.Clamp(index, 0, menu.count - 1);
        }

        static public int count => menu.count;

        static public int get_max_pages() => menu.get_max_pages();

        static public int get_current_page() => menu.get_current_page();

        static public string get_page_category(int page) => menu.get_page_category(page);

        static public string get_page_label(int page) => menu.get_page_label(page);

        /// <summary>Der aktuell gewaehlte eintrag (gate ODER construct, null auf einem blank).</summary>
        static public IMenuEntry get_selected_entry() => menu.get_selected();

        /// <summary>Der gate-typ hinter der auswahl (null auf einem blank oder einem construct).</summary>
        static public Type get_selected_type() => (menu.get_selected() as GateEntry)?.type;

        /// <summary>Der construct hinter der auswahl (null bei gates/blanks).</summary>
        static public ConstructDef get_selected_construct() => menu.get_selected() as ConstructDef;

        static public string get_display_name(int index) => menu.get_display_name(index);

        static public void do_input(Vector2 window_mouse, float ox, float oy, float scale)
        {
            //das inventar reagiert nur auf tastatur (w/s/a/d) und mausrad -
            //keine maus-klicks, links-klicks fallen komplett in die welt durch
            menu.do_input();
        }

        static public void draw(float ox, float oy, float scale) => menu.draw(ox, oy, scale);

        static public Rectangle screen_rect(float ox, float oy, float scale) => menu.screen_rect(ox, oy, scale);

        static public bool contains_window(Vector2 window_mouse, float ox, float oy, float scale)
        {
            return menu.contains_window(window_mouse, ox, oy, scale);
        }
    }
}
