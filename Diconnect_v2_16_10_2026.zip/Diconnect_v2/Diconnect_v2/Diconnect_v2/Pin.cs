using System;
using System.Collections.Generic;
using System.Numerics;
using Raylib_cs;

namespace Diconnect_v2
{
    /// <summary>
    /// One pin of a gate. Pins do NOT occupy grid cells.
    /// An input pin can be driven by many wires at once: it reads HIGH if at
    /// least one of its fan-in wires is high (artificial "or" gate).
    ///
    /// Ein pin traegt 1 bit (normal) oder 8 (bits = 8): ein 8-bit-pin ist EIN
    /// pin-platz, der acht bit-reihen uebereinander zeigt (reihe 0 = MSB ganz
    /// oben, genau wie bei den acht einzelnen pins eines SPLIT). Er ist
    /// Global.pin8_size hoch, jede reihe pin8_size / 8.
    ///
    /// Ein 8-bit-pin passt nur auf einen 8-bit-pin: eine leitung traegt immer
    /// gleich viele bits an beiden enden (siehe Wire.connect_undirected).
    /// </summary>
    internal class Pin : Ipin
    {
        public readonly IGate gate;
        public readonly bool input;   // true = input pin, false = output pin
        public readonly int index;    // index along its side of the gate

        public List<Wire> wires = new(); // output: all outgoing; input: all fan-in

        /// <summary>Wie viele bits dieser pin traegt: 1 (normal) oder 8.</summary>
        int _bits = 1;
        public int bits
        {
            get => _bits;
            set => _bits = Math.Clamp(value, 1, Global.pin8_rows);
        }

        /// <summary>
        /// Die bit-werte; reihe 0 (MSB) bis reihe bits-1 (LSB). Nur die ersten
        /// bits eintraege werden benutzt.
        /// </summary>
        public bool[] bit_state = new bool[Global.pin8_rows];

        /// <summary>Pegel des pins. Bei einem 8-bit-pin ist das sein MSB - fuer
        /// die pin-farbe zaehlt aber any_high().</summary>
        public bool state
        {
            get => bit_state[0];
            set => bit_state[0] = value;
        }

        public string name = "";
        public string description = "";

        public Pin(IGate gate, bool is_input, int index)
        {
            this.gate = gate;
            input = is_input;
            this.index = index;
            name = (is_input ? "IN" : "OUT") + index;
        }

        // ---- Ipin -------------------------------------------------------------------

        public IGate get_gate() => gate;

        /// <summary>Ipin: ein pin ist "aktiv", wenn irgendein bit hoch liegt -
        /// ein 8-bit-pin faerbt sich also wie ein normaler (rot/weiss). Explizit
        /// implementiert, weil die eigenschaft state sonst mit dem namen
        /// get_state kollidiert.</summary>
        bool Ipin.get_state() => any_high();

        public bool is_input() => input;
        public string get_name() => name;
        public string get_description() => description;

        // ---- bits --------------------------------------------------------------------

        /// <summary>Der pegel einer reihe (0 = MSB).</summary>
        public bool bit(int index) => index >= 0 && index < bits && bit_state[index];

        public void set_bit(int index, bool value)
        {
            if (index >= 0 && index < bits) bit_state[index] = value;
        }

        /// <summary>Ist irgendein bit dieses pins hoch? (pin-farbe)</summary>
        public bool any_high()
        {
            for (int i = 0; i < bits; i++) if (bit_state[i]) return true;
            return false;
        }

        /// <summary>Hoehe dieses pins in pixeln (pin8_size fuer 8 bit).</summary>
        public int height => bits > 1 ? row_height * bits : Global.pin_size;

        /// <summary>Hoehe EINER bit-reihe (nur bei 8 bit sinnvoll).</summary>
        public int row_height => Global.pin8_size / bits;

        /// <summary>Pegel, den eine auswertung fuer dieses bit sehen soll: fuer
        /// eingaenge das OR ueber alle fan-in-leitungen (kuenstliches or),
        /// sonst der eigene pegel.</summary>
        public bool bit_from_wire(int bit)
        {
            if (input)
            {
                foreach (Wire w in wires)
                    if (w.output != null && w.output.bit(bit)) return true; //or-fan-in
                return false; //kein (hoher) fan-in vorhanden
            }
            return this.bit(bit);
        }

        /// <summary>Wert an einer evaluation (reihe 0) - kompatibilitaet.</summary>
        public bool get_from_wire() => bit_from_wire(0);

        // ---- geometry ------------------------------------------------------------------

        public Rectangle rect()
        {
            if (gate is GateBase g)
            {
                (int w, int h) = g.get_cell_size();
                (int[] heights, int slot) = g.side_stack(this);
                return Global.pin_rect(g.cell_x, g.cell_y, w, h, heights, slot,
                                       input ? g.input_side : g.output_side);
            }
            return new Rectangle(0, 0, 0, 0);
        }

        /// <summary>Die reihe eines bits dieses pins (bei 1 bit: der ganze pin).</summary>
        public Rectangle bit_rect(int bit) => Global.bit_row(rect(), bit, bits);

        /// <summary>
        /// Auf welcher seite der box dieser pin sitzt. Die kurve einer leitung
        /// haengt daran: sie faehrt bzw. kommt auf der seite heraus, auf der der
        /// pin sitzt - NICHT immer nach rechts. Bei <see cref="RL"/> sitzt der
        /// EINGANG rechts, bei <see cref="LR"/> der AUSGANG links.
        /// </summary>
        public PinSide side
        {
            get
            {
                if (gate is GateBase g) return input ? g.input_side : g.output_side;
                return input ? PinSide.left : PinSide.right;   //wie ein normales gate
            }
        }

        /// <summary>
        /// Mitte des pins - hier haengt das kabel. Ein 8-bit-kabel setzt seine
        /// acht leitungen mit Global.line_offset um diesen punkt (sie folgen
        /// NICHT den reihen des pins, siehe Global.wire8_spacing).
        /// </summary>
        public Vector2 center()
        {
            Rectangle r = rect();
            return new Vector2(r.X + r.Width / 2f, r.Y + r.Height / 2f);
        }

        public bool hit(Vector2 world_pos) => Raylib.CheckCollisionPointRec(world_pos, rect());

        public void disconnect_all()
        {
            foreach (var wd in wires) wd.destroy(null);
            wires.Clear();
        }
    }
}
