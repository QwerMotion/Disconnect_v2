using Raylib_cs;
using System;
using System.Collections.Generic;
using System.Numerics;

namespace Diconnect_v2
{
    /// <summary>
    /// Die inventar-suche (ctrl+f): statt des inventars steht hier eine liste
    /// ALLER eintraege, deren name zur eingabe passt - gates UND constructs.
    ///
    /// Anders als das inventar ist sie nicht in seiten zu je sechs plaetzen
    /// geteilt: es werden so viele treffer gezeigt, wie ins inhaltsfeld passen,
    /// und durch die liste laesst sich scrollen (pfeiltasten hoch/runter und
    /// mausrad). Ganz ohne eingabe steht die ganze liste da - so kann man auch
    /// einfach durch alles blaettern.
    ///
    /// w/s sind hier absichtlich NICHT die blaetter-tasten wie im inventar: in
    /// einer suche tippt man namen, und "s" kommt in vielen vor ("split").
    ///
    /// Ein linksklick auf eine zeile uebernimmt genau diesen eintrag, enter den
    /// gerade gewaehlten; beides setzt die auswahl DES INVENTARS - seite und
    /// zeile ergeben sich aus dem index (siehe Inventory.select_index) - und geht
    /// zurueck ins bauen. Esc oder ein klick neben die liste geht nur zurueck.
    /// </summary>
    internal static class Search
    {
        /// <summary>Was der user getippt hat. Verglichen wird ohne gross/klein.</summary>
        public static string query = "";

        /// <summary>Die treffer als indizes in Inventory.elements, in menue-reihenfolge.</summary>
        public static List<int> matches = new();

        /// <summary>Der gewaehlte platz in matches.</summary>
        public static int selected;

        /// <summary>Der erste sichtbare platz in matches (damit scrollt die liste).</summary>
        public static int scroll;

        public const string title = "search";

        /// <summary>Erste zeile mit treffern: zeile 0 ist der titel, zeile 1 bleibt leer.</summary>
        public const int first_row = 2;

        /// <summary>Was ein durchlauf der suche ergeben hat.</summary>
        public enum Result
        {
            /// <summary>Die suche laeuft weiter.</summary>
            none,
            /// <summary>Den gewaehlten eintrag uebernehmen und schliessen.</summary>
            choose,
            /// <summary>Nur schliessen (esc oder ein klick neben die liste).</summary>
            close
        }

        // ---- auf/zu -----------------------------------------------------------------

        /// <summary>Die suche oeffnen: leere eingabe, also die ganze liste, erste zeile gewaehlt.</summary>
        public static void begin()
        {
            query = "";
            selected = 0;
            scroll = 0;
            refresh();
            Global.state = GlobalState.searching;
        }

        /// <summary>Die suche schliessen und zurueck ins bauen.</summary>
        public static void close()
        {
            query = "";
            matches.Clear();
            selected = 0;
            scroll = 0;
            Global.state = GlobalState.building;
        }

        // ---- eingabe ----------------------------------------------------------------

        /// <summary>Alle eintraege, deren name die eingabe enthaelt, in menue-reihenfolge.</summary>
        public static void refresh()
        {
            matches.Clear();

            List<IMenuEntry> all = Inventory.elements;
            for (int i = 0; i < all.Count; i++)
            {
                IMenuEntry entry = all[i];
                if (entry == null) continue;                 //leere plaetze im inventar
                if (query.Length == 0 || contains(entry.display_name, query)) matches.Add(i);
            }

            if (selected >= matches.Count) selected = Math.Max(0, matches.Count - 1);
            if (selected < 0) selected = 0;
            keep_visible(visible_rows());
        }

        static bool contains(string text, string needle)
        {
            return text != null && text.IndexOf(needle, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        /// <summary>Ein getipptes zeichen uebernehmen (es filtert die liste).</summary>
        public static void type(char ch)
        {
            query += ch;
            selected = 0;   //die erste zeile des neuen ergebnisses ist gewaehlt
            scroll = 0;
            refresh();
        }

        /// <summary>Ein zeichen loeschen (leere eingabe: nichts zu tun).</summary>
        public static void backspace()
        {
            if (query.Length == 0) return;
            query = query.Remove(query.Length - 1);
            selected = 0;
            scroll = 0;
            refresh();
        }

        /// <summary>In der liste einen platz weiter (dir=+1) oder zurueck (dir=-1), mit umlauf.</summary>
        public static void move(int dir)
        {
            if (matches.Count == 0) return;
            selected = ((selected + dir) % matches.Count + matches.Count) % matches.Count;
            keep_visible(visible_rows());
        }

        /// <summary>Die auswahl im sichtbaren fenster halten (die liste scrollt mit).</summary>
        public static void keep_visible(int visible)
        {
            if (visible <= 0 || matches.Count == 0) { scroll = 0; return; }

            if (selected < scroll) scroll = selected;
            else if (selected >= scroll + visible) scroll = selected - visible + 1;

            scroll = Math.Clamp(scroll, 0, Math.Max(0, matches.Count - visible));
        }

        /// <summary>Den gewaehlten eintrag im inventar auswaehlen (seite und zeile folgen).</summary>
        public static bool choose()
        {
            if (selected < 0 || selected >= matches.Count) return false;
            Inventory.select_index(matches[selected]);
            return true;
        }

        /// <summary>
        /// Den ablauf auswerten: die tasten und die maus sind schon gelesen, hier
        /// steht nur noch, was daraus folgt. Eigene methode, damit sich die suche
        /// ohne echte tastatur durchspielen laesst.
        /// </summary>
        public static Result step(bool close_key, bool choose_key, bool clicked, int clicked_row)
        {
            if (close_key) return Result.close;        //esc
            if (choose_key) return Result.choose;      //enter: den gewaehlten eintrag

            if (!clicked) return Result.none;

            if (clicked_row >= 0)
            {
                selected = clicked_row;                //der klick zeigt auf genau diese zeile
                return Result.choose;
            }

            return Result.close;                       //klick neben die liste
        }

        /// <summary>
        /// Die echte eingabe der suche: tippen, backspace, pfeile/rad zum blaettern,
        /// enter/esc und linksklick. Uebernimmt und schliesst noch nichts - das
        /// macht der aufrufer mit dem ergebnis.
        /// </summary>
        public static Result do_input(Vector2 window_mouse, float ox, float oy)
        {
            int c;
            while ((c = Raylib.GetCharPressed()) > 0)
            {
                if (c < 32) continue;                  //steuerzeichen kommen nicht als text
                type((char)c);
            }

            if (Raylib.IsKeyPressed(KeyboardKey.Backspace)) backspace();

            //blaettern: pfeiltasten und mausrad (w/s tippen hier!)
            float wheel = Raylib.GetMouseWheelMove();
            if (Raylib.IsKeyPressed(KeyboardKey.Down) || wheel < 0f) move(+1);
            else if (Raylib.IsKeyPressed(KeyboardKey.Up) || wheel > 0f) move(-1);

            bool clicked = Raylib.IsMouseButtonPressed(MouseButton.Left);
            int row = clicked ? row_at(window_mouse, ox, oy) : -1;

            bool close_key = Raylib.IsKeyPressed(KeyboardKey.Escape);
            bool choose_key = Raylib.IsKeyPressed(KeyboardKey.Enter) || Raylib.IsKeyPressed(KeyboardKey.KpEnter);

            return step(close_key, choose_key, clicked, row);
        }

        // ---- geometrie --------------------------------------------------------------

        /// <summary>Wie viele treffer-zeilen ins inhaltsfeld passen (ohne titel und fusszeile).</summary>
        public static int visible_rows()
        {
            float scale = Global.content_scale;
            float line = Global.inventory_line_height * scale;
            if (line <= 0f) return 1;

            float height = 720f * scale;   //inhaltshoehe in bild-punkten (siehe Global.update_letterbox)
            int rows = (int)MathF.Floor((height - 10f * scale) / line) - first_row - 1;
            return Math.Max(1, rows);
        }

        /// <summary>Die y-lage (bild-punkte) der ersten treffer-zeile.</summary>
        static float list_top(float oy)
        {
            return oy + 10f * Global.content_scale +
                   Global.inventory_line_height * Global.content_scale * first_row;
        }

        /// <summary>
        /// Der treffer-platz unter der maus, oder -1 (neben der liste / unter der
        /// letzten zeile). Zaehlt genau die zeilen, die auch wirklich gezeichnet
        /// werden - ein klick kann also keinen eintrag erwischen, den es nicht gibt.
        /// </summary>
        public static int row_at(Vector2 window_mouse, float ox, float oy)
        {
            float line = Global.inventory_line_height * Global.content_scale;
            if (line <= 0f || matches.Count == 0) return -1;

            int row = (int)MathF.Floor((window_mouse.Y - list_top(oy)) / line);
            if (row < 0 || row >= visible_rows()) return -1;

            int index = scroll + row;
            return index >= 0 && index < matches.Count ? index : -1;
        }

        // ---- zeichnen ---------------------------------------------------------------

        /// <summary>
        /// Die suche zeichnen: oben "search: eingabe", darunter ALLE treffer, die
        /// ins feld passen (nicht sechs wie im inventar), unten eine fusszeile mit
        /// der anzahl und dem gerade sichtbaren ausschnitt.
        /// </summary>
        public static void draw(float ox, float oy)
        {
            float scale = Global.content_scale;
            float font_size = Global.inventory_fontsize * scale;
            float line = Global.inventory_line_height * scale;
            int visible = visible_rows();

            //zeile 0: der titel und dahinter die eingabe, mit blinkendem cursor
            //(wie im eingabefeld) - zeile 1 bleibt leer
            Vector2 head = new Vector2(ox + 10f * scale, oy + 10f * scale);
            Raylib.DrawTextEx(Global.font, title + ":", head, font_size, Global.letter_spacing, Color.Orange);

            float typed_x = head.X + Global.text_advance(Global.font, title + ": ", font_size);
            Raylib.DrawTextEx(Global.font, query, new Vector2(typed_x, head.Y),
                              font_size, Global.letter_spacing, Color.LightGray);

            if (((int)(Raylib.GetTime() * 2.0)) % 2 == 0)
            {
                float cursor_x = typed_x + Global.text_advance(Global.font, query, font_size);
                Raylib.DrawTextEx(Global.font, "_", new Vector2(cursor_x, head.Y),
                                  font_size, Global.letter_spacing, Color.LightGray);
            }

            //die treffer: so viele zeilen wie passen, ab `scroll`
            for (int row = 0; row < visible; row++)
            {
                int index = scroll + row;
                if (index >= matches.Count) break;

                IMenuEntry entry = Inventory.elements[matches[index]];
                if (entry == null) continue;

                Color c = index == selected ? Color.Orange : Color.LightGray;
                Raylib.DrawTextEx(Global.font, entry.display_name,
                    new Vector2(ox + 10f * scale, list_top(oy) + line * row),
                    font_size, Global.letter_spacing, c);
            }

            //fusszeile: wie viele treffer es gibt und welcher ausschnitt steht
            string footer = matches.Count == 0
                ? "no match"
                : matches.Count <= visible
                    ? matches.Count + (matches.Count == 1 ? " entry" : " entries")
                    : $"showing {scroll + 1}-{Math.Min(scroll + visible, matches.Count)} of {matches.Count}";

            Raylib.DrawTextEx(Global.font, footer,
                new Vector2(ox + 10f * scale, list_top(oy) + line * visible),
                font_size, Global.letter_spacing, Color.LightGray);
        }
    }
}
